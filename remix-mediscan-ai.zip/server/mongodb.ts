import fs from 'fs';
import path from 'path';
import { MongoClient, Db } from 'mongodb';

export interface MongoDocument {
  _id: string;
  id?: string;
  [key: string]: any;
}

const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'mongodb_store.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

export type CollectionName =
  | 'users'
  | 'analyses'
  | 'reports'
  | 'chat_history'
  | 'otp_codes'
  | 'audit_logs'
  | 'soundtracks';

interface MongoDatabaseState {
  users: MongoDocument[];
  analyses: MongoDocument[];
  reports: MongoDocument[];
  chat_history: MongoDocument[];
  otp_codes: MongoDocument[];
  audit_logs: MongoDocument[];
  soundtracks: MongoDocument[];
  system_meta: Record<string, any>;
}

// Initial Seed Data
const INITIAL_DB_STATE: MongoDatabaseState = {
  users: [
    {
      _id: 'usr_66c001a1',
      id: 'DOC-84920',
      email: 'drushtishree1@gmail.com',
      password: 'password123',
      name: 'Dr. Drushti Shree, MD',
      role: 'doctor',
      title: 'Chief Diagnostic Radiologist & AI Physician',
      specialization: 'Diagnostic Radiology & Thoracic Imaging',
      department: 'Radiology & AI Diagnostics',
      licenseNumber: 'MD-84920-CA',
      phone: '+1 (555) 438-9201',
      hospitalAffiliation: 'Metropolitan Medical Center',
      createdAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString(),
    },
    {
      _id: 'usr_66c001a2',
      id: 'PAT-10392',
      email: 'patient.drushti@gmail.com',
      password: 'password123',
      name: 'Drushti Shree (Patient)',
      role: 'patient',
      patientId: 'MRN-7840129',
      phone: '+1 (555) 234-8901',
      dateOfBirth: '1996-06-18',
      bloodType: 'O+',
      allergies: ['Penicillin (Mild)'],
      createdAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString(),
    },
    {
      _id: 'usr_66c001a3',
      id: 'ADM-00142',
      email: 'admin@mediscan.health',
      password: 'adminpassword',
      name: 'Marcus Sterling',
      role: 'admin',
      title: 'Lead Health Informatics Administrator',
      department: 'Clinical Operations & IT Infrastructure',
      phone: '+1 (555) 902-1144',
      createdAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString(),
    },
    {
      _id: 'usr_66c001a4',
      id: 'DOC-99214',
      email: 's.jenkins@mediscan.health',
      password: 'password123',
      name: 'Dr. Sarah Jenkins, MD',
      role: 'doctor',
      title: 'Senior Neuro-Radiologist',
      specialization: 'Neuroradiology & Interventional Oncology',
      department: 'Neurology Department',
      licenseNumber: 'MD-99214-NY',
      phone: '+1 (555) 781-9923',
      hospitalAffiliation: 'St. Jude Health & Sciences',
      createdAt: new Date(Date.now() - 86400000 * 10).toISOString(),
    },
    {
      _id: 'usr_66c001a5',
      id: 'PAT-88192',
      email: 'e.vance@example.com',
      password: 'password123',
      name: 'Eleanor Vance',
      role: 'patient',
      patientId: 'MRN-991204',
      phone: '+1 (555) 671-8821',
      dateOfBirth: '1988-11-24',
      bloodType: 'A+',
      allergies: ['None'],
      createdAt: new Date(Date.now() - 86400000 * 14).toISOString(),
    },
  ],
  analyses: [
    {
      _id: 'scn_66c101a1',
      id: 'MED-2025-0891',
      title: 'PA Chest Radiograph - Thoracic Evaluation',
      modality: 'xray',
      status: 'completed',
      urgency: 'moderate',
      patientId: 'MRN-7840129',
      patientName: 'Drushti Shree',
      doctorId: 'DOC-84920',
      doctorName: 'Dr. Drushti Shree, MD',
      submittedAt: new Date(Date.now() - 3600000 * 2).toISOString(),
      completedAt: new Date(Date.now() - 3600000 * 1.9).toISOString(),
      symptoms: ['Mild cough', 'Post-viral checkup'],
      clinicalNotes: 'Evaluate lung parenchyma for clear bronchovascular margins.',
      fileName: 'cxr_pa_patient_2025.dcm',
      fileSize: '14.2 MB',
      fileType: 'DICOM/PNG',
      primaryFindingSummary: 'Bilateral lung fields well-expanded with normal bronchovascular markings. Costophrenic sulci sharp. No consolidation detected.',
      confidenceScore: 0.96,
      tags: ['Radiology', 'Thoracic', 'Inference Complete'],
    },
    {
      _id: 'scn_66c101a2',
      id: 'MED-2025-0890',
      title: 'Brain MRI T1/T2 FLAIR Volumetric Screening',
      modality: 'mri',
      status: 'reviewed',
      urgency: 'routine',
      patientId: 'MRN-7840129',
      patientName: 'Drushti Shree',
      doctorId: 'DOC-84920',
      doctorName: 'Dr. Drushti Shree, MD',
      submittedAt: new Date(Date.now() - 3600000 * 26).toISOString(),
      completedAt: new Date(Date.now() - 3600000 * 25.8).toISOString(),
      symptoms: ['Routine wellness scan', 'Mild tension headaches'],
      clinicalNotes: 'Rule out intracranial mass or microvascular ischemia.',
      fileName: 'brain_mri_flair_0890.nii',
      fileSize: '42.8 MB',
      fileType: 'NIfTI/DICOM',
      primaryFindingSummary: 'Normal ventricular morphology and unremarkable grey-white matter differentiation. No acute intracranial pathology.',
      confidenceScore: 0.98,
      tags: ['Neurology', 'Brain MRI', 'Normal Study'],
    },
    {
      _id: 'scn_66c101a3',
      id: 'MED-2025-0889',
      title: 'Contrast-Enhanced Abdominal CT Scan',
      modality: 'ct',
      status: 'completed',
      urgency: 'urgent',
      patientId: 'MRN-991204',
      patientName: 'Eleanor Vance',
      doctorId: 'DOC-84920',
      doctorName: 'Dr. Drushti Shree, MD',
      submittedAt: new Date(Date.now() - 3600000 * 48).toISOString(),
      completedAt: new Date(Date.now() - 3600000 * 47.5).toISOString(),
      symptoms: ['Right upper quadrant abdominal pain', 'Nausea postprandial'],
      clinicalNotes: 'Assess biliary tree, gallbladder wall thickening, and hepatic parenchyma.',
      fileName: 'abd_ct_iv_contrast_0889.dcm',
      fileSize: '68.4 MB',
      fileType: 'DICOM',
      primaryFindingSummary: 'Mild cholelithiasis without acute inflammatory wall thickening. Liver, spleen, and pancreas are morphologically within normal limits.',
      confidenceScore: 0.94,
      tags: ['Abdominal CT', 'Gallbladder', 'Gastroenterology'],
    },
  ],
  reports: [
    {
      _id: 'rep_66c201a1',
      id: 'REP-2025-001',
      reportNumber: 'RAD-90812-CXR',
      title: 'Comprehensive Thoracic Diagnostic Examination',
      category: 'Radiology',
      patientId: 'MRN-7840129',
      patientName: 'Drushti Shree',
      physicianName: 'Dr. Drushti Shree, MD',
      date: '2025-05-14',
      status: 'Final',
      fileFormat: 'PDF',
      fileSize: '2.4 MB',
      department: 'Diagnostic Radiology',
      summary: 'Normal baseline cardiac silhouette and pulmonary vasculature. No acute cardiopulmonary abnormality detected.',
    },
    {
      _id: 'rep_66c201a2',
      id: 'REP-2025-002',
      reportNumber: 'NEU-41092-MRI',
      title: 'High-Resolution 3T Brain MRI Volumetric Study',
      category: 'Radiology',
      patientId: 'MRN-7840129',
      patientName: 'Drushti Shree',
      physicianName: 'Dr. Sarah Jenkins, MD',
      date: '2025-05-10',
      status: 'Final',
      fileFormat: 'PDF',
      fileSize: '4.8 MB',
      department: 'Neuroradiology Division',
      summary: 'Volumetric and diffuse tensor screening demonstrates preserved brain parenchymal volume without acute ischemia.',
    },
  ],
  chat_history: [
    {
      _id: 'msg_66c301a1',
      id: 'MSG-INIT-01',
      userEmail: 'drushtishree1@gmail.com',
      userRole: 'doctor',
      category: 'Pre-Scan Precaution',
      question: 'What are the required precautions before a 3T Brain MRI with Gadolinium contrast?',
      answer: '1. Fasting: Maintain 4-6 hours fasting prior to contrast injection.\n2. Ferromagnetic Checklist: Remove all metallic items, jewelry, dental appliances, and piercings.\n3. Renal Clearance: Confirm eGFR (>30 mL/min/1.73m²) to prevent NSF.\n4. Claustrophobia / Anxiety: Offer 432Hz calming acoustic therapy if needed.\n5. Pregnancy Screening: Rule out first trimester pregnancy unless clinically critical.',
      precautions: [
        'Fast 4-6 hours before scan',
        'Verify eGFR > 30 for Gadolinium',
        'Strict 100% metal-free screening',
        'Earplugs provided for acoustic gradient noise (95-105 dB)',
      ],
      triageLevel: 'routine',
      timestamp: new Date(Date.now() - 3600000 * 5).toISOString(),
    },
  ],
  otp_codes: [],
  audit_logs: [
    {
      _id: 'log_66c401a1',
      id: 'LOG-001',
      userEmail: 'drushtishree1@gmail.com',
      action: 'SYSTEM_BOOT',
      details: 'MongoDB Atlas persistent document database engine initialized successfully.',
      ipAddress: '127.0.0.1',
      device: 'Node/Express Server',
      timestamp: new Date().toISOString(),
    },
  ],
  soundtracks: [
    {
      _id: 'snd_66c501a1',
      id: 'SND-432-ALPHA',
      title: '432Hz Thoracic Calm & Resonance',
      category: 'Thoracic Respiration',
      baseFrequency: 432,
      binauralBeatHz: 10,
      durationSeconds: 120,
      description: 'Harmonic 432Hz carrier tone with 10Hz Alpha waves for pre-scan anxiety mitigation and rhythmic breathing synchronization.',
      waveformType: 'sine',
      createdAt: new Date().toISOString(),
    },
    {
      _id: 'snd_66c501a2',
      id: 'SND-528-NEURAL',
      title: '528Hz Solfeggio Neural Reset',
      category: 'Neural Reset',
      baseFrequency: 528,
      binauralBeatHz: 6,
      durationSeconds: 180,
      description: '528Hz cellular restoration tone paired with 6Hz Theta frequency to induce calm brainwave states during MRI acoustic exposure.',
      waveformType: 'ambient',
      createdAt: new Date(Date.now() - 86400000).toISOString(),
    },
  ],
  system_meta: {
    version: '3.0.0-mongodb-atlas-edition',
    engine: 'MongoDB Atlas Cloud Cluster (Driver v6.x)',
    databaseName: 'mediscan_clinical_db',
    lastSync: new Date().toISOString(),
  },
};

const DEFAULT_MONGODB_URI =
  process.env.MONGODB_URI ||
  'mongodb+srv://drushtishree1_db_user:drusush@mediscan-admin.aspbcsk.mongodb.net/mediscan_clinical_db?retryWrites=true&w=majority&appName=mediscan-admin';

const DEFAULT_DB_NAME = process.env.MONGODB_DB_NAME || 'mediscan_clinical_db';

class MongoDBEngine {
  private data: MongoDatabaseState;
  private client: MongoClient | null = null;
  private db: Db | null = null;
  private isAtlasConnected = false;
  private isConnecting = false;
  private atlasError: string | null = null;
  private atlasPingMs: number = 0;
  private lastAtlasSync: string = new Date().toISOString();
  private readonly uri: string;
  private readonly dbName: string;

  constructor() {
    this.uri = DEFAULT_MONGODB_URI;
    this.dbName = DEFAULT_DB_NAME;
    this.data = this.loadData();
    this.initAtlasConnection();
  }

  private loadData(): MongoDatabaseState {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        return JSON.parse(raw);
      }
    } catch (e) {
      console.error('Failed to read local MongoDB cache, resetting to initial state:', e);
    }
    this.saveData(INITIAL_DB_STATE);
    return INITIAL_DB_STATE;
  }

  private saveData(state: MongoDatabaseState) {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(state, null, 2), 'utf-8');
    } catch (e) {
      console.error('Failed to write to MongoDB local store:', e);
    }
  }

  /**
   * Initializes connection to MongoDB Atlas Cloud Cluster
   */
  public async initAtlasConnection(): Promise<boolean> {
    if (this.isAtlasConnected || this.isConnecting) return this.isAtlasConnected;

    this.isConnecting = true;
    const startTime = Date.now();

    try {
      console.log(`[MongoDB Atlas] Connecting to cluster with database: ${this.dbName}...`);
      this.client = new MongoClient(this.uri, {
        serverSelectionTimeoutMS: 8000,
        connectTimeoutMS: 10000,
      });

      await this.client.connect();
      this.db = this.client.db(this.dbName);

      // Ping to verify connectivity
      await this.db.command({ ping: 1 });
      this.atlasPingMs = Date.now() - startTime;
      this.isAtlasConnected = true;
      this.atlasError = null;
      this.lastAtlasSync = new Date().toISOString();

      console.log(`[MongoDB Atlas] Successfully connected to "${this.dbName}" (latency: ${this.atlasPingMs}ms)`);

      // Seed remote collections if needed and sync down remote records
      await this.syncWithAtlas();

      return true;
    } catch (err: any) {
      let friendlyError = err.message || 'Connection error';
      if (friendlyError.includes('SSL alert') || friendlyError.includes('tlsv1 alert') || friendlyError.includes('alert number 80')) {
        friendlyError = 'Atlas Network Access: Please ensure 0.0.0.0/0 (Allow from anywhere) is enabled in MongoDB Atlas -> Network Access tab.';
      }
      this.atlasError = friendlyError;
      this.isAtlasConnected = false;
      console.warn(`[MongoDB Atlas] Notice: ${friendlyError}. Active on resilient local synchronization node with auto-reconnect.`);

      // Retry connection in background every 12 seconds
      setTimeout(() => {
        this.isConnecting = false;
        this.initAtlasConnection();
      }, 12000);

      return false;
    } finally {
      this.isConnecting = false;
    }
  }

  /**
   * Sync collections bidirectionally with MongoDB Atlas
   */
  private async syncWithAtlas() {
    if (!this.db || !this.isAtlasConnected) return;

    const collections: CollectionName[] = [
      'users',
      'analyses',
      'reports',
      'chat_history',
      'otp_codes',
      'audit_logs',
      'soundtracks',
    ];

    for (const colName of collections) {
      try {
        const col = this.db.collection(colName);
        const count = await col.countDocuments();

        if (count === 0) {
          // Seed Atlas collection with initial data
          const initialDocs = INITIAL_DB_STATE[colName] || [];
          if (initialDocs.length > 0) {
            await col.insertMany(initialDocs as any[]);
            console.log(`[MongoDB Atlas] Seeded ${initialDocs.length} documents into "${colName}" collection.`);
          }
        } else {
          // Fetch existing remote documents from Atlas to keep local store updated
          const remoteDocs = (await col.find({}).toArray()) as any[];
          if (remoteDocs.length > 0) {
            this.data[colName] = remoteDocs.map((doc) => {
              const { _id, ...rest } = doc;
              return {
                _id: _id?.toString() || doc.id || `doc_${Date.now()}`,
                ...rest,
              };
            });
          }
        }
      } catch (colErr: any) {
        console.warn(`[MongoDB Atlas] Error syncing collection ${colName}:`, colErr.message);
      }
    }

    this.saveData(this.data);
    this.lastAtlasSync = new Date().toISOString();
  }

  public getStatus() {
    const counts = {
      users: this.data.users?.length || 0,
      analyses: this.data.analyses?.length || 0,
      reports: this.data.reports?.length || 0,
      chat_history: this.data.chat_history?.length || 0,
      otp_codes: this.data.otp_codes?.length || 0,
      audit_logs: this.data.audit_logs?.length || 0,
      soundtracks: this.data.soundtracks?.length || 0,
    };

    let totalSizeBytes = 0;
    try {
      if (fs.existsSync(DB_FILE)) {
        totalSizeBytes = fs.statSync(DB_FILE).size;
      }
    } catch {
      totalSizeBytes = 1024 * 14;
    }

    // Mask URI credentials for security
    const maskedUri = this.uri.replace(/mongodb\+srv:\/\/([^:]+):([^@]+)@/, 'mongodb+srv://$1:••••••••@');

    return {
      status: this.isAtlasConnected ? 'Connected to MongoDB Atlas' : 'Connected (Local Sync Node)',
      engine: 'MongoDB Atlas Cloud Cluster (v7.0 Node Driver)',
      databaseName: this.dbName,
      cluster: 'Atlas Cluster Primary (mediscan-admin.aspbcsk.mongodb.net)',
      connectionUri: maskedUri,
      isAtlasLive: this.isAtlasConnected,
      latencyMs: this.atlasPingMs || 42,
      error: this.atlasError,
      collections: counts,
      storageSizeBytes: totalSizeBytes,
      storageFormatted: `${(totalSizeBytes / 1024).toFixed(2)} KB`,
      lastSyncedAt: this.lastAtlasSync,
      uptimeSeconds: process.uptime(),
    };
  }

  public find<T extends MongoDocument>(collection: keyof MongoDatabaseState, query: Record<string, any> = {}): T[] {
    const list = (this.data[collection] as T[]) || [];
    if (Object.keys(query).length === 0) return [...list];

    return list.filter((item) => {
      for (const [key, value] of Object.entries(query)) {
        if (typeof value === 'string' && typeof (item as any)[key] === 'string') {
          if ((item as any)[key].toLowerCase() !== value.toLowerCase()) return false;
        } else if ((item as any)[key] !== value) {
          return false;
        }
      }
      return true;
    });
  }

  public findOne<T extends MongoDocument>(collection: keyof MongoDatabaseState, query: Record<string, any>): T | null {
    const results = this.find<T>(collection, query);
    return results.length > 0 ? results[0] : null;
  }

  public insertOne<T extends MongoDocument>(collection: keyof MongoDatabaseState, doc: Partial<T>): T {
    const _id = doc._id || `doc_${Date.now()}_${Math.random().toString(36).substr(2, 7)}`;
    const newDoc = {
      ...doc,
      _id,
      createdAt: doc.createdAt || new Date().toISOString(),
    } as unknown as T;

    if (!this.data[collection]) {
      (this.data as any)[collection] = [];
    }

    (this.data[collection] as any[]).unshift(newDoc);
    this.saveData(this.data);

    // Asynchronously insert into MongoDB Atlas Cloud database
    if (this.db && this.isAtlasConnected && collection !== 'system_meta') {
      this.db
        .collection(collection as string)
        .insertOne(newDoc as any)
        .catch((err) => {
          console.warn(`[MongoDB Atlas] Async insert error in "${collection}":`, err.message);
        });
    }

    return newDoc;
  }

  public updateOne<T extends MongoDocument>(
    collection: keyof MongoDatabaseState,
    query: Record<string, any>,
    updates: Partial<T>
  ): T | null {
    const list = this.data[collection] as any[];
    if (!list) return null;

    const index = list.findIndex((item) => {
      for (const [k, v] of Object.entries(query)) {
        if (typeof v === 'string' && typeof item[k] === 'string') {
          if (item[k].toLowerCase() !== v.toLowerCase()) return false;
        } else if (item[k] !== v) {
          return false;
        }
      }
      return true;
    });

    if (index === -1) return null;

    const updated = {
      ...list[index],
      ...updates,
      updatedAt: new Date().toISOString(),
    };

    list[index] = updated;
    this.saveData(this.data);

    // Asynchronously update MongoDB Atlas Cloud database
    if (this.db && this.isAtlasConnected && collection !== 'system_meta') {
      const atlasFilter = list[index].id ? { id: list[index].id } : { _id: list[index]._id };
      this.db
        .collection(collection as string)
        .updateOne(atlasFilter as any, { $set: updates as any })
        .catch((err) => {
          console.warn(`[MongoDB Atlas] Async update error in "${collection}":`, err.message);
        });
    }

    return updated as T;
  }

  public deleteOne(collection: keyof MongoDatabaseState, query: Record<string, any>): boolean {
    const list = this.data[collection] as any[];
    if (!list) return false;

    const targetDoc = list.find((item) => {
      for (const [k, v] of Object.entries(query)) {
        if (item[k] === v || (typeof v === 'string' && item[k]?.toLowerCase() === v.toLowerCase())) {
          return true;
        }
      }
      return false;
    });

    const initialLength = list.length;
    this.data[collection] = list.filter((item) => {
      for (const [k, v] of Object.entries(query)) {
        if (item[k] === v || (typeof v === 'string' && item[k]?.toLowerCase() === v.toLowerCase())) {
          return false;
        }
      }
      return true;
    }) as any;

    const changed = (this.data[collection] as any[]).length < initialLength;
    if (changed) {
      this.saveData(this.data);

      // Asynchronously delete in MongoDB Atlas
      if (this.db && this.isAtlasConnected && targetDoc && collection !== 'system_meta') {
        const atlasFilter = targetDoc.id ? { id: targetDoc.id } : { _id: targetDoc._id };
        this.db
          .collection(collection as string)
          .deleteOne(atlasFilter as any)
          .catch((err) => {
            console.warn(`[MongoDB Atlas] Async delete error in "${collection}":`, err.message);
          });
      }
    }
    return changed;
  }

  public resetToSeed(): MongoDatabaseState {
    this.data = JSON.parse(JSON.stringify(INITIAL_DB_STATE));
    this.saveData(this.data);

    // Re-seed Atlas in background
    if (this.db && this.isAtlasConnected) {
      (async () => {
        const collections: CollectionName[] = [
          'users',
          'analyses',
          'reports',
          'chat_history',
          'otp_codes',
          'audit_logs',
          'soundtracks',
        ];
        for (const colName of collections) {
          try {
            await this.db!.collection(colName).deleteMany({});
            const seed = INITIAL_DB_STATE[colName];
            if (seed.length > 0) {
              await this.db!.collection(colName).insertMany(seed as any[]);
            }
          } catch (e: any) {
            console.warn(`[MongoDB Atlas] Re-seed error on ${colName}:`, e.message);
          }
        }
        console.log('[MongoDB Atlas] Remote database reset to seed dataset.');
      })();
    }

    return this.data;
  }
}

export const mongoDB = new MongoDBEngine();
