export type UserRole = 'patient' | 'doctor' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
  title?: string;
  specialization?: string;
  department?: string;
  licenseNumber?: string;
  patientId?: string;
  phone?: string;
  dateOfBirth?: string;
  bloodType?: string;
  allergies?: string[];
  hospitalAffiliation?: string;
  createdAt: string;
}

export type AnalysisModality = 
  | 'xray' 
  | 'mri' 
  | 'ct' 
  | 'ultrasound'
  | 'derm' 
  | 'face'
  | 'retinal' 
  | 'lab_report' 
  | 'pathology';

export type AnalysisStatus = 
  | 'queued' 
  | 'processing' 
  | 'completed' 
  | 'flagged' 
  | 'reviewed';

export type AnalysisUrgency = 'routine' | 'moderate' | 'urgent' | 'critical';

export interface FacialAnalysisMetrics {
  facialZone?: string;
  symmetryScore?: number; // e.g., 97.4
  cranialNerveVIIIntact?: boolean;
  skinBarrierStatus?: string;
  erythemaLevel?: 'None' | 'Mild' | 'Moderate' | 'Severe';
  erythemaSeverity?: string;
  skinBarrierHydration?: string;
  papulePustuleCount?: number;
  pigmentationHomogeneity?: string;
  sebumDistribution?: string;
  lesionDistribution?: string;
  cranialNerveStatus?: string;
  sebumOrPoreScore?: string;
  hydrationLevel?: string;
  keyRegionsEvaluated?: Array<{
    region: string;
    status: string;
    findings: string;
  }>;
}

export interface PubMedCitation {
  pmid: string;
  title: string;
  journal: string;
  year: string;
  doi?: string;
  url: string;
  evidenceLevel: string;
  keyEvidence: string;
  crossValidationMatch: string;
}

export interface RAGDoubleVerification {
  verified: boolean;
  consensusScore: number;
  evidenceSummary: string;
  ragKnowledgeBase: string;
  pubMedCitations: PubMedCitation[];
  peerReviewConsensus: string;
}

export interface ClinicalPrescriptionItem {
  medication: string;
  genericName: string;
  dosage: string;
  route: string;
  frequency: string;
  duration: string;
  indication: string;
  contraindications: string[];
  pharmacistNotes: string;
  rxType: 'Primary Rx' | 'Supportive Rx' | 'Symptomatic Relief';
}

export interface ClinicalPrecautions {
  immediateDirectives: string[];
  lifestyleAndActivity: string[];
  dietaryAndHydration: string[];
  criticalContraindications: string[];
  redFlagEmergencySymptoms: string[];
  postScanMonitoring?: string[];
}

export interface TreatmentAndManagementOptions {
  conservativeTherapy: string[];
  interventionalOrSurgical: string[];
  adjunctRehabilitation: string[];
  followUpImagingTimeline: string[];
}

export interface AnalysisRecord {
  id: string;
  title: string;
  modality: AnalysisModality;
  status: AnalysisStatus;
  urgency: AnalysisUrgency;
  patientId: string;
  patientName: string;
  doctorId?: string;
  doctorName?: string;
  submittedAt: string;
  completedAt?: string;
  symptoms?: string[];
  clinicalNotes?: string;
  fileName?: string;
  fileSize?: string;
  fileType?: string;
  primaryFindingSummary?: string;
  issueDiagnosis?: string; // Core medical issue identified
  severityLevel?: 'Mild' | 'Moderate' | 'Severe' | 'Critical';
  icd10Code?: string;
  detailedObservations?: string[]; // Step-by-step visual & structural observations
  anatomicalRegions?: string[]; // Zones inspected
  differentialDiagnosis?: string[];
  facialAnalysisMetrics?: FacialAnalysisMetrics;
  confidenceScore?: number;
  tags: string[];
  imageUrl?: string;
  beforeImageUrl?: string;
  afterImageUrl?: string;
  comparisonNotes?: string;
  treatmentOutcome?: string;
  ragVerification?: RAGDoubleVerification;
  prescriptions?: ClinicalPrescriptionItem[];
  precautions?: ClinicalPrecautions;
  treatmentOptions?: TreatmentAndManagementOptions;
}

export interface MedicalReport {
  id: string;
  reportNumber: string;
  title: string;
  category: 'Radiology' | 'Pathology' | 'Laboratory' | 'Cardiology' | 'Discharge Summary';
  patientId: string;
  patientName: string;
  physicianName: string;
  date: string;
  status: 'Final' | 'Preliminary' | 'Addendum';
  fileFormat: 'PDF' | 'DICOM' | 'DOCX';
  fileSize: string;
  department: string;
  summary: string;
  ragVerification?: RAGDoubleVerification;
  prescriptions?: ClinicalPrescriptionItem[];
  precautions?: ClinicalPrecautions;
  treatmentOptions?: TreatmentAndManagementOptions;
}

export interface ClinicalNotification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'critical' | 'success';
  timestamp: string;
  read: boolean;
  targetRole?: UserRole;
  linkTo?: string;
}

export interface LoginSession {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  timestamp: string;
  device: string;
  ipAddress: string;
  status: 'Active' | 'Closed' | 'Revoked';
  location: string;
}

export interface MedicalFacility {
  id: string;
  name: string;
  category: 'Hospital' | 'Imaging Center' | 'Diagnostic Lab' | 'Urgent Care' | 'Radiology Specialty';
  address: string;
  lat: number;
  lng: number;
  phone: string;
  emergencyPhone?: string;
  rating: number;
  reviewCount: number;
  openHours: string;
  services: string[];
  distanceKm?: number;
  estimatedDriveTimeMin?: number;
  traumaLevel?: string;
  hasEmergencyRoom?: boolean;
  isOpenNow?: boolean;
  waitTimesMin?: number;
  consultationFee?: string;
  isGovtFreeCare?: boolean;
  feeTier?: 'Free / Govt (₹0)' | 'Affordable (₹100-₹250)' | 'Private Care';
  schemeAccepted?: string[];
  bedChargesPerDay?: string;
}

export interface SoundTherapyTrack {
  id: string;
  title: string;
  userEmail?: string;
  category: 'Anxiety Relief' | 'Deep Focus' | 'Thoracic Respiration' | 'Neural Reset' | 'Custom Generated';
  baseFrequency: number;
  binauralBeatHz: number;
  durationSeconds: number;
  description: string;
  waveformType: 'sine' | 'triangle' | 'ambient';
  createdAt: string;
}

export interface Anatomy3DMarker {
  id: string;
  name: string;
  organ: 'Lungs' | 'Brain' | 'Heart' | 'Spine' | 'Liver' | 'Kidneys';
  position: [number, number, number];
  condition: 'Normal' | 'Observation' | 'Critical Finding';
  notes: string;
  modality: AnalysisModality;
}

export interface AdminSystemStats {
  activeUsers: number | string;
  totalDoctors: number;
  totalPatients: number;
  totalAnalysesToday: number;
  systemUptime: string;
  averageInferenceTime: string;
  storageUsed: string;
  apiHealthStatus: string;
}

export interface MongoDBStatus {
  status: string;
  engine: string;
  databaseName: string;
  cluster: string;
  connectionUri?: string;
  isAtlasLive?: boolean;
  latencyMs?: number;
  error?: string | null;
  collections: {
    users: number;
    analyses: number;
    reports: number;
    chat_history: number;
    otp_codes: number;
    audit_logs: number;
    soundtracks: number;
  };
  storageSizeBytes: number;
  storageFormatted: string;
  lastSyncedAt: string;
  uptimeSeconds: number;
}

export interface PrecautionChatRecord {
  id: string;
  _id?: string;
  userEmail: string;
  userRole: UserRole;
  category: string;
  question: string;
  answer: string;
  precautions?: string[];
  triageLevel?: 'critical' | 'urgent' | 'routine';
  timestamp: string;
}

export interface VitalRecord {
  id: string;
  timestamp: string;
  date: string;
  time: string;
  heartRate: number; // bpm (e.g. 72)
  systolicBp: number; // mmHg (e.g. 120)
  diastolicBp: number; // mmHg (e.g. 80)
  oxygenSaturation: number; // % (e.g. 98)
  bloodGlucose?: number; // mg/dL (e.g. 95)
  bodyTemperature?: number; // °F (e.g. 98.6)
  respiratoryRate?: number; // breaths/min (e.g. 16)
  weightKg?: number; // kg
  activityContext?: 'Resting' | 'Post-Exercise' | 'Morning Fasting' | 'Post-Meal' | 'Bedtime';
  notes?: string;
  recordedBy?: string;
  statusAlert?: 'optimal' | 'normal' | 'borderline' | 'elevated' | 'critical';
  associatedScanId?: string;
}

export type VitalMetricKey = 
  | 'all' 
  | 'heartRate' 
  | 'bloodPressure' 
  | 'oxygenSaturation' 
  | 'bloodGlucose' 
  | 'bodyTemperature' 
  | 'respiratoryRate';

export interface HealthGoal {
  id: string;
  title: string;
  current: number;
  target: number;
  unit: string;
  category: 'water' | 'steps' | 'sleep' | 'medication' | 'exercise';
  status: 'on_track' | 'needs_attention' | 'achieved';
}

export interface EmergencyTriageResponse {
  triageLevel: 'critical' | 'urgent' | 'routine';
  category: string;
  summary: string;
  immediateSteps: string[];
  avoidActions: string[];
  fullDetailedAnswer: string;
  redFlagWarnings: string[];
  recommendedEmergencyContacts: string[];
  homeRemediesAndCare?: string[];
  medicationGuidance?: string[];
  doctorConsultAdvice?: string;
  preventionTips?: string[];
}



