import { AnalysisRecord, MedicalReport, ClinicalNotification, AdminSystemStats } from '../types';

export const INITIAL_ANALYSIS_RECORDS: AnalysisRecord[] = [
  {
    id: 'MED-2025-0891',
    title: 'PA Chest Radiograph - Pneumonia Evaluation',
    modality: 'xray',
    status: 'completed',
    urgency: 'moderate',
    patientId: 'MRN-7840129',
    patientName: 'Eleanor Vance',
    doctorId: 'DOC-84920',
    doctorName: 'Dr. Sarah Jenkins, MD',
    submittedAt: '2025-02-24T14:32:00Z',
    completedAt: '2025-02-24T14:34:10Z',
    symptoms: ['Persistent productive cough (5 days)', 'Low-grade fever (38.2°C)', 'Pleuritic right chest tightness'],
    clinicalNotes: 'Evaluate for right lower lobe consolidation or pleural effusion.',
    fileName: 'cxr_pa_evance_20250224.dcm',
    fileSize: '14.2 MB',
    fileType: 'DICOM/PNG',
    primaryFindingSummary: 'Localized focal opacity noted in the right lower lobe consistent with early community-acquired bronchopneumonia. Costophrenic angles remain clear.',
    confidenceScore: 0.96,
    tags: ['Radiology', 'Thoracic', 'Infection Screen', 'PubMed Verified'],
    ragVerification: {
      verified: true,
      consensusScore: 98.4,
      evidenceSummary: 'Findings cross-validated with ATS/IDSA Guidelines for Community-Acquired Pneumonia and PubMed diagnostic radiography trials.',
      ragKnowledgeBase: 'PubMed Central (PMC) + American Thoracic Society (ATS) + ACR Appropriateness Criteria®',
      peerReviewConsensus: 'High diagnostic congruence (98.4%) across 4 peer-reviewed multicenter radiological trials.',
      pubMedCitations: [
        {
          pmid: '31573350',
          title: 'Diagnosis and Treatment of Adults with Community-acquired Pneumonia. An Official Clinical Practice Guideline of the ATS and IDSA',
          journal: 'American Journal of Respiratory and Critical Care Medicine',
          year: '2019',
          doi: '10.1164/rccm.201908-1581ST',
          url: 'https://pubmed.ncbi.nlm.nih.gov/31573350/',
          evidenceLevel: 'Level 1A (Clinical Practice Guideline)',
          keyEvidence: 'Defines standard radiographic infiltrates criterion and outpatient empirical antibiotic regimens for community-acquired pneumonia.',
          crossValidationMatch: '100% Concordant on focal consolidation marker & antimicrobial spectrum'
        },
        {
          pmid: '34488219',
          title: 'Automated Chest Radiography Interpretation in Infiltrative Lung Disease: A Multi-Institutional Validation',
          journal: 'Lancet Digital Health / PubMed Central',
          year: '2022',
          doi: '10.1016/S2589-7500(21)00155-7',
          url: 'https://pubmed.ncbi.nlm.nih.gov/34488219/',
          evidenceLevel: 'Level 1B (Multicenter Cohort Trial)',
          keyEvidence: 'Validated right basal opacity differentiation vs atelectasis with 97.2% sensitivity.',
          crossValidationMatch: '98.1% Concordance'
        }
      ]
    },
    prescriptions: [
      {
        medication: 'Amoxicillin / Clavulanate (Augmentin)',
        genericName: 'Amoxicillin + Clavulanate Potassium',
        dosage: '875 mg / 125 mg Tablet',
        route: 'Oral (PO)',
        frequency: 'Every 12 hours with meals',
        duration: '7 Days',
        indication: 'Empirical coverage for bacterial Community-Acquired Pneumonia (CAP)',
        contraindications: ['Severe Penicillin/Beta-lactam hypersensitivity', 'History of cholestatic jaundice'],
        pharmacistNotes: 'Complete the entire 7-day course. Take with food to minimize gastrointestinal distress.',
        rxType: 'Primary Rx'
      },
      {
        medication: 'Azithromycin (Zithromax Z-Pak)',
        genericName: 'Azithromycin',
        dosage: '500 mg Day 1, then 250 mg Days 2-5',
        route: 'Oral (PO)',
        frequency: 'Once daily (q24h)',
        duration: '5 Days',
        indication: 'Atypical pathogen coverage (Mycoplasma/Chlamydia pneumoniae)',
        contraindications: ['Prolonged QT interval history', 'Severe hepatic impairment'],
        pharmacistNotes: 'May be taken with or without food. Inform physician if palpitations occur.',
        rxType: 'Supportive Rx'
      },
      {
        medication: 'Guaifenesin Extended-Release (Mucinex)',
        genericName: 'Guaifenesin',
        dosage: '600 mg Tablet',
        route: 'Oral (PO)',
        frequency: 'Every 12 hours with full glass of water',
        duration: '5 to 7 Days (as needed for chest congestion)',
        indication: 'Mucolytic & expectorant for bronchopulmonary clearance',
        contraindications: ['Hypersensitivity to guaifenesin'],
        pharmacistNotes: 'Maintain copious oral fluid intake (>2.5L/day) for optimal mucus thinning.',
        rxType: 'Symptomatic Relief'
      }
    ],
    precautions: {
      immediateDirectives: [
        'Commence prescribed oral antimicrobial regimen within 2 hours of meal ingestion.',
        'Rest in semi-Fowler position (elevated 30-45 degrees) to facilitate thoracic expansion and diaphragmatic excursion.',
        'Perform incentive spirometry (10 deep inspiratory breaths every hour while awake).'
      ],
      lifestyleAndActivity: [
        'Strict bed rest during the febrile window (next 48-72 hours); avoid strenuous physical exertion.',
        'Avoid exposure to secondhand cigarette smoke, cooking fumes, wood smoke, and cold dry drafts.',
        'Use a room cool-mist humidifier to lubricate upper airway passages.'
      ],
      dietaryAndHydration: [
        'Maintain oral hydration of 2.5 to 3.0 Liters/day (warm water, herbal broths, electrolyte fluids).',
        'Consume high-protein, nutrient-dense soft meals (lentils, steamed vegetables, lean poultry, warm soups).',
        'Avoid iced or heavily carbonated drinks which may provoke broncho-spasms.'
      ],
      criticalContraindications: [
        'DO NOT take OTC antitussives (cough suppressants like dextromethorphan) without doctor approval, as clearing phlegm is crucial.',
        'DO NOT skip doses or discontinue antibiotics early even if symptoms improve on Day 3.'
      ],
      redFlagEmergencySymptoms: [
        'Sudden acute shortness of breath or resting respiratory rate > 26 breaths/min.',
        'Peripheral cyanosis (bluish tint around lips, nail beds, or tongue).',
        'Confusion, extreme lethargy, or inability to stay awake (hypoxia indicator).',
        'Oxygen saturation (SpO2) dropping below 92% on pulse oximeter.'
      ],
      postScanMonitoring: [
        'Monitor body temperature and SpO2 every 4 hours.',
        'Schedule clinical re-evaluation if fever persists beyond 72 hours of antimicrobial initiation.'
      ]
    },
    treatmentOptions: {
      conservativeTherapy: [
        'Outpatient targeted oral antimicrobial therapy (Augmentin + Azithromycin).',
        'Supportive antipyretic therapy with Acetaminophen (500mg q6h PRN for fever > 38.5°C).',
        'Warm steam inhalation and postural chest percussion.'
      ],
      interventionalOrSurgical: [
        'If clinical deterioration occurs, hospital admission for IV Ceftriaxone + Azithromycin and supplemental oxygen.',
        'Diagnostic thoracentesis only indicated if significant parapneumonic effusion develops (>10mm on decubitus film).'
      ],
      adjunctRehabilitation: [
        'Diaphragmatic breathing exercises & thoracic expansion loops.',
        'Targeted 432 Hz / 528 Hz pulmonary harmonic sound therapy for anxiety and parasympathetic activation.'
      ],
      followUpImagingTimeline: [
        'Repeat PA/Lateral chest radiograph at 6-8 weeks post-treatment to verify complete radiologic resolution and rule out underlying endobronchial lesions.'
      ]
    }
  },
  {
    id: 'MED-2025-0890',
    title: 'Brain MRI T1/T2 FLAIR - Cephalea & Vertigo',
    modality: 'mri',
    status: 'reviewed',
    urgency: 'routine',
    patientId: 'MRN-9941021',
    patientName: 'Marcus Aurel',
    doctorId: 'DOC-84920',
    doctorName: 'Dr. Sarah Jenkins, MD',
    submittedAt: '2025-02-23T11:15:00Z',
    completedAt: '2025-02-23T11:18:45Z',
    symptoms: ['Episodic tension headaches', 'Intermittent lightheadedness', 'No focal neuro deficits'],
    clinicalNotes: 'Rule out intracranial mass or microvascular ischemia.',
    fileName: 'brain_mri_flair_0890.nii',
    fileSize: '42.8 MB',
    fileType: 'NIfTI/DICOM',
    primaryFindingSummary: 'No acute intracranial hemorrhage, mass effect, or midline shift. Ventricles and sulci are unremarkable for age.',
    confidenceScore: 0.98,
    tags: ['Neurology', 'Brain MRI', 'Normal Study', 'PubMed Verified'],
    ragVerification: {
      verified: true,
      consensusScore: 99.2,
      evidenceSummary: 'Cross-referenced against ACR Appropriateness Criteria® for Headache and Neuroimaging Cochrane Reviews.',
      ragKnowledgeBase: 'PubMed Central (PMC) + American Academy of Neurology (AAN) + ACR Appropriateness Criteria®',
      peerReviewConsensus: 'Full concordance across published neurological guidelines confirming absence of secondary intracranial etiology.',
      pubMedCitations: [
        {
          pmid: '31880922',
          title: 'ACR Appropriateness Criteria® Headache: Comprehensive Neuroimaging Protocol Review',
          journal: 'Journal of the American College of Radiology',
          year: '2020',
          doi: '10.1016/j.jacr.2019.05.018',
          url: 'https://pubmed.ncbi.nlm.nih.gov/31880922/',
          evidenceLevel: 'Level 1A (National Clinical Practice Guideline)',
          keyEvidence: 'Brain MRI with FLAIR sequences reliably excludes secondary etiologies including mass lesions, aneurysms, and acute ischemic changes.',
          crossValidationMatch: '100% Concordant'
        }
      ]
    },
    prescriptions: [
      {
        medication: 'Magnesium Glycinate',
        genericName: 'Chelated Magnesium Glycinate',
        dosage: '400 mg Capsule',
        route: 'Oral (PO)',
        frequency: 'Once daily at bedtime',
        duration: '60 Days',
        indication: 'Neurovascular prophylaxis for tension headaches and vestibular relaxation',
        contraindications: ['Severe renal failure (GFR < 30 mL/min)'],
        pharmacistNotes: 'Take with evening meal or before sleep. Very low gastrointestinal laxative effect.',
        rxType: 'Primary Rx'
      },
      {
        medication: 'Coenzyme Q10 (Ubiquinol)',
        genericName: 'Ubiquinol',
        dosage: '100 mg Softgel',
        route: 'Oral (PO)',
        frequency: 'Once daily with breakfast',
        duration: '60 Days',
        indication: 'Mitochondrial and cellular support for tension cephalea',
        contraindications: ['Known hypersensitivity'],
        pharmacistNotes: 'Fat-soluble antioxidant; take with a meal containing dietary lipids.',
        rxType: 'Supportive Rx'
      },
      {
        medication: 'Naproxen Sodium (Aleve)',
        genericName: 'Naproxen Sodium',
        dosage: '220 mg Tablet',
        route: 'Oral (PO)',
        frequency: '1 tablet every 8-12 hours as needed for acute headache',
        duration: 'PRN (Do not exceed 3 days per week to avoid medication overuse headache)',
        indication: 'Acute symptomatic relief of episodic tension headache',
        contraindications: ['Active peptic ulcer', 'History of GI bleeding', 'Severe renal impairment'],
        pharmacistNotes: 'Always take with food or milk to protect stomach lining.',
        rxType: 'Symptomatic Relief'
      }
    ],
    precautions: {
      immediateDirectives: [
        'Maintain a detailed 30-day Headache & Sleep Diary logging triggers (caffeine, screen time, dehydration).',
        'Practice cervical spine postural resets every 45 minutes during computer work.'
      ],
      lifestyleAndActivity: [
        'Maintain consistent sleep schedule (7-8 hours/night); avoid irregular sleep-wake cycles.',
        'Incorporate 20-30 minutes of low-impact aerobic exercise (walking, swimming) 4 times weekly.'
      ],
      dietaryAndHydration: [
        'Maintain regular hydration of at least 2.0 to 2.5 Liters/day.',
        'Limit excessive dietary triggers: artificial sweeteners (aspartame), MSG, aged cheeses, and excess red wine.'
      ],
      criticalContraindications: [
        'AVOID daily OTC analgesic overuse (>10 days/month) to prevent medication-overuse rebound headaches.'
      ],
      redFlagEmergencySymptoms: [
        'Sudden "thunderclap" headache reaching maximal intensity in < 60 seconds.',
        'New focal weakness, facial drooping, speech difficulty, or visual field loss.',
        'Headache accompanied by stiff neck, high fever, or altered consciousness.'
      ],
      postScanMonitoring: [
        'Routine follow-up in 8-12 weeks with neurologist or primary care clinician if headache frequency alters.'
      ]
    },
    treatmentOptions: {
      conservativeTherapy: [
        'Trigger avoidance and ergonomic posture adjustments.',
        'Magnesium and riboflavin (Vitamin B2 400mg) supplementation.',
        'Cognitive behavioral stress reduction and mindfulness meditation.'
      ],
      interventionalOrSurgical: [
        'Not indicated. Scan demonstrates completely benign intracranial structures.'
      ],
      adjunctRehabilitation: [
        'Physical therapy for cervical spine mobilization and suboccipital trigger point release.',
        'Binaural alpha/theta wave sound therapy for central nervous system calming.'
      ],
      followUpImagingTimeline: [
        'No repeat neuroimaging needed unless new progressive neurological deficits develop.'
      ]
    }
  },
  {
    id: 'MED-2025-0889',
    title: 'Dermoscopy - Pigmented Cutaneous Lesion',
    modality: 'derm',
    status: 'flagged',
    urgency: 'urgent',
    patientId: 'MRN-4309182',
    patientName: 'David Chen',
    doctorId: 'DOC-84920',
    doctorName: 'Dr. Sarah Jenkins, MD',
    submittedAt: '2025-02-22T09:40:00Z',
    completedAt: '2025-02-22T09:42:15Z',
    symptoms: ['Asymmetrical pigmented macule on left scapula', 'Reported recent border alteration and darkening'],
    clinicalNotes: 'High suspicion ABCDE criteria, recommended immediate biopsy correlation.',
    fileName: 'derm_lesion_scapula_4309.jpg',
    fileSize: '8.4 MB',
    fileType: 'High-Res JPEG',
    primaryFindingSummary: 'Atypical pigment network with focal pseudopods and peripheral irregular dots. Flagged for urgent dermatologist punch / excisional biopsy.',
    confidenceScore: 0.95,
    tags: ['Dermatology', 'Melanocytic', 'Biopsy Recommended', 'PubMed Verified'],
    ragVerification: {
      verified: true,
      consensusScore: 97.8,
      evidenceSummary: 'Correlated with American Academy of Dermatology (AAD) Melanoma Guidelines and PubMed dermoscopy criteria.',
      ragKnowledgeBase: 'PubMed Central (PMC) + National Comprehensive Cancer Network (NCCN) Guidelines + JAAD',
      peerReviewConsensus: 'Strong consensus (97.8%) recommending complete narrow-margin excisional biopsy for definitive histopathology.',
      pubMedCitations: [
        {
          pmid: '30414704',
          title: 'Guidelines of Care for the Management of Primary Cutaneous Melanoma',
          journal: 'Journal of the American Academy of Dermatology (JAAD)',
          year: '2019',
          doi: '10.1016/j.jaad.2018.08.055',
          url: 'https://pubmed.ncbi.nlm.nih.gov/30414704/',
          evidenceLevel: 'Level 1A (Clinical Practice Guideline)',
          keyEvidence: 'Establishes full-thickness excisional biopsy with 1-3 mm margins as the gold standard for atypical dermoscopic lesions.',
          crossValidationMatch: '100% Concordance on biopsy protocol'
        }
      ]
    },
    prescriptions: [
      {
        medication: 'Mupirocin 2% Topical Ointment (Bactroban)',
        genericName: 'Mupirocin Ointment',
        dosage: 'Apply thin layer to site post-biopsy',
        route: 'Topical',
        frequency: 'Twice daily after cleaning',
        duration: '7 to 10 Days post-procedure',
        indication: 'Prophylactic antibacterial coverage for skin biopsy site',
        contraindications: ['Hypersensitivity to mupirocin'],
        pharmacistNotes: 'For external cutaneous use only. Cover with sterile non-stick bandage.',
        rxType: 'Primary Rx'
      },
      {
        medication: 'Broad-Spectrum Mineral Sunscreen SPF 50+',
        genericName: 'Zinc Oxide 20% + Titanium Dioxide',
        dosage: 'Generous application',
        route: 'Topical',
        frequency: 'Every 2 hours during daylight exposure',
        duration: 'Continuous daily preventive care',
        indication: 'UV-A / UV-B photodamage prevention for remaining cutaneous surface',
        contraindications: ['None'],
        pharmacistNotes: 'Apply 15 minutes before sun exposure.',
        rxType: 'Supportive Rx'
      }
    ],
    precautions: {
      immediateDirectives: [
        'Schedule urgent in-person dermatology evaluation within 5-7 business days for full-thickness excisional biopsy.',
        'Avoid scratching, picking, or rubbing the pigmented lesion.'
      ],
      lifestyleAndActivity: [
        'Avoid direct sunlight exposure between 10:00 AM and 4:00 PM; wear UV-protective clothing (UPF 50+).',
        'Avoid tanning beds and artificial UV radiation completely.'
      ],
      dietaryAndHydration: [
        'Maintain balanced antioxidant-rich Mediterranean diet rich in carotenoids and polyphenols.'
      ],
      criticalContraindications: [
        'DO NOT attempt OTC wart/mole removal creams, chemical peels, or cryotherapy on pigmented lesions before biopsy.'
      ],
      redFlagEmergencySymptoms: [
        'Rapid spontaneous bleeding, ulceration, or oozing from the lesion.',
        'Rapid satellite pigmentation or enlargement > 6mm.'
      ],
      postScanMonitoring: [
        'Monthly full-body cutaneous self-examination using the ABCDE method.'
      ]
    },
    treatmentOptions: {
      conservativeTherapy: [
        'Photographic dermoscopic monitoring of non-suspicious baseline lesions.'
      ],
      interventionalOrSurgical: [
        'Excisional biopsy with 1-3 mm margins and subcutaneous fat inclusion for histological Breslow depth staging.',
        'Wide local excision if histopathology confirms melanoma in situ or invasive melanoma.'
      ],
      adjunctRehabilitation: [
        'Dermatologic total-body skin mapping.'
      ],
      followUpImagingTimeline: [
        'Dermatology clinical review in 1 week post-biopsy for histopathology disclosure and suture removal.'
      ]
    }
  }
];

export const INITIAL_MEDICAL_REPORTS: MedicalReport[] = [
  {
    id: 'REP-2025-01',
    reportNumber: 'RAD-77102',
    title: 'Thoracic Diagnostic Radiology Summary',
    category: 'Radiology',
    patientId: 'MRN-7840129',
    patientName: 'Eleanor Vance',
    physicianName: 'Dr. Sarah Jenkins, MD',
    date: '2025-02-24',
    status: 'Final',
    fileFormat: 'PDF',
    fileSize: '1.4 MB',
    department: 'Cardiothoracic Imaging',
    summary: 'Single view PA chest radiograph demonstrating localized infiltrates in right basal lobe consistent with bronchopneumonia. Costophrenic angles clear. No pneumothorax.',
    ragVerification: {
      verified: true,
      consensusScore: 98.4,
      evidenceSummary: 'Validated with American Thoracic Society guidelines and PubMed diagnostic radiology literature.',
      ragKnowledgeBase: 'PubMed Central (PMC) + ATS + ACR Appropriateness Criteria®',
      peerReviewConsensus: 'Concordant on right lower lobe consolidation with high specificity.',
      pubMedCitations: [
        {
          pmid: '31573350',
          title: 'ATS/IDSA Clinical Practice Guidelines for Community-Acquired Pneumonia',
          journal: 'Am J Respir Crit Care Med',
          year: '2019',
          url: 'https://pubmed.ncbi.nlm.nih.gov/31573350/',
          evidenceLevel: 'Level 1A',
          keyEvidence: 'Standard empirical outpatient antimicrobials Augmentin + Macrolide.',
          crossValidationMatch: '100% Match'
        }
      ]
    },
    prescriptions: [
      {
        medication: 'Amoxicillin / Clavulanate (Augmentin)',
        genericName: 'Amoxicillin + Clavulanate',
        dosage: '875/125 mg',
        route: 'Oral',
        frequency: 'q12h with meals',
        duration: '7 Days',
        indication: 'Community-acquired pneumonia',
        contraindications: ['Penicillin allergy'],
        pharmacistNotes: 'Take with food to minimize GI upset.',
        rxType: 'Primary Rx'
      }
    ],
    precautions: {
      immediateDirectives: ['Take antibiotic on schedule', 'Maintain semi-Fowler resting position'],
      lifestyleAndActivity: ['Strict bed rest for 48 hours', 'Avoid all smoke and vape exposure'],
      dietaryAndHydration: ['Hydrate with 2.5L+ fluids daily', 'Nutritious warm soups and broths'],
      criticalContraindications: ['Do not suppress productive cough with high-dose antitussives'],
      redFlagEmergencySymptoms: ['SpO2 below 92%', 'Severe shortness of breath', 'Chest pain radiating to arm'],
      postScanMonitoring: ['Check temperature and SpO2 every 4 hours']
    },
    treatmentOptions: {
      conservativeTherapy: ['Outpatient oral antibiotics', 'Supportive hydration and antipyretics'],
      interventionalOrSurgical: ['IV antibiotics if clinical deterioration occurs'],
      adjunctRehabilitation: ['Incentive spirometry and diaphragmatic breathing'],
      followUpImagingTimeline: ['Follow-up chest X-ray at 6 weeks post-treatment']
    }
  }
];

export const INITIAL_NOTIFICATIONS: ClinicalNotification[] = [
  {
    id: 'notif-1',
    title: 'Urgent Case Flagged & PubMed RAG Verified',
    message: 'Cutaneous lesion for Patient David Chen flagged with high risk score (JAAD / PubMed validated).',
    type: 'critical',
    timestamp: '10 mins ago',
    read: false,
  },
  {
    id: 'notif-2',
    title: 'Scan Analysis Completed & Double-Verified',
    message: 'PA Chest Radiograph for Eleanor Vance completed with 96% confidence and PubMed RAG consensus.',
    type: 'success',
    timestamp: '1 hour ago',
    read: false,
  },
  {
    id: 'notif-3',
    title: 'Clinical Knowledgebase Synced',
    message: 'PubMed Central & ACR Appropriateness Criteria database updated with 2025 guidelines.',
    type: 'info',
    timestamp: 'Yesterday',
    read: true,
  },
];

export const INITIAL_ADMIN_STATS: AdminSystemStats = {
  activeUsers: 142,
  totalDoctors: 38,
  totalPatients: 104,
  totalAnalysesToday: 87,
  systemUptime: '99.98%',
  averageInferenceTime: '1.42s',
  storageUsed: '342.6 GB / 2 TB',
  apiHealthStatus: 'Healthy (PubMed RAG Engine Online)',
};
