import React, { useState } from 'react';
import { 
  FileText, 
  Search, 
  Download, 
  Eye, 
  Filter, 
  Calendar, 
  User, 
  Building2, 
  FileCheck, 
  X, 
  FileSpreadsheet, 
  Plus,
  Printer,
  Sparkles,
  Stethoscope,
  Pill,
  HeartPulse,
  AlertTriangle,
  CheckCircle2,
  BookOpen,
  Layers,
  ArrowRight
} from 'lucide-react';
import { INITIAL_MEDICAL_REPORTS } from '../../data/mockData';
import { MedicalReport, AnalysisRecord } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { EmptyState } from '../common/EmptyState';
import { LoadingSkeletonTable } from '../common/LoadingSkeleton';
import { PrintReportModal } from './PrintReportModal';

interface MedicalReportsViewProps {
  onNavigateToNewAnalysis: () => void;
}

export const MedicalReportsView: React.FC<MedicalReportsViewProps> = ({
  onNavigateToNewAnalysis,
}) => {
  const { user, userAnalyses, allAnalyses } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activeReportModal, setActiveReportModal] = useState<MedicalReport | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Print Modal state
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [reportToPrint, setReportToPrint] = useState<MedicalReport | null>(null);
  const [analysisToPrint, setAnalysisToPrint] = useState<AnalysisRecord | null>(null);

  const categories = ['All', 'Radiology', 'Pathology', 'Laboratory', 'Cardiology', 'Discharge Summary'];

  const combinedAnalyses = user?.role === 'admin' ? allAnalyses : (userAnalyses.length > 0 ? userAnalyses : allAnalyses);

  const filteredReports = INITIAL_MEDICAL_REPORTS.filter((report) => {
    const matchesCategory = selectedCategory === 'All' || report.category === selectedCategory;
    const matchesSearch =
      report.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      report.reportNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      report.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      report.physicianName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      report.department.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleOpenPrintForReport = (report: MedicalReport, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setReportToPrint(report);
    setAnalysisToPrint(null);
    setIsPrintModalOpen(true);
  };

  const handleOpenPrintDossier = () => {
    setReportToPrint(null);
    setAnalysisToPrint(null);
    setIsPrintModalOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 rounded-3xl bg-white border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-slate-800 tracking-tight">
              Medical Documentation & Clinical Reports
            </h2>
            <span className="px-2.5 py-0.5 text-xs font-semibold text-blue-700 bg-blue-50 border border-blue-200 rounded-lg">
              {filteredReports.length} Available
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1 max-w-2xl leading-relaxed">
            Standardized clinical records, hospital diagnostic summaries, and professional vector PDF export engine with structured treatment plans.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {/* Print Dossier / PDF Button */}
          <button
            onClick={handleOpenPrintDossier}
            className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-sm transition-all cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>Print to PDF (Patient Dossier)</span>
          </button>

          <button
            onClick={onNavigateToNewAnalysis}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Upload Document</span>
          </button>
        </div>
      </div>

      {/* Filter & Category Bar */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-2xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search reports by report ID, test title, physician, patient, department..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50/60 focus:bg-white focus:outline-none focus:border-blue-500 font-medium"
            />
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Reports List */}
      {isLoading ? (
        <LoadingSkeletonTable rows={4} />
      ) : filteredReports.length === 0 ? (
        <EmptyState
          title="No Clinical Reports Found"
          description="No medical documents match your current filter. Try resetting search criteria or upload a new PDF / lab document."
          actionText="Upload Medical Report"
          onAction={onNavigateToNewAnalysis}
          secondaryActionText="Reset Search"
          onSecondaryAction={() => {
            setSearchQuery('');
            setSelectedCategory('All');
          }}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredReports.map((report) => (
            <div
              key={report.id}
              onClick={() => setActiveReportModal(report)}
              className="p-5 rounded-3xl border border-slate-200 bg-white hover:border-blue-300 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-[11px] font-mono font-bold text-blue-700 bg-blue-50 px-2.5 py-0.5 rounded-lg border border-blue-200">
                    {report.reportNumber}
                  </span>
                  <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                    {report.status}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-slate-900 line-clamp-1 group-hover:text-blue-600 transition-colors">
                  {report.title}
                </h3>

                <p className="text-xs text-slate-600 mt-1.5 line-clamp-2 leading-relaxed">
                  {report.summary}
                </p>

                <div className="mt-3.5 grid grid-cols-2 gap-2 text-[11px] text-slate-500 bg-slate-50/80 p-3 rounded-2xl border border-slate-100">
                  <div>
                    <span className="block text-[10px] font-bold uppercase text-slate-400">Patient</span>
                    <span className="font-bold text-slate-800 truncate block">{report.patientName}</span>
                  </div>
                  <div>
                    <span className="block text-[10px] font-bold uppercase text-slate-400">Physician</span>
                    <span className="font-bold text-slate-800 truncate block">{report.physicianName}</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3.5 border-t border-slate-100 flex items-center justify-between text-[11px]">
                <span className="flex items-center gap-1.5 font-medium text-slate-500">
                  <FileText className="w-3.5 h-3.5 text-blue-600" />
                  <span>{report.fileFormat} &bull; {report.fileSize}</span>
                </span>

                <div className="flex items-center gap-2">
                  {/* Quick Print to PDF button on each card */}
                  <button
                    onClick={(e) => handleOpenPrintForReport(report, e)}
                    className="px-2.5 py-1 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-[11px] flex items-center gap-1 border border-blue-200 transition-colors cursor-pointer"
                    title="Print report to PDF"
                  >
                    <Printer className="w-3 h-3 text-blue-600" />
                    <span>Print to PDF</span>
                  </button>

                  <span className="text-xs font-bold text-slate-700 flex items-center gap-1 hover:text-blue-600">
                    <Eye className="w-3.5 h-3.5" />
                    <span>Preview</span>
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Report Summary Modal */}
      {activeReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-3xl bg-white border border-slate-200 shadow-2xl space-y-0">
            
            {/* Modal Header */}
            <div className="sticky top-0 z-10 flex items-center justify-between p-5 border-b border-slate-200 bg-white/95 backdrop-blur-md">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center border border-blue-200">
                  <FileCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-slate-900">
                    {activeReportModal.title}
                  </h3>
                  <span className="text-xs text-slate-500 font-mono">
                    Ref: {activeReportModal.reportNumber} &bull; {activeReportModal.department}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setActiveReportModal(null)}
                className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 space-y-5 text-xs">
              
              {/* Demographics & Metadata */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 bg-slate-50 rounded-2xl border border-slate-200">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Patient</span>
                  <span className="font-bold text-slate-900">{activeReportModal.patientName}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Department</span>
                  <span className="font-bold text-slate-800">{activeReportModal.department}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Date of Record</span>
                  <span className="font-bold text-slate-800">{activeReportModal.date}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Status</span>
                  <span className="font-bold text-emerald-700">{activeReportModal.status} Verified</span>
                </div>
              </div>

              {/* Executive Summary */}
              <div>
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <Stethoscope className="w-4 h-4 text-blue-600" />
                  <span>Executive Clinical Findings</span>
                </h4>
                <p className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-slate-800 leading-relaxed font-medium">
                  {activeReportModal.summary}
                </p>
              </div>

              {/* Prescriptions & Management Plan if available */}
              {activeReportModal.prescriptions && activeReportModal.prescriptions.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <Pill className="w-4 h-4 text-emerald-600" />
                    <span>Prescribed Pharmacotherapy:</span>
                  </h4>
                  <div className="space-y-1.5">
                    {activeReportModal.prescriptions.map((rx, idx) => (
                      <div key={idx} className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-200 flex items-center justify-between text-xs">
                        <div>
                          <div className="font-bold text-slate-900">{rx.medication} ({rx.dosage})</div>
                          <div className="text-[11px] text-slate-600">{rx.frequency} &bull; {rx.duration} &bull; {rx.indication}</div>
                        </div>
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-600 text-white">
                          {rx.rxType}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* PDF Document Print Banner */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="space-y-0.5">
                  <div className="font-bold text-blue-900 flex items-center gap-1.5">
                    <Printer className="w-4 h-4 text-blue-600" />
                    <span>Professional Vector PDF Document Ready</span>
                  </div>
                  <p className="text-[11px] text-blue-700">
                    Export full hospital letterhead, diagnostic imaging history, structured prescriptions, precautions, and physician sign-off.
                  </p>
                </div>

                <button
                  onClick={() => {
                    setActiveReportModal(null);
                    handleOpenPrintForReport(activeReportModal);
                  }}
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer shrink-0"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Open Print & PDF Layout</span>
                </button>
              </div>

            </div>

            {/* Modal Footer */}
            <div className="sticky bottom-0 p-4 border-t border-slate-200 bg-white flex items-center justify-between">
              <span className="text-[11px] text-slate-500 font-medium">
                Format: {activeReportModal.fileFormat} ({activeReportModal.fileSize})
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setActiveReportModal(null);
                    handleOpenPrintForReport(activeReportModal);
                  }}
                  className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl cursor-pointer flex items-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print to PDF</span>
                </button>
                <button
                  onClick={() => setActiveReportModal(null)}
                  className="px-4 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Complete Print & PDF Export Modal Engine */}
      {isPrintModalOpen && (
        <PrintReportModal
          report={reportToPrint}
          patientRecord={analysisToPrint}
          allPatientRecords={combinedAnalyses}
          onClose={() => {
            setIsPrintModalOpen(false);
            setReportToPrint(null);
            setAnalysisToPrint(null);
          }}
        />
      )}
    </div>
  );
};
