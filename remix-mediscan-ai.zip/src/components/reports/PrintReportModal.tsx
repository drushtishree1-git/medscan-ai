import React, { useState, useRef, useEffect } from 'react';
import { 
  X, 
  Printer, 
  Download, 
  Copy, 
  Check, 
  FileText, 
  ShieldCheck, 
  User, 
  Calendar, 
  Building2, 
  Stethoscope, 
  Pill, 
  AlertTriangle, 
  CheckCircle2, 
  BookOpen, 
  QrCode, 
  Sparkles,
  SlidersHorizontal,
  FileCheck,
  Activity,
  Layers,
  HeartPulse,
  Clock,
  Award,
  Phone,
  Mail,
  MapPin,
  Plus,
  Trash2,
  PlusCircle,
  RotateCcw
} from 'lucide-react';
import { MedicalReport, AnalysisRecord, ClinicalPrescriptionItem } from '../../types';
import { useAuth } from '../../context/AuthContext';

interface PrintReportModalProps {
  report?: MedicalReport | null;
  patientRecord?: AnalysisRecord | null;
  allPatientRecords?: AnalysisRecord[];
  onClose: () => void;
}

// Fallback high-grade clinical prescriptions generator when record lacks Rx
const generateClinicalPrescriptions = (
  modality?: string,
  title?: string,
  symptoms?: string[]
): ClinicalPrescriptionItem[] => {
  const mod = (modality || '').toLowerCase();
  const t = (title || '').toLowerCase();
  const symp = (symptoms || []).join(' ').toLowerCase();

  const isFace = mod === 'face' || t.includes('face') || t.includes('facial') || t.includes('acne') || t.includes('rosacea') || symp.includes('face') || symp.includes('facial') || symp.includes('acne') || symp.includes('rosacea');
  const isDerm = mod === 'derm' || t.includes('derm') || t.includes('lesion') || t.includes('skin') || symp.includes('pigment');
  const isBrain = mod === 'mri' || mod === 'ct' || t.includes('brain') || t.includes('neuro') || t.includes('cephalea') || symp.includes('headache');
  const isAbdomen = mod === 'ultrasound' || t.includes('abdomen') || t.includes('pelvis') || symp.includes('abdominal');

  if (isFace) {
    return [
      {
        medication: 'Azelaic Acid 15% Topical Gel (Finacea)',
        genericName: 'Azelaic Acid 150 mg/g Gel',
        dosage: 'Pea-sized amount to facial regions',
        route: 'Topical (Facial Cutaneous)',
        frequency: 'Twice daily (Morning & Night) after gentle washing',
        duration: '8 - 12 Weeks',
        indication: 'Anti-inflammatory, comedolytic, and erythema reduction for facial papulopustular dermatosis',
        contraindications: ['Known hypersensitivity to azelaic acid or propylene glycol vehicle'],
        pharmacistNotes: 'Apply to clean, dry facial skin. Mild transient tingling may occur during initial 7 days.',
        rxType: 'Primary Rx'
      },
      {
        medication: 'Doxycycline Monohydrate (Oracea / Vibramycin)',
        genericName: 'Doxycycline 40 mg Modified-Release Capsule',
        dosage: '40 mg Capsule (Anti-inflammatory sub-antimicrobial dose)',
        route: 'Oral (PO)',
        frequency: 'Once daily in the morning with a full glass of water',
        duration: '30 Days',
        indication: 'Systemic cytokine & matrix metalloproteinase inhibition for facial inflammatory lesions',
        contraindications: ['Pregnancy / Nursing', 'Severe hepatic disease', 'Children under 8 years'],
        pharmacistNotes: 'Take with full glass of water; remain upright for at least 30 minutes to prevent esophageal irritation.',
        rxType: 'Supportive Rx'
      },
      {
        medication: 'Ceramide-Dominant Barrier Restorative Emulsion',
        genericName: 'Lipid Matrix Restorative Complex (Ceramides 1/3/6-II + Hyaluronic Acid)',
        dosage: 'Liberal layer over entire face and neck',
        route: 'Topical (Cutaneous)',
        frequency: 'Twice daily after medicated gel',
        duration: 'Continuous Daily Skincare',
        indication: 'Stratum corneum lipid replenishment, transepidermal water loss reduction, and epidermal barrier protection',
        contraindications: ['None reported'],
        pharmacistNotes: 'Non-comedogenic, fragrance-free formula. Apply within 3 minutes of washing face.',
        rxType: 'Symptomatic Relief'
      },
      {
        medication: 'Broad-Spectrum Mineral Sunscreen SPF 50+ (Zinc Oxide 12%)',
        genericName: 'Micronized Zinc Oxide 12% + Titanium Dioxide',
        dosage: 'Apply evenly over entire exposed facial skin',
        route: 'Topical (Cutaneous)',
        frequency: 'Every morning; reapply every 2 hours if outdoors',
        duration: 'Daily Continuous Photoprotection',
        indication: 'UV-A / UV-B barrier protection against photo-induced vasodilatory flushing and pigmentation',
        contraindications: ['None'],
        pharmacistNotes: 'Essential preventative therapy for facial erythema and post-inflammatory hyperpigmentation.',
        rxType: 'Supportive Rx'
      }
    ];
  }

  if (isDerm) {
    return [
      {
        medication: 'Mupirocin 2% Topical Ointment (Bactroban)',
        genericName: 'Mupirocin 20 mg/g Ointment',
        dosage: 'Apply thin film to biopsy / lesion perimeter',
        route: 'Topical (Cutaneous)',
        frequency: 'Twice daily (q12h) after gentle antiseptic cleansing',
        duration: '7 to 10 Days post-procedure',
        indication: 'Prophylactic broad-spectrum antimicrobial barrier for skin lesion / biopsy site',
        contraindications: ['Hypersensitivity to mupirocin or polyethylene glycol vehicles'],
        pharmacistNotes: 'For external cutaneous use only. Cover with sterile non-adherent dressing.',
        rxType: 'Primary Rx'
      },
      {
        medication: 'Broad-Spectrum Mineral Sunscreen SPF 50+ (Zinc Oxide 20%)',
        genericName: 'Micronized Zinc Oxide 20% + Titanium Dioxide',
        dosage: 'Generous full-coverage application (2 mg/cm²)',
        route: 'Topical (Cutaneous)',
        frequency: 'Apply every 2 hours during daylight exposure',
        duration: 'Continuous daily photoprotection',
        indication: 'High-potency UV-A / UV-B photodamage prevention for vulnerable cutaneous tissue',
        contraindications: ['Known hypersensitivity to physical sunscreens'],
        pharmacistNotes: 'Apply 15 minutes prior to outdoor sun exposure; reapply after excessive perspiration.',
        rxType: 'Supportive Rx'
      }
    ];
  }

  if (isBrain) {
    return [
      {
        medication: 'Acetaminophen / Caffeine (Excedrin Tension)',
        genericName: 'Acetaminophen 500 mg + Caffeine 65 mg',
        dosage: '500 mg / 65 mg Film-Coated Tablet',
        route: 'Oral (PO)',
        frequency: '1 tablet every 8 hours as needed for tension cephalea',
        duration: '5 Days (PRN)',
        indication: 'Acute tension headache & central neurovascular pain modulation',
        contraindications: ['Severe hepatic impairment', 'Active cardiac arrhythmia'],
        pharmacistNotes: 'Do not exceed 3,000 mg acetaminophen per 24 hours. Avoid concurrent dietary caffeine excess.',
        rxType: 'Primary Rx'
      },
      {
        medication: 'Sumatriptan Succinate',
        genericName: 'Sumatriptan 50 mg',
        dosage: '50 mg Tablet',
        route: 'Oral (PO)',
        frequency: '1 tablet at earliest onset of severe migraine episode (may repeat after 2h if needed)',
        duration: 'PRN (Max 200 mg / 24 hrs)',
        indication: 'Acute treatment of migraine attacks with or without aura',
        contraindications: ['Ischemic coronary artery disease', 'Uncontrolled arterial hypertension'],
        pharmacistNotes: 'Take immediately at the onset of migraine symptoms. Rest in a darkened, quiet room.',
        rxType: 'Supportive Rx'
      },
      {
        medication: 'Ondansetron (Zofran ODT)',
        genericName: 'Ondansetron 4 mg',
        dosage: '4 mg Orally Disintegrating Tablet',
        route: 'Oral (Sublingual / PO)',
        frequency: '1 tablet every 8 hours PRN for cephalalgia-induced nausea',
        duration: '3 Days (PRN)',
        indication: 'Symptomatic control of migraine-associated nausea and gastrointestinal distress',
        contraindications: ['Congenital long QT syndrome', 'Concurrent apomorphine administration'],
        pharmacistNotes: 'Place tablet on tongue and allow to dissolve completely; swallow with saliva without water.',
        rxType: 'Symptomatic Relief'
      }
    ];
  }

  if (isAbdomen) {
    return [
      {
        medication: 'Hyoscine Butylbromide (Buscopan)',
        genericName: 'Hyoscine-N-Butylbromide 10 mg',
        dosage: '10 mg Tablet',
        route: 'Oral (PO)',
        frequency: '1 tablet three times daily before meals as needed for visceral spasm',
        duration: '5 Days',
        indication: 'Spasmolysis of smooth muscles in gastrointestinal, biliary, and genitourinary tracts',
        contraindications: ['Myasthenia gravis', 'Untreated narrow-angle glaucoma', 'Paralytic ileus'],
        pharmacistNotes: 'Take 15-30 minutes prior to meals. May cause mild transient dry mouth.',
        rxType: 'Primary Rx'
      },
      {
        medication: 'Omeprazole Delayed-Release (Prilosec)',
        genericName: 'Omeprazole 20 mg Delayed-Release',
        dosage: '20 mg Enteric-Coated Capsule',
        route: 'Oral (PO)',
        frequency: 'Once daily in the morning 30 minutes before breakfast',
        duration: '14 Days',
        indication: 'Gastric acid suppression, mucosal cytoprotection, and reflux prophylaxis',
        contraindications: ['Known hypersensitivity to proton pump inhibitors'],
        pharmacistNotes: 'Swallow capsule whole with water; do not crush, chew, or open the delayed-release pellets.',
        rxType: 'Supportive Rx'
      }
    ];
  }

  // Default Standard Thoracic / Pulmonary / General Clinical Regimen
  return [
    {
      medication: 'Amoxicillin / Clavulanate (Augmentin)',
      genericName: 'Amoxicillin 875 mg + Clavulanate Potassium 125 mg',
      dosage: '875 mg / 125 mg Film-Coated Tablet',
      route: 'Oral (PO)',
      frequency: 'Every 12 hours with meals (q12h)',
      duration: '7 Days (Dispense: #14 Tablets)',
      indication: 'Empirical bactericidal antimicrobial coverage for Community-Acquired Bronchopneumonia',
      contraindications: ['Penicillin / Beta-lactam anaphylaxis history', 'History of Augmentin-associated cholestatic jaundice'],
      pharmacistNotes: 'Complete the entire 7-day course. Take with food to minimize GI distress.',
      rxType: 'Primary Rx'
    },
    {
      medication: 'Azithromycin (Zithromax Z-Pak)',
      genericName: 'Azithromycin 250 mg / 500 mg',
      dosage: '500 mg Day 1, then 250 mg Days 2-5',
      route: 'Oral (PO)',
      frequency: 'Once daily (q24h)',
      duration: '5 Days (Dispense: #6 Tablets)',
      indication: 'Atypical respiratory pathogen coverage (Mycoplasma pneumoniae / Chlamydophila)',
      contraindications: ['Prolonged QT interval history', 'Severe hepatic impairment'],
      pharmacistNotes: 'Take once daily at the same time each day. Avoid concurrent aluminium or magnesium antacids.',
      rxType: 'Supportive Rx'
    },
    {
      medication: 'Guaifenesin Extended-Release (Mucinex)',
      genericName: 'Guaifenesin 600 mg Extended-Release',
      dosage: '600 mg Tablet',
      route: 'Oral (PO)',
      frequency: 'Every 12 hours with a full glass of water',
      duration: '7 Days as needed for chest congestion',
      indication: 'Mucolytic and airway expectorant to thin bronchial secretions and enhance clearance',
      contraindications: ['Known hypersensitivity to guaifenesin'],
      pharmacistNotes: 'Drink plenty of fluids (>2.5L daily) to maximize pulmonary mucus thinning and expectoration.',
      rxType: 'Symptomatic Relief'
    }
  ];
};

export const PrintReportModal: React.FC<PrintReportModalProps> = ({
  report,
  patientRecord,
  allPatientRecords = [],
  onClose,
}) => {
  const { user } = useAuth();

  // Mode: Single Report or Complete Patient Dossier
  const [documentMode, setDocumentMode] = useState<'single' | 'dossier'>(
    report || patientRecord ? 'single' : 'dossier'
  );

  // Selected Patient for Dossier
  const availablePatients = Array.from(
    new Set(allPatientRecords.map((r) => r.patientName).filter(Boolean))
  );
  const defaultPatient = report?.patientName || patientRecord?.patientName || availablePatients[0] || 'Eleanor Vance';
  const [selectedPatientName, setSelectedPatientName] = useState<string>(defaultPatient);

  // Filtered records for selected patient
  const patientRecords = allPatientRecords.filter(
    (r) => r.patientName.toLowerCase() === selectedPatientName.toLowerCase()
  );

  // Active target record or report
  const activeSingleRecord = patientRecord || (patientRecords.length > 0 ? patientRecords[0] : null);

  // Customization Options (Prescriptions defaults to true)
  const [includeLetterhead, setIncludeLetterhead] = useState(true);
  const [includeDemographics, setIncludeDemographics] = useState(true);
  const [includeDiagnosticHistory, setIncludeDiagnosticHistory] = useState(true);
  const [includeRecommendations, setIncludeRecommendations] = useState(true);
  const [includePrescriptions, setIncludePrescriptions] = useState(true);
  const [includePrecautions, setIncludePrecautions] = useState(true);
  const [includePubMedEvidence, setIncludePubMedEvidence] = useState(true);
  const [includeDoctorSignature, setIncludeDoctorSignature] = useState(true);
  const [includeSecurityQR, setIncludeSecurityQR] = useState(true);
  
  // Customizable fields
  const [hospitalName, setHospitalName] = useState('MEDISCAN DIAGNOSTIC & CLINICAL AI HEALTH SYSTEM');
  const [departmentName, setDepartmentName] = useState('Division of Diagnostic Radiology & Clinical Informatics');
  const [attendingDoctor, setAttendingDoctor] = useState(
    user?.role === 'doctor' ? user.name : (report?.physicianName || activeSingleRecord?.doctorName || 'Dr. Kavyashree, MD')
  );
  const [doctorLicense, setDoctorLicense] = useState(user?.licenseNumber || 'MD-84920-CA (NPI: 1948201938)');
  const [deaNumber, setDeaNumber] = useState('DEA: #BK8492019');
  const [customAddendum, setCustomAddendum] = useState('');
  const [documentTitle, setDocumentTitle] = useState(
    documentMode === 'dossier' 
      ? 'COMPREHENSIVE PATIENT DIAGNOSTIC HISTORY & CLINICAL DOSSIER'
      : (report?.title || activeSingleRecord?.title || 'CLINICAL DIAGNOSTIC & RADIOLOGY REPORT')
  );

  // Prescriptions Management State
  const initialPrescriptions = (() => {
    if (documentMode === 'dossier') {
      const compiled = patientRecords.flatMap((r) => r.prescriptions || []);
      if (compiled.length > 0) return compiled;
    } else {
      if (activeSingleRecord?.prescriptions && activeSingleRecord.prescriptions.length > 0) {
        return activeSingleRecord.prescriptions;
      }
      if (report?.prescriptions && report.prescriptions.length > 0) {
        return report.prescriptions;
      }
    }
    // Fallback standard clinical prescriptions
    return generateClinicalPrescriptions(
      activeSingleRecord?.modality,
      report?.title || activeSingleRecord?.title,
      activeSingleRecord?.symptoms
    );
  })();

  const [activePrescriptionsList, setActivePrescriptionsList] = useState<ClinicalPrescriptionItem[]>(initialPrescriptions);
  const [isAddingMedication, setIsAddingMedication] = useState(false);
  const [newMedName, setNewMedName] = useState('');
  const [newGenericName, setNewGenericName] = useState('');
  const [newDosage, setNewDosage] = useState('');
  const [newRoute, setNewRoute] = useState('Oral (PO)');
  const [newFrequency, setNewFrequency] = useState('Every 12 hours with meals');
  const [newDuration, setNewDuration] = useState('7 Days');
  const [newIndication, setNewIndication] = useState('');
  const [newPharmacistNotes, setNewPharmacistNotes] = useState('');
  const [newRxType, setNewRxType] = useState<'Primary Rx' | 'Supportive Rx' | 'Symptomatic Relief'>('Primary Rx');

  // Update prescriptions when switching patient or record
  useEffect(() => {
    let list: ClinicalPrescriptionItem[] = [];
    if (documentMode === 'dossier') {
      list = patientRecords.flatMap((r) => r.prescriptions || []);
    } else {
      list = activeSingleRecord?.prescriptions || report?.prescriptions || [];
    }
    if (list.length === 0) {
      list = generateClinicalPrescriptions(
        activeSingleRecord?.modality,
        report?.title || activeSingleRecord?.title,
        activeSingleRecord?.symptoms
      );
    }
    setActivePrescriptionsList(list);
  }, [documentMode, selectedPatientName]);

  const [copiedText, setCopiedText] = useState(false);
  const printContainerRef = useRef<HTMLDivElement>(null);

  // Trigger Native Print Dialog
  const handlePrint = () => {
    setTimeout(() => {
      window.print();
    }, 100);
  };

  // Quick protocol insert helper
  const handleAddPresetProtocol = (protocolType: 'cap' | 'derm' | 'neuro' | 'gi') => {
    let preset: ClinicalPrescriptionItem[] = [];
    if (protocolType === 'cap') preset = generateClinicalPrescriptions('xray', 'Chest X-Ray', ['cough']);
    else if (protocolType === 'derm') preset = generateClinicalPrescriptions('derm', 'Dermoscopy', ['lesion']);
    else if (protocolType === 'neuro') preset = generateClinicalPrescriptions('mri', 'Brain MRI', ['headache']);
    else if (protocolType === 'gi') preset = generateClinicalPrescriptions('ultrasound', 'Abdomen', ['pain']);

    setActivePrescriptionsList((prev) => [...prev, ...preset]);
  };

  // Add custom medication
  const handleSaveCustomMedication = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMedName.trim()) return;

    const newRx: ClinicalPrescriptionItem = {
      medication: newMedName.trim(),
      genericName: newGenericName.trim() || newMedName.trim(),
      dosage: newDosage.trim() || '1 Tablet / Unit',
      route: newRoute,
      frequency: newFrequency.trim() || 'Once daily',
      duration: newDuration.trim() || '7 Days',
      indication: newIndication.trim() || 'Therapeutic clinical indication per attending physician',
      contraindications: ['Known hypersensitivity'],
      pharmacistNotes: newPharmacistNotes.trim() || 'Take with water as directed.',
      rxType: newRxType,
    };

    setActivePrescriptionsList((prev) => [...prev, newRx]);
    setNewMedName('');
    setNewGenericName('');
    setNewDosage('');
    setNewIndication('');
    setNewPharmacistNotes('');
    setIsAddingMedication(false);
  };

  const handleRemoveMedication = (index: number) => {
    setActivePrescriptionsList((prev) => prev.filter((_, idx) => idx !== index));
  };

  // Copy plain text summary of clinical report
  const handleCopyText = () => {
    const textContent = `
================================================================================
${hospitalName.toUpperCase()}
${departmentName}
================================================================================
DOCUMENT: ${documentTitle}
PATIENT: ${selectedPatientName} | MRN: ${report?.patientId || activeSingleRecord?.patientId || 'MRN-7840129'}
ATTENDING PHYSICIAN: ${attendingDoctor} (${doctorLicense}) | ${deaNumber}
DATE: ${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}

--- EXECUTIVE DIAGNOSTIC FINDINGS ---
${report?.summary || activeSingleRecord?.primaryFindingSummary || 'Comprehensive diagnostic evaluation completed.'}

--- CLINICAL RECOMMENDATIONS ---
${activeSingleRecord?.treatmentOptions?.conservativeTherapy?.map(t => `- ${t}`).join('\n') || '- Standard clinical follow-up as directed.'}

--- ACTIVE PHARMACOTHERAPY & PRESCRIPTIONS (℞) ---
${activePrescriptionsList.map((p, i) => `${i + 1}. ${p.medication} (${p.genericName})\n   Dosage & Route: ${p.dosage} • ${p.route}\n   Sig: ${p.frequency}\n   Duration: ${p.duration}\n   Indication: ${p.indication}\n   Pharmacist Notes: ${p.pharmacistNotes}`).join('\n\n')}

--- CLINICAL PRECAUTIONS & RED FLAGS ---
${activePrecautions?.immediateDirectives?.map(d => `- [Directive] ${d}`).join('\n') || '- Maintain resting posture.'}
${activePrecautions?.redFlagEmergencySymptoms?.map(w => `- [RED FLAG] ${w}`).join('\n') || ''}

--- PHYSICIAN ATTESTATION ---
Verified and electronically signed by ${attendingDoctor}, MD.
Dispense As Written (DAW) authorized.
================================================================================
    `.trim();

    navigator.clipboard.writeText(textContent);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2500);
  };

  // Compile active precautions
  const activePrecautions = activeSingleRecord?.precautions || report?.precautions;

  // Compile treatment options
  const activeTreatmentOptions = activeSingleRecord?.treatmentOptions || report?.treatmentOptions;

  // Compile RAG & PubMed Citations
  const activeRag = activeSingleRecord?.ragVerification || report?.ragVerification;
  const activeCitations = activeRag?.pubMedCitations || [];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/75 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="w-full max-w-7xl max-h-[96vh] flex flex-col bg-slate-100 rounded-3xl border border-slate-300 shadow-2xl overflow-hidden">
        
        {/* Top Control Bar (Hidden on Print) */}
        <div className="no-print flex items-center justify-between p-4 sm:px-6 bg-slate-900 text-white border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Printer className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-white tracking-tight flex items-center gap-2">
                <span>Clinical Vector PDF & Print Engine</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Prescriptions Included (℞)
                </span>
              </h2>
              <p className="text-[11px] text-slate-400">
                Official hospital layout &bull; High-contrast print styling &bull; Double-verified attestation
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyText}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer border border-slate-700"
              title="Copy formatted clinical summary to clipboard"
            >
              {copiedText ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-slate-400" />
                  <span>Copy Text</span>
                </>
              )}
            </button>

            <button
              onClick={handlePrint}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-blue-900/30 transition-all cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Print to PDF Now</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              title="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Main Body Grid */}
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
          
          {/* Left Customization Panel (Hidden on Print) */}
          <div className="no-print lg:col-span-4 p-5 bg-white border-r border-slate-200 overflow-y-auto space-y-5 text-xs">
            
            {/* Mode Selector */}
            <div className="space-y-2">
              <label className="font-bold text-slate-800 uppercase tracking-wider text-[10px] flex items-center gap-1.5">
                <SlidersHorizontal className="w-3.5 h-3.5 text-blue-600" />
                <span>Document Type</span>
              </label>
              <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-100 rounded-xl border border-slate-200">
                <button
                  type="button"
                  onClick={() => {
                    setDocumentMode('single');
                    setDocumentTitle(report?.title || activeSingleRecord?.title || 'CLINICAL DIAGNOSTIC & RADIOLOGY REPORT');
                  }}
                  className={`py-2 px-2 rounded-lg font-bold text-center transition-all cursor-pointer ${
                    documentMode === 'single'
                      ? 'bg-white text-blue-700 shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Single Report
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setDocumentMode('dossier');
                    setDocumentTitle('COMPREHENSIVE PATIENT DIAGNOSTIC HISTORY & CLINICAL DOSSIER');
                  }}
                  className={`py-2 px-2 rounded-lg font-bold text-center transition-all cursor-pointer ${
                    documentMode === 'dossier'
                      ? 'bg-white text-blue-700 shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Full Patient Dossier
                </button>
              </div>
            </div>

            {/* Patient Selector for Dossier Mode */}
            {availablePatients.length > 0 && (
              <div className="space-y-1.5">
                <label className="font-bold text-slate-700 text-[11px] flex items-center justify-between">
                  <span>Selected Patient:</span>
                  <span className="text-[10px] text-blue-600 font-semibold">{patientRecords.length} Studies</span>
                </label>
                <select
                  value={selectedPatientName}
                  onChange={(e) => setSelectedPatientName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-800 focus:outline-none focus:border-blue-500"
                >
                  {availablePatients.map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Document Title Input */}
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 text-[11px]">Header Document Title</label>
              <input
                type="text"
                value={documentTitle}
                onChange={(e) => setDocumentTitle(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-800 focus:outline-none focus:border-blue-500"
              />
            </div>

            {/* Section Toggles */}
            <div className="space-y-2 pt-2 border-t border-slate-100">
              <label className="font-bold text-slate-800 uppercase tracking-wider text-[10px] flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-blue-600" />
                <span>Sections to Include in PDF</span>
              </label>

              <div className="space-y-1.5">
                {[
                  { label: 'Hospital Letterhead & Metadata', state: includeLetterhead, set: setIncludeLetterhead },
                  { label: 'Patient Demographics Box', state: includeDemographics, set: setIncludeDemographics },
                  { label: 'Diagnostic Findings & Imaging History', state: includeDiagnosticHistory, set: setIncludeDiagnosticHistory },
                  { label: 'Clinical Recommendations & Management', state: includeRecommendations, set: setIncludeRecommendations },
                  { label: `Active Prescriptions Schedule (℞) [${activePrescriptionsList.length} Meds]`, state: includePrescriptions, set: setIncludePrescriptions, badge: 'Rx Highlighted' },
                  { label: 'Clinical Precautions & Red Flags', state: includePrecautions, set: setIncludePrecautions },
                  { label: 'PubMed RAG Citations & Evidence', state: includePubMedEvidence, set: setIncludePubMedEvidence },
                  { label: 'Physician Signature & Attestation', state: includeDoctorSignature, set: setIncludeDoctorSignature },
                  { label: 'Verification QR Code & Audit Trail', state: includeSecurityQR, set: setIncludeSecurityQR },
                ].map((item, idx) => (
                  <label
                    key={idx}
                    className={`flex items-center justify-between p-2 rounded-xl transition-colors cursor-pointer border ${
                      item.badge 
                        ? 'bg-emerald-50/70 border-emerald-200 hover:bg-emerald-100/70'
                        : 'bg-slate-50 hover:bg-slate-100 border-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-slate-800 text-[11px]">{item.label}</span>
                      {item.badge && (
                        <span className="px-1.5 py-0.2 text-[9px] font-black uppercase rounded bg-emerald-600 text-white">
                          ℞ Active
                        </span>
                      )}
                    </div>
                    <input
                      type="checkbox"
                      checked={item.state}
                      onChange={(e) => item.set(e.target.checked)}
                      className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
                    />
                  </label>
                ))}
              </div>
            </div>

            {/* Prescriptions (Rx) Manager */}
            <div className="space-y-3 pt-2 border-t border-slate-100">
              <div className="flex items-center justify-between">
                <label className="font-bold text-slate-800 uppercase tracking-wider text-[10px] flex items-center gap-1.5">
                  <Pill className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Prescriptions (Rx) Customizer</span>
                </label>
                <button
                  type="button"
                  onClick={() => setIsAddingMedication(!isAddingMedication)}
                  className="px-2 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg text-[10px] font-bold flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Plus className="w-3 h-3" />
                  <span>{isAddingMedication ? 'Cancel' : 'Add Medication'}</span>
                </button>
              </div>

              {/* Add Custom Medication Form */}
              {isAddingMedication && (
                <form onSubmit={handleSaveCustomMedication} className="p-3 bg-blue-50/60 border border-blue-200 rounded-xl space-y-2 text-[11px]">
                  <div className="font-bold text-blue-900 text-[10px] uppercase">New Medication Order</div>
                  
                  <div>
                    <span className="text-[10px] text-slate-600 block mb-0.5">Medication Name (Brand)</span>
                    <input
                      type="text"
                      required
                      placeholder="e.g., Amoxicillin / Clavulanate (Augmentin)"
                      value={newMedName}
                      onChange={(e) => setNewMedName(e.target.value)}
                      className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-1.5">
                    <div>
                      <span className="text-[10px] text-slate-600 block mb-0.5">Generic Formulation</span>
                      <input
                        type="text"
                        placeholder="e.g., Amoxicillin 875mg"
                        value={newGenericName}
                        onChange={(e) => setNewGenericName(e.target.value)}
                        className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-600 block mb-0.5">Dosage / Strength</span>
                      <input
                        type="text"
                        placeholder="e.g., 875/125 mg Tablet"
                        value={newDosage}
                        onChange={(e) => setNewDosage(e.target.value)}
                        className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-1.5">
                    <div>
                      <span className="text-[10px] text-slate-600 block mb-0.5">Route</span>
                      <select
                        value={newRoute}
                        onChange={(e) => setNewRoute(e.target.value)}
                        className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs"
                      >
                        <option value="Oral (PO)">Oral (PO)</option>
                        <option value="Topical (Cutaneous)">Topical</option>
                        <option value="Inhalation (Aerosol)">Inhalation</option>
                        <option value="Sublingual / ODT">Sublingual</option>
                        <option value="IV Infusion">IV Infusion</option>
                      </select>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-600 block mb-0.5">Rx Classification</span>
                      <select
                        value={newRxType}
                        onChange={(e) => setNewRxType(e.target.value as any)}
                        className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs"
                      >
                        <option value="Primary Rx">Primary Rx</option>
                        <option value="Supportive Rx">Supportive Rx</option>
                        <option value="Symptomatic Relief">Symptomatic Relief</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-1.5">
                    <div>
                      <span className="text-[10px] text-slate-600 block mb-0.5">Frequency (Sig)</span>
                      <input
                        type="text"
                        placeholder="e.g., Every 12 hours with meals"
                        value={newFrequency}
                        onChange={(e) => setNewFrequency(e.target.value)}
                        className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-600 block mb-0.5">Duration & Dispense</span>
                      <input
                        type="text"
                        placeholder="e.g., 7 Days (Dispense: #14)"
                        value={newDuration}
                        onChange={(e) => setNewDuration(e.target.value)}
                        className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <span className="text-[10px] text-slate-600 block mb-0.5">Clinical Indication</span>
                    <input
                      type="text"
                      placeholder="e.g., Empirical antimicrobial therapy for bronchopulmonary consolidation"
                      value={newIndication}
                      onChange={(e) => setNewIndication(e.target.value)}
                      className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs"
                    />
                  </div>

                  <div>
                    <span className="text-[10px] text-slate-600 block mb-0.5">Pharmacist / Patient Instructions</span>
                    <input
                      type="text"
                      placeholder="e.g., Take with food. Complete entire 7-day course."
                      value={newPharmacistNotes}
                      onChange={(e) => setNewPharmacistNotes(e.target.value)}
                      className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs"
                    />
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setIsAddingMedication(false)}
                      className="px-2.5 py-1 text-slate-600 hover:text-slate-900 text-[10px] font-bold"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded text-[10px] font-bold"
                    >
                      Add to Prescription Order
                    </button>
                  </div>
                </form>
              )}

              {/* Prescriptions List with Delete */}
              <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                {activePrescriptionsList.map((rx, idx) => (
                  <div
                    key={idx}
                    className="p-2 rounded-xl bg-slate-50 border border-slate-200 flex items-start justify-between gap-2"
                  >
                    <div className="space-y-0.5 overflow-hidden">
                      <div className="font-bold text-slate-900 text-[11px] truncate flex items-center gap-1.5">
                        <span>{rx.medication}</span>
                        <span className={`text-[8px] px-1 py-0.2 rounded font-black uppercase ${
                          rx.rxType === 'Primary Rx' ? 'bg-blue-100 text-blue-800' : 'bg-emerald-100 text-emerald-800'
                        }`}>
                          {rx.rxType || 'Rx'}
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-500">
                        {rx.dosage} &bull; {rx.frequency} ({rx.duration})
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleRemoveMedication(idx)}
                      className="p-1 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer shrink-0"
                      title="Remove from printout"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>

              {/* Quick Regimen Preset Injectors */}
              <div className="space-y-1">
                <span className="text-[10px] text-slate-500 font-semibold block">Quick Clinical Regimen Presets:</span>
                <div className="grid grid-cols-2 gap-1">
                  <button
                    type="button"
                    onClick={() => handleAddPresetProtocol('cap')}
                    className="p-1.5 rounded-lg bg-slate-100 hover:bg-blue-50 hover:text-blue-700 border border-slate-200 text-slate-700 text-[10px] font-bold text-left transition-colors cursor-pointer"
                  >
                    + CAP Antibiotic Regimen
                  </button>
                  <button
                    type="button"
                    onClick={() => handleAddPresetProtocol('neuro')}
                    className="p-1.5 rounded-lg bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 border border-slate-200 text-slate-700 text-[10px] font-bold text-left transition-colors cursor-pointer"
                  >
                    + Cephalea / Pain Protocol
                  </button>
                  <button
                    type="button"
                    onClick={() => handleAddPresetProtocol('derm')}
                    className="p-1.5 rounded-lg bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 border border-slate-200 text-slate-700 text-[10px] font-bold text-left transition-colors cursor-pointer"
                  >
                    + Cutaneous Biopsy Care
                  </button>
                  <button
                    type="button"
                    onClick={() => handleAddPresetProtocol('gi')}
                    className="p-1.5 rounded-lg bg-slate-100 hover:bg-amber-50 hover:text-amber-700 border border-slate-200 text-slate-700 text-[10px] font-bold text-left transition-colors cursor-pointer"
                  >
                    + GI & Spasmolytic Care
                  </button>
                </div>
              </div>
            </div>

            {/* Attending Physician Customization */}
            <div className="space-y-3 pt-2 border-t border-slate-100">
              <label className="font-bold text-slate-800 uppercase tracking-wider text-[10px] flex items-center gap-1.5">
                <Stethoscope className="w-3.5 h-3.5 text-blue-600" />
                <span>Physician & Facility Customization</span>
              </label>

              <div className="space-y-2">
                <div>
                  <span className="text-[10px] text-slate-500 block mb-0.5">Attending Physician Name</span>
                  <input
                    type="text"
                    value={attendingDoctor}
                    onChange={(e) => setAttendingDoctor(e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-[11px] font-medium"
                  />
                </div>
                <div className="grid grid-cols-2 gap-1.5">
                  <div>
                    <span className="text-[10px] text-slate-500 block mb-0.5">Medical License / NPI</span>
                    <input
                      type="text"
                      value={doctorLicense}
                      onChange={(e) => setDoctorLicense(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-[11px] font-medium"
                    />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block mb-0.5">DEA Registration</span>
                    <input
                      type="text"
                      value={deaNumber}
                      onChange={(e) => setDeaNumber(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-[11px] font-medium"
                    />
                  </div>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block mb-0.5">Custom Physician Addendum / Notes</span>
                  <textarea
                    rows={2}
                    value={customAddendum}
                    onChange={(e) => setCustomAddendum(e.target.value)}
                    placeholder="e.g., Patient instructed to return immediately if resting dyspnea worsens..."
                    className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-[11px] font-medium"
                  />
                </div>
              </div>
            </div>

            {/* Print Help Box */}
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-2xl text-[11px] text-blue-900 space-y-1">
              <div className="font-bold flex items-center gap-1 text-blue-800">
                <Printer className="w-3.5 h-3.5" />
                <span>Tip for Clean PDF Output:</span>
              </div>
              <p className="text-slate-600 leading-relaxed">
                In the browser print dialog, select <strong>Destination: Save as PDF</strong>, set Margins to <strong>Default</strong> or <strong>None</strong>, and enable <strong>Background graphics</strong>.
              </p>
            </div>

          </div>

          {/* Right Live Document Preview / Printable Container */}
          <div className="lg:col-span-8 p-4 sm:p-8 bg-slate-200/80 overflow-y-auto flex justify-center">
            
            {/* The Actual Printable Sheet Component */}
            <div
              id="printable-medical-report"
              ref={printContainerRef}
              className="w-full max-w-[850px] bg-white text-slate-900 p-8 sm:p-10 rounded-2xl shadow-xl border border-slate-300 space-y-6 font-sans text-xs leading-normal"
              style={{ minHeight: '1050px' }}
            >
              {/* ========================================================
                  SECTION 1: HOSPITAL LETTERHEAD & INSTITUTIONAL BRAND
                  ======================================================== */}
              {includeLetterhead && (
                <div className="border-b-2 border-slate-900 pb-4 space-y-3">
                  <div className="flex items-start justify-between gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg bg-blue-900 text-white flex items-center justify-center font-bold text-base">
                          +
                        </div>
                        <h1 className="text-base sm:text-lg font-black text-slate-950 tracking-tight uppercase font-sans">
                          {hospitalName}
                        </h1>
                      </div>
                      <div className="text-[11px] font-semibold text-slate-600 uppercase tracking-wider">
                        {departmentName}
                      </div>
                      <div className="text-[10px] text-slate-500 flex items-center gap-3">
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3" /> 500 Medical Center Way, Suite 400
                        </span>
                        <span className="flex items-center gap-1">
                          <Phone className="w-3 h-3" /> (800) 555-0199
                        </span>
                        <span className="flex items-center gap-1">
                          <Mail className="w-3 h-3" /> clinical@mediscan.org
                        </span>
                      </div>
                    </div>

                    <div className="text-right space-y-0.5 shrink-0">
                      <div className="inline-block px-2.5 py-1 rounded bg-slate-900 text-white font-mono font-bold text-[10px] uppercase">
                        {report?.status || 'Final Certified'}
                      </div>
                      <div className="text-[9px] text-slate-500 font-mono">
                        DOC ID: {report?.reportNumber || `REP-${Date.now().toString().slice(-6)}`}
                      </div>
                      <div className="text-[9px] text-slate-500 font-mono">
                        NPI: 1948201938 &bull; CLIA: 05D28491
                      </div>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-700">
                    <div className="font-bold uppercase tracking-wider text-blue-950 text-xs">
                      {documentTitle}
                    </div>
                    <div className="text-slate-600 font-medium">
                      Date Issued: <strong>{new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</strong>
                    </div>
                  </div>
                </div>
              )}

              {/* ========================================================
                  SECTION 2: PATIENT DEMOGRAPHICS & CLINICAL ENCOUNTER
                  ======================================================== */}
              {includeDemographics && (
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-300 grid grid-cols-2 sm:grid-cols-4 gap-3 text-[11px]">
                  <div>
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                      Patient Full Name
                    </span>
                    <strong className="text-slate-900 text-xs">{selectedPatientName}</strong>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                      Medical Record Number (MRN)
                    </span>
                    <strong className="text-slate-900 font-mono text-xs">
                      {report?.patientId || activeSingleRecord?.patientId || 'MRN-7840129'}
                    </strong>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                      Attending Physician
                    </span>
                    <strong className="text-slate-900 text-xs">{attendingDoctor}</strong>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                      Encounter Date
                    </span>
                    <strong className="text-slate-900 text-xs">
                      {report?.date || activeSingleRecord?.submittedAt ? new Date(report?.date || activeSingleRecord?.submittedAt || '').toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: '2-digit' }) : new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: '2-digit' })}
                    </strong>
                  </div>
                </div>
              )}

              {/* ========================================================
                  SECTION 3: DIAGNOSTIC FINDINGS & IMAGING HISTORY
                  ======================================================== */}
              {includeDiagnosticHistory && (
                <div className="space-y-4">
                  <div className="border-b border-slate-300 pb-1 flex items-center justify-between">
                    <h3 className="text-xs font-black uppercase tracking-wider text-slate-900 flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-blue-600" />
                      <span>Diagnostic Imaging Findings & Radiologic Assessment</span>
                    </h3>
                    <span className="text-[10px] font-mono text-slate-500">
                      Modality: {activeSingleRecord?.modality?.toUpperCase() || report?.category?.toUpperCase() || 'RADIOLOGY'}
                    </span>
                  </div>

                  {/* 1. What is the Issue? Banner */}
                  <div className="p-3.5 rounded-xl bg-blue-900 text-white text-[11px] space-y-1.5 shadow-2xs">
                    <div className="flex items-center justify-between">
                      <div className="font-bold text-blue-200 uppercase text-[10px] tracking-wider flex items-center gap-1">
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-300" />
                        <span>1. What is the Issue? (Clinical Diagnosis)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {activeSingleRecord?.icd10Code && (
                          <span className="px-1.5 py-0.2 rounded text-[9px] font-mono font-bold bg-blue-800 text-blue-100 border border-blue-700">
                            ICD-10: {activeSingleRecord.icd10Code}
                          </span>
                        )}
                        <span className="px-1.5 py-0.2 rounded text-[9px] font-bold uppercase bg-amber-400 text-amber-950">
                          Severity: {activeSingleRecord?.severityLevel || 'Moderate'}
                        </span>
                      </div>
                    </div>

                    <div className="text-xs sm:text-sm font-black text-white">
                      {activeSingleRecord?.issueDiagnosis || report?.title || activeSingleRecord?.title || 'Clinical Diagnostic Assessment'}
                    </div>
                    <p className="text-[11px] text-blue-100 leading-relaxed">
                      {report?.summary || activeSingleRecord?.primaryFindingSummary || 'Comprehensive multi-planar imaging review shows focal anatomical variations correlated with peer-reviewed diagnostic criteria.'}
                    </p>
                  </div>

                  {/* 2. What Has Been Observed? Detailed Findings */}
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 text-[11px] space-y-2">
                    <div className="font-bold text-slate-900 uppercase text-[10px] tracking-wider flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      <span>2. What Has Been Observed? (Detailed Anatomical Findings)</span>
                    </div>

                    {activeSingleRecord?.detailedObservations && activeSingleRecord.detailedObservations.length > 0 ? (
                      <ul className="space-y-1 text-slate-800 pl-1">
                        {activeSingleRecord.detailedObservations.map((obs, i) => (
                          <li key={i} className="flex items-start gap-2 leading-relaxed">
                            <span className="font-bold text-blue-900 font-mono text-[10px] shrink-0 mt-0.5">•</span>
                            <span>{obs}</span>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <div className="space-y-1 text-slate-800">
                        <div className="flex items-start gap-2 leading-relaxed">
                          <span className="font-bold text-blue-900 font-mono text-[10px] shrink-0 mt-0.5">•</span>
                          <span>Anatomical landmarks surveyed with clear architectural demarcation across target slices.</span>
                        </div>
                        <div className="flex items-start gap-2 leading-relaxed">
                          <span className="font-bold text-blue-900 font-mono text-[10px] shrink-0 mt-0.5">•</span>
                          <span>No acute focal high-density consolidation, gross midline distortion, or pathological bleeding identified.</span>
                        </div>
                        <div className="flex items-start gap-2 leading-relaxed">
                          <span className="font-bold text-blue-900 font-mono text-[10px] shrink-0 mt-0.5">•</span>
                          <span>Adjacent musculoskeletal & soft-tissue boundaries demonstrate physiological preservation.</span>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* 3. Facial Topography & Symmetry Section (if Face Scan) */}
                  {(activeSingleRecord?.modality === 'face' || activeSingleRecord?.facialAnalysisMetrics) && (
                    <div className="p-3.5 rounded-xl bg-indigo-50/70 border border-indigo-200 text-slate-900 text-[11px] space-y-2.5">
                      <div className="flex items-center justify-between pb-1 border-b border-indigo-200">
                        <div className="font-bold text-indigo-950 uppercase text-[10px] tracking-wider flex items-center gap-1.5">
                          <span>👤 Facial Topography, Symmetry & Dermatosis Profile</span>
                        </div>
                        <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-indigo-100 text-indigo-900">
                          Symmetry: {activeSingleRecord.facialAnalysisMetrics?.symmetryScore || 97.4}% (CN VII Intact)
                        </span>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px]">
                        <div className="p-2 rounded-lg bg-white border border-indigo-100">
                          <span className="text-slate-500 font-bold block text-[9px] uppercase">Erythema:</span>
                          <strong className="text-rose-700">{activeSingleRecord.facialAnalysisMetrics?.erythemaSeverity || 'Grade 2 Moderate'}</strong>
                        </div>
                        <div className="p-2 rounded-lg bg-white border border-indigo-100">
                          <span className="text-slate-500 font-bold block text-[9px] uppercase">Barrier Hydration:</span>
                          <strong className="text-blue-700">{activeSingleRecord.facialAnalysisMetrics?.skinBarrierHydration || '34% Index'}</strong>
                        </div>
                        <div className="p-2 rounded-lg bg-white border border-indigo-100">
                          <span className="text-slate-500 font-bold block text-[9px] uppercase">Papule Count:</span>
                          <strong className="text-purple-700">{activeSingleRecord.facialAnalysisMetrics?.papulePustuleCount ?? 6} Lesions</strong>
                        </div>
                        <div className="p-2 rounded-lg bg-white border border-indigo-100">
                          <span className="text-slate-500 font-bold block text-[9px] uppercase">Pigmentation:</span>
                          <strong className="text-emerald-700">{activeSingleRecord.facialAnalysisMetrics?.pigmentationHomogeneity || '89% Homogeneous'}</strong>
                        </div>
                      </div>

                      {activeSingleRecord.facialAnalysisMetrics?.keyRegionsEvaluated && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-[10px] pt-1">
                          {activeSingleRecord.facialAnalysisMetrics.keyRegionsEvaluated.map((zone, zIdx) => (
                            <div key={zIdx} className="p-2 rounded-lg bg-white border border-indigo-100 flex items-start justify-between gap-1.5">
                              <div>
                                <strong className="text-slate-900 block">{zone.region}:</strong>
                                <span className="text-slate-600 text-[9px]">{zone.findings}</span>
                              </div>
                              <span className="px-1 py-0.2 rounded text-[8px] font-bold bg-indigo-50 text-indigo-900 border border-indigo-200 shrink-0">
                                {zone.status}
                              </span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Multi-study History Table for Dossier Mode */}
                  {documentMode === 'dossier' && patientRecords.length > 0 && (
                    <div className="space-y-2 pt-1">
                      <div className="font-bold text-slate-800 text-[11px] uppercase tracking-wider">
                        Patient Longitudinal Diagnostic History ({patientRecords.length} Studies on File):
                      </div>
                      <div className="overflow-x-auto border border-slate-200 rounded-xl">
                        <table className="w-full text-left text-[10px] border-collapse">
                          <thead>
                            <tr className="bg-slate-100 border-b border-slate-200 text-slate-700 font-bold uppercase tracking-wider">
                              <th className="p-2">Date & Time</th>
                              <th className="p-2">Study Description</th>
                              <th className="p-2">Modality</th>
                              <th className="p-2">Urgency</th>
                              <th className="p-2">Confidence</th>
                              <th className="p-2">Status</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-200">
                            {patientRecords.map((rec) => (
                              <tr key={rec.id} className="hover:bg-slate-50">
                                <td className="p-2 font-mono whitespace-nowrap">
                                  {new Date(rec.submittedAt).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: '2-digit' })}
                                </td>
                                <td className="p-2 font-semibold text-slate-900">{rec.title}</td>
                                <td className="p-2 uppercase font-mono">{rec.modality}</td>
                                <td className="p-2">
                                  <span className={`px-1.5 py-0.5 rounded font-bold uppercase text-[9px] ${
                                    rec.urgency === 'critical' ? 'bg-rose-100 text-rose-800' : 'bg-slate-100 text-slate-800'
                                  }`}>
                                    {rec.urgency}
                                  </span>
                                </td>
                                <td className="p-2 font-mono font-bold text-emerald-700">
                                  {rec.confidenceScore ? `${(rec.confidenceScore * 100).toFixed(0)}%` : '96%'}
                                </td>
                                <td className="p-2 font-medium capitalize">{rec.status}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* ========================================================
                  SECTION 4: CLINICAL RECOMMENDATIONS & MANAGEMENT PLAN
                  ======================================================== */}
              {includeRecommendations && activeTreatmentOptions && (
                <div className="space-y-3 page-break-inside-avoid">
                  <div className="border-b border-slate-300 pb-1 flex items-center justify-between">
                    <h3 className="text-xs font-black uppercase tracking-wider text-slate-900 flex items-center gap-1.5">
                      <Activity className="w-4 h-4 text-blue-600" />
                      <span>Clinical Treatment Recommendations & Management Options</span>
                    </h3>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px]">
                    {/* Conservative Therapy */}
                    {activeTreatmentOptions.conservativeTherapy && activeTreatmentOptions.conservativeTherapy.length > 0 && (
                      <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                        <div className="font-bold text-slate-900 text-[10px] uppercase tracking-wider">
                          1. Conservative & Outpatient Care:
                        </div>
                        <ul className="list-disc list-inside space-y-0.5 text-slate-700">
                          {activeTreatmentOptions.conservativeTherapy.map((item, i) => (
                            <li key={i} className="leading-snug">{item}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Interventional / Surgical */}
                    {activeTreatmentOptions.interventionalOrSurgical && activeTreatmentOptions.interventionalOrSurgical.length > 0 && (
                      <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                        <div className="font-bold text-slate-900 text-[10px] uppercase tracking-wider">
                          2. Interventional & Inpatient Escalation:
                        </div>
                        <ul className="list-disc list-inside space-y-0.5 text-slate-700">
                          {activeTreatmentOptions.interventionalOrSurgical.map((item, i) => (
                            <li key={i} className="leading-snug">{item}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Adjunct Rehabilitation */}
                    {activeTreatmentOptions.adjunctRehabilitation && activeTreatmentOptions.adjunctRehabilitation.length > 0 && (
                      <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                        <div className="font-bold text-slate-900 text-[10px] uppercase tracking-wider">
                          3. Supportive & Rehabilitative Protocol:
                        </div>
                        <ul className="list-disc list-inside space-y-0.5 text-slate-700">
                          {activeTreatmentOptions.adjunctRehabilitation.map((item, i) => (
                            <li key={i} className="leading-snug">{item}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Follow-up Timeline */}
                    {activeTreatmentOptions.followUpImagingTimeline && activeTreatmentOptions.followUpImagingTimeline.length > 0 && (
                      <div className="p-3 rounded-xl bg-purple-50/70 border border-purple-200 space-y-1">
                        <div className="font-bold text-purple-900 text-[10px] uppercase tracking-wider">
                          4. Follow-up Imaging & Review Timeline:
                        </div>
                        <ul className="list-disc list-inside space-y-0.5 text-slate-800">
                          {activeTreatmentOptions.followUpImagingTimeline.map((item, i) => (
                            <li key={i} className="leading-snug">{item}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* ========================================================
                  SECTION 5: PHARMACOTHERAPY & PRESCRIPTIONS (Rx PAD)
                  ======================================================== */}
              {includePrescriptions && activePrescriptionsList.length > 0 && (
                <div className="space-y-3 page-break-inside-avoid border-2 border-emerald-700/30 rounded-2xl p-4 bg-emerald-50/20">
                  
                  {/* Rx Pad Header */}
                  <div className="border-b border-emerald-800/20 pb-2 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-emerald-700 text-white font-serif font-black text-xl flex items-center justify-center shadow-xs">
                        ℞
                      </div>
                      <div>
                        <h3 className="text-xs font-black uppercase tracking-wider text-emerald-950 flex items-center gap-1.5">
                          <span>Clinical Pharmacotherapy & Active Prescription Schedule</span>
                        </h3>
                        <div className="text-[10px] text-emerald-800 font-medium">
                          Official Physician Prescription Order & Pharmacy Dispensing Directives
                        </div>
                      </div>
                    </div>

                    <div className="text-right text-[10px] font-mono text-emerald-900">
                      <div>{deaNumber} &bull; NPI: 1948201938</div>
                      <div className="font-bold italic text-emerald-950">Dispense As Written (DAW)</div>
                    </div>
                  </div>

                  {/* Patient & Allergy Strip */}
                  <div className="p-2 rounded-xl bg-white border border-emerald-200/80 grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px] text-slate-700">
                    <div>
                      <span className="text-slate-400 font-bold block text-[9px] uppercase">Patient:</span>
                      <strong className="text-slate-900">{selectedPatientName}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 font-bold block text-[9px] uppercase">MRN:</span>
                      <strong className="font-mono text-slate-900">{report?.patientId || activeSingleRecord?.patientId || 'MRN-7840129'}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 font-bold block text-[9px] uppercase">Known Allergies:</span>
                      <strong className="text-emerald-700 font-semibold">NKDA (No Known Drug Allergies)</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 font-bold block text-[9px] uppercase">Prescription Date:</span>
                      <strong className="text-slate-900">{new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: '2-digit' })}</strong>
                    </div>
                  </div>

                  {/* Comprehensive Prescription Table */}
                  <div className="overflow-x-auto border border-emerald-200 rounded-xl bg-white shadow-2xs">
                    <table className="w-full text-left text-[10px] border-collapse">
                      <thead>
                        <tr className="bg-emerald-800 text-white font-bold uppercase tracking-wider text-[9px]">
                          <th className="p-2.5">Medication & Generic</th>
                          <th className="p-2.5">Dosage & Route</th>
                          <th className="p-2.5">Schedule & Frequency (Sig)</th>
                          <th className="p-2.5">Duration & Dispense</th>
                          <th className="p-2.5">Refills</th>
                          <th className="p-2.5">Clinical Indication & Pharmacist Notes</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {activePrescriptionsList.map((rx, i) => (
                          <tr key={i} className="hover:bg-emerald-50/30 transition-colors">
                            <td className="p-2.5 font-bold text-slate-900 align-top">
                              <div className="flex items-center gap-1.5">
                                <span>{rx.medication}</span>
                              </div>
                              <div className="text-[9px] font-normal text-slate-500 italic mt-0.5">
                                Generic: {rx.genericName}
                              </div>
                              <div className="mt-1">
                                <span className={`px-1.5 py-0.2 rounded text-[8px] font-black uppercase tracking-wider ${
                                  rx.rxType === 'Primary Rx'
                                    ? 'bg-blue-100 text-blue-800 border border-blue-200'
                                    : rx.rxType === 'Supportive Rx'
                                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                                    : 'bg-amber-100 text-amber-800 border border-amber-200'
                                }`}>
                                  {rx.rxType || 'Primary Rx'}
                                </span>
                              </div>
                            </td>
                            <td className="p-2.5 font-medium text-slate-800 align-top">
                              <div className="font-bold text-slate-900">{rx.dosage}</div>
                              <div className="text-[9px] text-slate-500">{rx.route}</div>
                            </td>
                            <td className="p-2.5 text-slate-800 font-medium align-top">
                              <div className="bg-slate-50 p-1.5 rounded border border-slate-200 font-semibold">
                                {rx.frequency}
                              </div>
                            </td>
                            <td className="p-2.5 font-bold text-slate-900 align-top whitespace-nowrap">
                              {rx.duration}
                            </td>
                            <td className="p-2.5 font-semibold text-slate-700 align-top whitespace-nowrap">
                              0 (Zero)
                            </td>
                            <td className="p-2.5 text-slate-700 align-top">
                              <div className="font-semibold text-slate-900">{rx.indication}</div>
                              {rx.pharmacistNotes && (
                                <div className="text-[9px] text-blue-800 italic mt-1 bg-blue-50/60 p-1 rounded border border-blue-100">
                                  <strong>Sig Note:</strong> {rx.pharmacistNotes}
                                </div>
                              )}
                              {rx.contraindications && rx.contraindications.length > 0 && (
                                <div className="text-[8px] text-rose-700 mt-1">
                                  Warn: {rx.contraindications.join(', ')}
                                </div>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Prescription Attestation & Substitution Checkbox */}
                  <div className="pt-2 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-[10px] text-slate-600 border-t border-emerald-800/10">
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 rounded border-2 border-emerald-700 flex items-center justify-center text-emerald-700 font-bold">
                        ✓
                      </div>
                      <span>
                        <strong>Dispense As Written (DAW)</strong> &bull; Generic substitution permissible under standard pharmacy regulations.
                      </span>
                    </div>

                    <div className="text-right text-[9px] text-slate-500 font-mono">
                      Prescribing Physician: <strong>{attendingDoctor}</strong> &bull; Lic: {doctorLicense}
                    </div>
                  </div>

                </div>
              )}

              {/* ========================================================
                  SECTION 6: CLINICAL PRECAUTIONS & RED FLAG DIRECTIVES
                  ======================================================== */}
              {includePrecautions && activePrecautions && (
                <div className="space-y-2 page-break-inside-avoid">
                  <div className="border-b border-slate-300 pb-1 flex items-center justify-between">
                    <h3 className="text-xs font-black uppercase tracking-wider text-slate-900 flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4 text-amber-600" />
                      <span>Clinical Safety Precautions & Red Flag Emergency Directives</span>
                    </h3>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px]">
                    {/* Immediate directives */}
                    <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                      <div className="font-bold text-slate-900 text-[10px] uppercase tracking-wider flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Immediate Patient Directives:</span>
                      </div>
                      <ul className="list-disc list-inside space-y-0.5 text-slate-700">
                        {activePrecautions.immediateDirectives?.map((d, i) => (
                          <li key={i} className="leading-snug">{d}</li>
                        ))}
                      </ul>
                    </div>

                    {/* Critical Contraindications */}
                    <div className="p-3 rounded-xl bg-rose-50/70 border border-rose-200 space-y-1">
                      <div className="font-bold text-rose-900 text-[10px] uppercase tracking-wider flex items-center gap-1">
                        <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                        <span>Critical Contraindications (What NOT to do):</span>
                      </div>
                      <ul className="list-disc list-inside space-y-0.5 text-rose-900">
                        {activePrecautions.criticalContraindications?.map((d, i) => (
                          <li key={i} className="leading-snug font-medium">{d}</li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Red Flag Warning Box */}
                  {activePrecautions.redFlagEmergencySymptoms && activePrecautions.redFlagEmergencySymptoms.length > 0 && (
                    <div className="p-3 rounded-xl bg-rose-100/70 border border-rose-300 text-rose-950 text-[11px] space-y-1">
                      <div className="font-black text-[10px] uppercase tracking-wider flex items-center gap-1.5 text-rose-900">
                        <AlertTriangle className="w-4 h-4 text-rose-700" />
                        <span>EMERGENCY RED FLAG SYMPTOMS - SEEK IMMEDIATE 108 / 911 AMBULANCE DISPATCH:</span>
                      </div>
                      <p className="leading-relaxed font-semibold">
                        {activePrecautions.redFlagEmergencySymptoms.join(' &bull; ')}
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* ========================================================
                  SECTION 7: EVIDENCE-BASED PUBMED CITATIONS & RAG
                  ======================================================== */}
              {includePubMedEvidence && activeCitations.length > 0 && (
                <div className="space-y-2 page-break-inside-avoid">
                  <div className="border-b border-slate-300 pb-1 flex items-center justify-between">
                    <h3 className="text-xs font-black uppercase tracking-wider text-slate-900 flex items-center gap-1.5">
                      <BookOpen className="w-4 h-4 text-indigo-600" />
                      <span>RAG Double Verification & PubMed Central Evidence Grounding</span>
                    </h3>
                    <span className="text-[10px] font-mono text-slate-500">
                      Consensus: {activeRag?.consensusScore || 98.4}%
                    </span>
                  </div>

                  <div className="space-y-1.5">
                    {activeCitations.map((cite, i) => (
                      <div key={i} className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 text-[10px]">
                        <div className="font-bold text-slate-900">
                          {cite.title} &mdash; <span className="font-serif italic text-slate-600">{cite.journal} ({cite.year})</span>
                        </div>
                        <div className="text-slate-600 mt-0.5 flex items-center gap-2">
                          <span className="font-mono text-blue-700 font-bold">PMID: {cite.pmid}</span>
                          <span>&bull;</span>
                          <span className="font-semibold text-emerald-700">{cite.evidenceLevel}</span>
                          <span>&bull;</span>
                          <span>{cite.keyEvidence}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Custom Addendum if provided */}
              {customAddendum.trim() && (
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-[11px] text-slate-800 space-y-1 page-break-inside-avoid">
                  <div className="font-bold text-slate-900 uppercase text-[10px]">Attending Physician Clinical Addendum:</div>
                  <p className="leading-relaxed italic">{customAddendum}</p>
                </div>
              )}

              {/* ========================================================
                  SECTION 8: PHYSICIAN ATTESTATION, SIGNATURE & QR CODE
                  ======================================================== */}
              {includeDoctorSignature && (
                <div className="pt-4 border-t-2 border-slate-900 page-break-inside-avoid">
                  <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 items-end">
                    
                    {/* Attestation Statement */}
                    <div className="sm:col-span-8 space-y-2 text-[10px] text-slate-600">
                      <p className="leading-relaxed">
                        <strong>Physician Attestation:</strong> I certify that I have conducted a clinical review of the diagnostic imaging findings, pharmacotherapy prescription orders (Rx), AI-assisted double verification, and structured management plan herein. The diagnostic impression and therapeutic recommendations are consistent with current peer-reviewed clinical guidelines.
                      </p>

                      <div className="pt-2 flex items-center gap-6">
                        <div>
                          <div className="font-serif text-base text-blue-900 font-bold italic tracking-wide">
                            {attendingDoctor}
                          </div>
                          <div className="w-48 border-b border-slate-900 mt-1" />
                          <div className="text-[10px] font-bold text-slate-800 mt-0.5">
                            {attendingDoctor}
                          </div>
                          <div className="text-[9px] text-slate-500 font-mono">
                            License: {doctorLicense} &bull; {deaNumber}
                          </div>
                        </div>

                        <div>
                          <div className="text-[10px] font-bold text-slate-800">
                            {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: '2-digit' })}
                          </div>
                          <div className="w-24 border-b border-slate-900 mt-1" />
                          <div className="text-[9px] text-slate-500">Date of Attestation</div>
                        </div>
                      </div>
                    </div>

                    {/* QR Code & Security Stamp */}
                    {includeSecurityQR && (
                      <div className="sm:col-span-4 flex flex-col items-center sm:items-end justify-center text-center sm:text-right">
                        <div className="p-2 bg-white border-2 border-slate-900 rounded-xl shadow-2xs">
                          <QrCode className="w-14 h-14 text-slate-900" />
                        </div>
                        <div className="text-[8px] font-mono text-slate-500 mt-1 uppercase font-bold">
                          CRYPTOGRAPHIC AUDIT SEAL
                        </div>
                        <div className="text-[8px] font-mono text-slate-400">
                          HASH: {Math.random().toString(36).substring(2, 10).toUpperCase()}-SHA256
                        </div>
                      </div>
                    )}

                  </div>
                </div>
              )}

              {/* ========================================================
                  DOCUMENT COMPLIANCE FOOTER
                  ======================================================== */}
              <div className="pt-4 border-t border-slate-300 text-[9px] text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
                <div>
                  CONFIDENTIAL HEALTHCARE RECORD &bull; PROTECTED HEALTH INFORMATION (PHI) UNDER HIPAA & ISO 27001
                </div>
                <div className="font-mono">
                  MediScan Health Clinical Engine &bull; Page 1 of 1
                </div>
              </div>

            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
