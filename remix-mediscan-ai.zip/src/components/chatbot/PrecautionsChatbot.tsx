import React, { useState, useEffect, useCallback, useRef } from 'react';
import { 
  Bot, 
  Send, 
  AlertTriangle, 
  ShieldAlert, 
  PhoneCall, 
  CheckCircle2, 
  XCircle, 
  Sparkles, 
  HelpCircle, 
  Flame, 
  HeartPulse, 
  Brain, 
  Magnet, 
  Syringe, 
  Wind, 
  Bandage, 
  Smile, 
  Clock, 
  RefreshCw, 
  History,
  Info,
  ChevronRight,
  Database,
  Volume2,
  VolumeX,
  Languages,
  Globe,
  User as UserIcon,
  MessageSquare,
  Thermometer,
  Activity,
  Zap,
  Droplet,
  Pill,
  Stethoscope,
  Search,
  HeartHandshake,
  BookOpen,
  ShieldCheck,
  Layers,
  LifeBuoy
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { EmergencyTriageResponse, PrecautionChatRecord } from '../../types';

interface PrecautionsChatbotProps {
  initialCategory?: string;
  isFloatingModal?: boolean;
  onClose?: () => void;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text?: string;
  response?: EmergencyTriageResponse;
  timestamp: string;
  category?: string;
}

const QUICK_PRECAUTIONS_TOPICS = [
  {
    id: 'chest_pain',
    title: 'Severe Chest Pain / Heart Attack',
    shortLabel: 'Chest Pain / Heart',
    icon: HeartPulse,
    categoryGroup: 'Cardiovascular',
    color: 'rose',
    prompt: 'What immediate precautions and solutions should I take for sudden crushing chest pain and left arm tightness?',
  },
  {
    id: 'stroke_fast',
    title: 'Suspected Stroke (FAST Protocol)',
    shortLabel: 'Stroke FAST',
    icon: Brain,
    categoryGroup: 'Neurology',
    color: 'amber',
    prompt: 'How to perform FAST stroke test and what immediate precautions for facial drooping and slurred speech?',
  },
  {
    id: 'seizure_epilepsy',
    title: 'Seizure & Convulsions First Aid',
    shortLabel: 'Seizures & Fits',
    icon: Zap,
    categoryGroup: 'Neurology',
    color: 'purple',
    prompt: 'What immediate precautions and first aid should be given during and after an active seizure or epileptic fit?',
  },
  {
    id: 'dyspnea_asthma',
    title: 'Acute Asthma & Shortness of Breath',
    shortLabel: 'Asthma / Breathlessness',
    icon: Wind,
    categoryGroup: 'Respiratory',
    color: 'cyan',
    prompt: 'What immediate first-aid positioning, inhaler precautions, and solutions for severe wheezing and difficulty breathing?',
  },
  {
    id: 'fever_infection',
    title: 'High Fever, Dengue & Viral Flu',
    shortLabel: 'High Fever & Flu',
    icon: Thermometer,
    categoryGroup: 'Infections',
    color: 'orange',
    prompt: 'What immediate precautions, safe temperature reduction, and home care solutions for high fever above 102°F?',
  },
  {
    id: 'gastro_poisoning',
    title: 'Food Poisoning & Stomach Cramps',
    shortLabel: 'Food Poisoning / Vomit',
    icon: Stethoscope,
    categoryGroup: 'Gastrointestinal',
    color: 'emerald',
    prompt: 'What immediate solutions and hydration precautions for severe acute food poisoning, diarrhea, and vomiting?',
  },
  {
    id: 'diabetes_hypo',
    title: 'Diabetic Low Sugar (Hypoglycemia)',
    shortLabel: 'Low Blood Sugar Crash',
    icon: Droplet,
    categoryGroup: 'Endocrine',
    color: 'blue',
    prompt: 'What immediate precautions and the Rule of 15 solution for a sudden diabetic low blood sugar crash?',
  },
  {
    id: 'trauma_bleeding',
    title: 'Severe Bleeding & Open Wounds',
    shortLabel: 'Bleeding & Trauma',
    icon: Bandage,
    categoryGroup: 'Emergency First Aid',
    color: 'rose',
    prompt: 'What are the immediate clinical precautions, direct pressure protocol, and first aid for heavy hemorrhage and trauma?',
  },
  {
    id: 'burns_scalds',
    title: 'Burn Injuries & Thermal Scalds',
    shortLabel: 'Burns & Scalds',
    icon: Flame,
    categoryGroup: 'Emergency First Aid',
    color: 'orange',
    prompt: 'What immediate first-aid cooling solutions and precautions should be taken for thermal burns and boiling water scalds?',
  },
  {
    id: 'anaphylaxis_allergy',
    title: 'Severe Allergy & Anaphylaxis (EpiPen)',
    shortLabel: 'Allergies & Stings',
    icon: ShieldAlert,
    categoryGroup: 'Allergy & Immunology',
    color: 'red',
    prompt: 'What immediate precautions, EpiPen steps, and positioning for severe allergic throat swelling and bee sting reaction?',
  },
  {
    id: 'panic_anxiety',
    title: 'Panic Attack & Acute Anxiety Surge',
    shortLabel: 'Panic Attack Relief',
    icon: Smile,
    categoryGroup: 'Mental Health',
    color: 'teal',
    prompt: 'What immediate sensory grounding and breathing solutions to stop a sudden severe panic attack and hyperventilation?',
  },
  {
    id: 'mri_metal',
    title: 'MRI Metal & Implant Safety Protocol',
    shortLabel: 'MRI Pre-Scan Rules',
    icon: Magnet,
    categoryGroup: 'Diagnostic Safety',
    color: 'indigo',
    prompt: 'What are the critical pre-scan safety precautions, pacemaker checks, and metal implant rules for MRI screening?',
  },
];

const HEALTH_CATEGORIES_FILTER = [
  'All Solutions',
  'Cardiovascular',
  'Neurology',
  'Respiratory',
  'Infections',
  'Gastrointestinal',
  'Emergency First Aid',
  'Diagnostic Safety'
];

export const PrecautionsChatbot: React.FC<PrecautionsChatbotProps> = ({
  initialCategory,
  isFloatingModal = false,
  onClose,
}) => {
  const { user, chatHistory, addChatRecord } = useAuth();
  const { language, currentLanguageInfo, t, speakText, stopSpeaking, isSpeaking, translateClinicalText } = useLanguage();

  const [inputQuery, setInputQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>(initialCategory || 'General Health & Immediate Precautions');
  const [categoryFilter, setCategoryFilter] = useState<string>('All Solutions');
  const [topicSearchTerm, setTopicSearchTerm] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [currentResponse, setCurrentResponse] = useState<EmergencyTriageResponse | null>(null);
  const [activeTab, setActiveTab] = useState<'chat' | 'history'>('chat');
  const [pastRecords, setPastRecords] = useState<PrecautionChatRecord[]>([]);
  const [translatedSummary, setTranslatedSummary] = useState<string | null>(null);
  const [isTranslating, setIsTranslating] = useState(false);

  // Dedicated conversational message stream for floating modal
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-1',
      sender: 'bot',
      text: 'Hello! I am your 24/7 Clinical Health Solutions & Immediate Precautions AI. Ask any health query or select an emergency topic below for instant life-saving directives, first aid, safe home remedies, and specialist guidance.',
      timestamp: new Date().toISOString(),
    }
  ]);

  const floatingMessagesEndRef = useRef<HTMLDivElement | null>(null);

  const scrollToBottom = useCallback(() => {
    if (floatingMessagesEndRef.current) {
      floatingMessagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, []);

  useEffect(() => {
    if (isFloatingModal) {
      scrollToBottom();
    }
  }, [messages, isFloatingModal, scrollToBottom]);

  // Handle dynamic translation of current response
  const handleTranslateResponse = async () => {
    if (!currentResponse) return;
    setIsTranslating(true);
    try {
      const fullTextToTranslate = `${currentResponse.summary}. Immediate steps: ${currentResponse.immediateSteps.join('. ')}. Home Care: ${(currentResponse.homeRemediesAndCare || []).join('. ')}`;
      const result = await translateClinicalText(fullTextToTranslate, language);
      setTranslatedSummary(result);
    } catch (e) {
      console.warn('Translate response failed:', e);
    } finally {
      setIsTranslating(false);
    }
  };

  // Load chat history from MongoDB once
  const loadMongoChatHistory = useCallback(async () => {
    try {
      const res = await fetch('/api/db/collections/chat_history');
      if (res.ok) {
        const data = await res.json();
        if (data.success && Array.isArray(data.data)) {
          setPastRecords(data.data);
          return;
        }
      }
      setPastRecords(chatHistory || []);
    } catch (e) {
      console.warn('MongoDB chat history load:', e);
      setPastRecords(chatHistory || []);
    }
  }, [chatHistory]);

  useEffect(() => {
    loadMongoChatHistory();
  }, [loadMongoChatHistory]);

  const handleAskPrecaution = async (questionText: string, category = activeCategory) => {
    if (!questionText.trim() || isLoading) return;
    
    const userMsgId = `usr-${Date.now()}`;
    const userText = questionText.trim();
    
    // Add user message to floating stream
    if (isFloatingModal) {
      setMessages((prev) => [
        ...prev,
        {
          id: userMsgId,
          sender: 'user',
          text: userText,
          timestamp: new Date().toISOString(),
          category,
        }
      ]);
    }

    setIsLoading(true);
    setInputQuery('');
    setTranslatedSummary(null);

    try {
      const res = await fetch('/api/ai/precautions-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: userText,
          category,
          userEmail: user?.email || 'drushtishree1@gmail.com',
          userRole: user?.role || 'patient',
        }),
      });

      const data = await res.json();
      if (data.success && data.result) {
        setCurrentResponse(data.result);
        if (data.savedRecord) {
          addChatRecord(data.savedRecord);
          setPastRecords((prev) => [data.savedRecord, ...prev]);
        }

        if (isFloatingModal) {
          setMessages((prev) => [
            ...prev,
            {
              id: `bot-${Date.now()}`,
              sender: 'bot',
              response: data.result,
              timestamp: new Date().toISOString(),
              category,
            }
          ]);
        }
      } else {
        throw new Error(data.message || 'Failed to retrieve response');
      }
    } catch (e: any) {
      console.error('Error asking precautions chatbot:', e);
      const fallbackResponse: EmergencyTriageResponse = {
        triageLevel: 'urgent',
        category,
        summary: 'Maintain calm, ensure airway stability, and follow established clinical precautions.',
        immediateSteps: [
          'Position patient safely in high Fowler\'s or resting recovery position',
          'Check airway, breathing, and pulse cadence continuously',
          'Call emergency room dispatch (108 / 112 / 911) without delay for severe symptoms',
          'Document symptom onset timeline for paramedic crew',
        ],
        avoidActions: [
          'Do not give oral fluids or solid food if patient is disoriented or choking',
          'Do not exert physically or delay seeking medical attention',
        ],
        fullDetailedAnswer: 'Standard emergency precautions apply. Maintain patient calm and monitor vital signs until professional medical assistance arrives.',
        redFlagWarnings: ['Loss of consciousness', 'Severe acute chest pressure', 'Labored breathing', 'Severe unyielding pain'],
        recommendedEmergencyContacts: ['108 / 112 (India)', '911 (US/Canada)', '999 (UK)'],
        homeRemediesAndCare: ['Quiet resting posture with adequate room ventilation', 'Hydration with clean water if conscious'],
        medicationGuidance: ['Avoid unverified self-medication until evaluated by a licensed physician'],
        doctorConsultAdvice: 'Consult a General Physician or nearest Emergency Department for definitive clinical evaluation.',
        preventionTips: ['Schedule regular preventative health checkups and maintain emergency contact numbers'],
      };

      setCurrentResponse(fallbackResponse);
      if (isFloatingModal) {
        setMessages((prev) => [
          ...prev,
          {
            id: `bot-${Date.now()}`,
            sender: 'bot',
            response: fallbackResponse,
            timestamp: new Date().toISOString(),
            category,
          }
        ]);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleAskPrecaution(inputQuery);
  };

  // Filter topics for left sidebar
  const filteredTopics = QUICK_PRECAUTIONS_TOPICS.filter((t) => {
    const matchesCategory = categoryFilter === 'All Solutions' || t.categoryGroup === categoryFilter;
    const matchesSearch = !topicSearchTerm || t.title.toLowerCase().includes(topicSearchTerm.toLowerCase()) || t.shortLabel.toLowerCase().includes(topicSearchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // ==========================================
  // FLOATING MODAL COMPACT VIEW
  // ==========================================
  if (isFloatingModal) {
    return (
      <div className="flex flex-col h-full bg-slate-50 text-slate-900 overflow-hidden">
        {/* Quick Suggestion Topic Chips Header */}
        <div className="p-2.5 bg-white border-b border-slate-200 shrink-0 overflow-x-auto">
          <div className="flex items-center gap-1.5 min-w-max">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1 mr-1">
              <Sparkles className="w-3 h-3 text-rose-600" />
              <span>Solutions:</span>
            </span>
            {QUICK_PRECAUTIONS_TOPICS.slice(0, 8).map((topic) => {
              const Icon = topic.icon;
              return (
                <button
                  key={topic.id}
                  type="button"
                  onClick={() => {
                    setActiveCategory(topic.title);
                    handleAskPrecaution(topic.prompt, topic.title);
                  }}
                  className="px-2.5 py-1 text-[11px] font-bold bg-slate-100 hover:bg-rose-50 text-slate-700 hover:text-rose-700 border border-slate-200 hover:border-rose-300 rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <Icon className="w-3 h-3 text-rose-600" />
                  <span>{topic.shortLabel}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Message Thread Area */}
        <div className="flex-1 overflow-y-auto p-3 space-y-3">
          {messages.map((msg) => {
            if (msg.sender === 'user') {
              return (
                <div key={msg.id} className="flex justify-end">
                  <div className="max-w-[85%] p-3 bg-rose-600 text-white rounded-2xl rounded-tr-xs text-xs font-medium shadow-xs">
                    <p className="leading-relaxed">{msg.text}</p>
                    <span className="text-[9px] text-rose-200 block text-right mt-1 font-mono">
                      {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                </div>
              );
            }

            // Bot Response
            const resp = msg.response;
            return (
              <div key={msg.id} className="flex gap-2 items-start">
                <div className="w-6 h-6 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center shrink-0 mt-0.5 border border-rose-200">
                  <Bot className="w-3.5 h-3.5" />
                </div>

                <div className="flex-1 max-w-[90%] space-y-2">
                  {msg.text && (
                    <div className="p-3 bg-white border border-slate-200 text-slate-800 rounded-2xl rounded-tl-xs text-xs shadow-xs">
                      <p className="leading-relaxed">{msg.text}</p>
                    </div>
                  )}

                  {resp && (
                    <div className="p-3.5 bg-white border border-slate-200 rounded-2xl rounded-tl-xs text-xs shadow-xs space-y-2.5">
                      {/* Triage Badge */}
                      <div className="flex items-center justify-between">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider ${
                          resp.triageLevel === 'critical'
                            ? 'bg-rose-100 text-rose-800 border border-rose-300'
                            : resp.triageLevel === 'urgent'
                            ? 'bg-amber-100 text-amber-800 border border-amber-300'
                            : 'bg-blue-100 text-blue-800 border border-blue-300'
                        }`}>
                          {resp.triageLevel} TRIAGE
                        </span>
                        <button
                          onClick={() => {
                            if (isSpeaking) stopSpeaking();
                            else speakText(`${resp.summary}. Steps: ${resp.immediateSteps.join('. ')}`);
                          }}
                          className="text-[10px] font-bold text-blue-700 hover:text-blue-900 flex items-center gap-1 cursor-pointer"
                        >
                          {isSpeaking ? <VolumeX className="w-3 h-3 text-rose-500" /> : <Volume2 className="w-3 h-3" />}
                          <span>{isSpeaking ? 'Stop' : 'Listen'}</span>
                        </button>
                      </div>

                      {/* Summary */}
                      <p className="font-bold text-slate-900 leading-snug">
                        {resp.summary}
                      </p>

                      {/* Immediate Steps */}
                      <div className="space-y-1 pt-1">
                        <div className="text-[10px] font-extrabold text-emerald-800 uppercase tracking-wider flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          <span>Immediate Steps:</span>
                        </div>
                        {resp.immediateSteps.slice(0, 3).map((step, idx) => (
                          <div key={idx} className="flex items-start gap-1.5 text-[11px] text-slate-800 font-medium">
                            <span className="w-4 h-4 rounded-full bg-emerald-600 text-white text-[9px] font-black flex items-center justify-center shrink-0 mt-0.5">
                              {idx + 1}
                            </span>
                            <span className="leading-snug">{step}</span>
                          </div>
                        ))}
                      </div>

                      {/* Home Care if available */}
                      {resp.homeRemediesAndCare && resp.homeRemediesAndCare.length > 0 && (
                        <div className="p-2 rounded-xl bg-blue-50/70 border border-blue-100 text-[11px] text-blue-900 space-y-1">
                          <div className="font-bold text-[10px] uppercase tracking-wider text-blue-800">
                            🌿 Safe Home Care Solution:
                          </div>
                          <p className="leading-snug">{resp.homeRemediesAndCare[0]}</p>
                        </div>
                      )}

                      {/* Emergency Hotline Buttons */}
                      <div className="pt-2 border-t border-slate-100 flex items-center gap-2">
                        <a
                          href="tel:108"
                          className="px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-[10px] flex items-center gap-1"
                        >
                          <PhoneCall className="w-3 h-3" />
                          <span>Call 108 / 112</span>
                        </a>
                        <a
                          href="tel:911"
                          className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold text-[10px] flex items-center gap-1"
                        >
                          <PhoneCall className="w-3 h-3 text-rose-400" />
                          <span>Call 911</span>
                        </a>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}

          {isLoading && (
            <div className="flex gap-2 items-center text-xs text-slate-500 bg-white p-3 rounded-2xl border border-slate-200">
              <RefreshCw className="w-4 h-4 text-rose-600 animate-spin" />
              <span className="font-medium">Formulating clinical solutions & emergency precautions...</span>
            </div>
          )}

          <div ref={floatingMessagesEndRef} />
        </div>

        {/* Fixed Chat Input Bar at Bottom */}
        <form onSubmit={handleFormSubmit} className="p-2.5 bg-white border-t border-slate-200 shrink-0">
          <div className="relative flex items-center">
            <input
              type="text"
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              placeholder="Ask any health question or symptom..."
              className="w-full pl-3 pr-10 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-rose-500 focus:ring-1 focus:ring-rose-500 transition-colors font-medium"
            />
            <button
              type="submit"
              disabled={isLoading || !inputQuery.trim()}
              className="absolute right-1.5 p-1.5 bg-rose-600 hover:bg-rose-700 disabled:opacity-40 text-white rounded-lg transition-colors cursor-pointer"
            >
              {isLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
            </button>
          </div>
        </form>
      </div>
    );
  }

  // ==========================================
  // FULL-PAGE COMPREHENSIVE VIEW
  // ==========================================
  return (
    <div className="space-y-6">
      {/* Top Header Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-slate-900 via-rose-950/90 to-slate-900 border border-rose-500/30 text-white shadow-xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-start gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-tr from-rose-600 to-amber-500 text-white shadow-md border border-rose-400/40 shrink-0">
              <ShieldAlert className="h-6 w-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white">
                  Clinical Health Solutions & Immediate Precautions AI
                </h1>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40">
                  24/7 RAPID TRIAGE
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1 max-w-2xl font-normal leading-relaxed">
                Evidence-grounded solutions for all health problems, acute symptoms, first-aid directives, safe home remedies, and pre/post-diagnostic scan safety rules with automatic MongoDB audit persistence.
              </p>
            </div>
          </div>

          {/* Emergency Hotline Dial Badges */}
          <div className="flex flex-wrap items-center gap-2">
            <a
              href="tel:108"
              className="px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-rose-600/30 transition-all cursor-pointer"
            >
              <PhoneCall className="w-3.5 h-3.5" />
              <span>Call 108 / 112 (India)</span>
            </a>
            <a
              href="tel:911"
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
            >
              <PhoneCall className="w-3.5 h-3.5 text-rose-400" />
              <span>Call 911 (US/CA)</span>
            </a>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 mt-6 pt-4 border-t border-slate-800/80">
          <button
            onClick={() => setActiveTab('chat')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'chat'
                ? 'bg-rose-600 text-white shadow-md'
                : 'bg-slate-800/60 text-slate-400 hover:text-white'
            }`}
          >
            <Bot className="w-3.5 h-3.5" />
            <span>AI Health Solutions & Triage</span>
          </button>
          <button
            onClick={() => { setActiveTab('history'); loadMongoChatHistory(); }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'history'
                ? 'bg-rose-600 text-white shadow-md'
                : 'bg-slate-800/60 text-slate-400 hover:text-white'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>MongoDB Triage History ({pastRecords.length})</span>
          </button>
        </div>
      </div>

      {activeTab === 'chat' ? (
        <div className="grid lg:grid-cols-12 gap-6">
          
          {/* Left Column: Category Filter & Quick Topic Cards */}
          <div className="lg:col-span-4 space-y-3">
            
            {/* Category Search & Filter */}
            <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-700">Health Problem Categories</span>
                <span className="text-[10px] text-slate-400">{filteredTopics.length} Topics</span>
              </div>

              {/* Search Bar */}
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={topicSearchTerm}
                  onChange={(e) => setTopicSearchTerm(e.target.value)}
                  placeholder="Search symptom, disease, first-aid..."
                  className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-rose-500 font-medium"
                />
              </div>

              {/* Category Filter Chips */}
              <div className="flex flex-wrap gap-1 max-h-24 overflow-y-auto">
                {HEALTH_CATEGORIES_FILTER.map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setCategoryFilter(cat)}
                    className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition-all cursor-pointer ${
                      categoryFilter === cat
                        ? 'bg-rose-600 text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* List of Topic Buttons */}
            <div className="space-y-2 max-h-[580px] overflow-y-auto pr-1">
              {filteredTopics.map((topic) => {
                const Icon = topic.icon;
                return (
                  <button
                    key={topic.id}
                    type="button"
                    onClick={() => {
                      setActiveCategory(topic.title);
                      handleAskPrecaution(topic.prompt, topic.title);
                    }}
                    className="w-full p-3 rounded-2xl bg-white hover:bg-slate-50 border border-slate-200 hover:border-rose-300 shadow-2xs hover:shadow-xs transition-all text-left flex items-center justify-between group cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-xl bg-rose-50 text-rose-600 group-hover:scale-105 transition-transform shrink-0">
                        <Icon className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-800 group-hover:text-rose-700">
                          {topic.title}
                        </div>
                        <div className="text-[10px] text-slate-400 mt-0.5 flex items-center gap-1.5">
                          <span className="font-semibold text-rose-600/80">{topic.categoryGroup}</span>
                          <span>&bull;</span>
                          <span>Tap for solution &rarr;</span>
                        </div>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-rose-600 transition-all shrink-0" />
                  </button>
                );
              })}
            </div>

            {/* Clinical Guidance Notice */}
            <div className="p-4 rounded-2xl bg-slate-900 text-slate-300 border border-slate-800 text-xs space-y-2">
              <div className="flex items-center gap-1.5 text-amber-400 font-bold text-[11px] uppercase tracking-wider">
                <AlertTriangle className="w-3.5 h-3.5" /> Emergency Support Directive
              </div>
              <p className="text-[11px] leading-relaxed text-slate-400">
                MediScan AI provides rapid, evidence-grounded precautions, first-aid, and safe home remedies. In life-threatening emergencies, dial emergency dispatch immediately.
              </p>
            </div>
          </div>

          {/* Right Column: Query Form & Comprehensive Clinical Solution Card */}
          <div className="lg:col-span-8 space-y-4">
            
            {/* Input Question Bar */}
            <form onSubmit={handleFormSubmit} className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-800 flex items-center gap-1.5">
                  <Stethoscope className="w-4 h-4 text-rose-600" />
                  <span>Ask Solutions & Immediate Precautions for ANY Health Problem</span>
                </span>
                <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200 flex items-center gap-1">
                  <Database className="w-3 h-3" /> Auto-saved in MongoDB
                </span>
              </div>

              <div className="relative">
                <input
                  type="text"
                  value={inputQuery}
                  onChange={(e) => setInputQuery(e.target.value)}
                  placeholder="e.g., What immediate solutions and precautions for high fever in child, sudden asthma wheezing, or severe stomach pain?"
                  className="w-full pl-4 pr-12 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-rose-500 focus:ring-1 focus:ring-rose-500 transition-colors font-medium"
                />
                <button
                  type="submit"
                  disabled={isLoading || !inputQuery.trim()}
                  className="absolute right-2 top-2 p-2 bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white rounded-lg transition-colors cursor-pointer"
                >
                  {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                </button>
              </div>

              {/* Sample Query Suggestions */}
              <div className="flex items-center gap-1.5 flex-wrap pt-1">
                <span className="text-[10px] font-bold text-slate-400">Try asking:</span>
                {[
                  'Remedies for food poisoning & vomiting',
                  'First aid for 2nd degree burn',
                  'Low blood sugar Rule of 15',
                  'Panic attack box breathing'
                ].map((sugg, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => {
                      setInputQuery(sugg);
                      handleAskPrecaution(sugg);
                    }}
                    className="px-2 py-0.5 rounded-md bg-slate-100 hover:bg-rose-50 text-slate-600 hover:text-rose-700 text-[10px] font-medium transition-colors cursor-pointer"
                  >
                    {sugg}
                  </button>
                ))}
              </div>
            </form>

            {/* Active AI Clinical Solution Display */}
            {isLoading ? (
              <div className="p-12 rounded-3xl bg-white border border-slate-200 text-center space-y-3 shadow-2xs">
                <RefreshCw className="w-8 h-8 text-rose-600 animate-spin mx-auto" />
                <div className="text-sm font-bold text-slate-800">Generating Comprehensive Clinical Solutions & Precautions...</div>
                <div className="text-xs text-slate-400">Consulting emergency triage knowledgebase and recording session in MongoDB</div>
              </div>
            ) : currentResponse ? (
              <div className="rounded-3xl bg-white border border-slate-200 shadow-sm overflow-hidden space-y-0">
                {/* Triage Level Banner */}
                <div className={`p-4 text-white flex items-center justify-between ${
                  currentResponse.triageLevel === 'critical'
                    ? 'bg-gradient-to-r from-rose-600 to-red-700'
                    : currentResponse.triageLevel === 'urgent'
                    ? 'bg-gradient-to-r from-amber-600 to-orange-600'
                    : 'bg-gradient-to-r from-blue-600 to-cyan-600'
                }`}>
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5" />
                    <div>
                      <div className="text-xs font-extrabold uppercase tracking-wider">
                        Triage Assessment: {currentResponse.triageLevel.toUpperCase()}
                      </div>
                      <div className="text-[11px] opacity-90 font-medium">{currentResponse.category}</div>
                    </div>
                  </div>

                  <span className="px-3 py-1 rounded-full text-xs font-mono font-black bg-black/30 border border-white/20">
                    STATUS: {currentResponse.triageLevel === 'critical' ? 'ACT IMMEDIATELY' : 'FOLLOW PROTOCOL'}
                  </span>
                </div>

                <div className="p-6 space-y-6">
                  {/* Language Audio Readout & Live Translator Toolbar */}
                  <div className="flex flex-wrap items-center justify-between gap-2 p-3 bg-blue-50/80 border border-blue-200/70 rounded-2xl">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          if (isSpeaking) {
                            stopSpeaking();
                          } else {
                            const speechContent = translatedSummary || `${currentResponse.summary}. Steps: ${currentResponse.immediateSteps.join('. ')}. Home Care: ${(currentResponse.homeRemediesAndCare || []).join('. ')}`;
                            speakText(speechContent);
                          }
                        }}
                        className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-2xs transition-all cursor-pointer"
                      >
                        {isSpeaking ? (
                          <>
                            <VolumeX className="w-3.5 h-3.5 text-rose-300" />
                            <span>{t('stop_audio')}</span>
                          </>
                        ) : (
                          <>
                            <Volume2 className="w-3.5 h-3.5" />
                            <span>Listen ({currentLanguageInfo.nativeName})</span>
                          </>
                        )}
                      </button>

                      {language !== 'en' && (
                        <button
                          onClick={handleTranslateResponse}
                          disabled={isTranslating}
                          className="px-3 py-1.5 rounded-xl bg-white hover:bg-slate-50 text-blue-800 border border-blue-200 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
                        >
                          <Globe className="w-3.5 h-3.5 text-blue-600" />
                          <span>{isTranslating ? 'Translating...' : `${t('translate_button')} ${currentLanguageInfo.nativeName}`}</span>
                        </button>
                      )}
                    </div>

                    <span className="text-[11px] font-semibold text-slate-500 flex items-center gap-1">
                      <span>{currentLanguageInfo.flag}</span>
                      <span>Voice: {currentLanguageInfo.speechCode}</span>
                    </span>
                  </div>

                  {/* Dynamic Translated Summary Box (if requested) */}
                  {translatedSummary && (
                    <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-200 text-xs text-amber-950 space-y-1">
                      <div className="font-bold flex items-center gap-1.5 text-amber-900 text-[11px] uppercase tracking-wider">
                        <Globe className="w-3.5 h-3.5 text-amber-600" />
                        <span>Translated to {currentLanguageInfo.name} ({currentLanguageInfo.nativeName})</span>
                      </div>
                      <p className="leading-relaxed font-medium whitespace-pre-line">{translatedSummary}</p>
                    </div>
                  )}

                  {/* Summary Directives */}
                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-800 leading-relaxed flex items-start gap-2.5">
                    <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                    <span>{currentResponse.summary}</span>
                  </div>

                  {/* Section 1: Immediate Steps Numbered List */}
                  <div>
                    <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider flex items-center gap-2 mb-3">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      Immediate Action Items (What to Do Right Now)
                    </h4>
                    <div className="space-y-2">
                      {currentResponse.immediateSteps.map((step, idx) => (
                        <div
                          key={idx}
                          className="p-3 rounded-xl bg-emerald-50/60 border border-emerald-200/80 flex items-start gap-3 text-xs text-slate-800"
                        >
                          <span className="flex h-5 w-5 rounded-full bg-emerald-600 text-white font-bold text-[10px] items-center justify-center shrink-0 mt-0.5">
                            {idx + 1}
                          </span>
                          <span className="font-medium leading-relaxed">{step}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Section 2: What NOT to do */}
                  {currentResponse.avoidActions && currentResponse.avoidActions.length > 0 && (
                    <div>
                      <h4 className="text-xs font-black text-rose-800 uppercase tracking-wider flex items-center gap-2 mb-2">
                        <XCircle className="w-4 h-4 text-rose-600" />
                        Critical Pitfalls to AVOID
                      </h4>
                      <div className="space-y-1.5">
                        {currentResponse.avoidActions.map((avoid, idx) => (
                          <div
                            key={idx}
                            className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 flex items-start gap-2.5 text-xs text-rose-900"
                          >
                            <span className="text-rose-600 font-bold text-sm leading-none">&times;</span>
                            <span className="font-medium">{avoid}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Section 3: Safe Home Remedies & Care Solutions */}
                  {currentResponse.homeRemediesAndCare && currentResponse.homeRemediesAndCare.length > 0 && (
                    <div className="p-4 rounded-2xl bg-teal-50/70 border border-teal-200 text-xs space-y-2">
                      <div className="font-bold text-teal-950 flex items-center gap-2 text-[11px] uppercase tracking-wider">
                        <HeartHandshake className="w-4 h-4 text-teal-700" />
                        <span>Evidence-Based Safe Home Solutions & Care:</span>
                      </div>
                      <div className="space-y-1.5 text-teal-900 font-medium">
                        {currentResponse.homeRemediesAndCare.map((remedy, idx) => (
                          <div key={idx} className="flex items-start gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-teal-600 mt-1.5 shrink-0" />
                            <span>{remedy}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Section 4: Safe Medication & Pharmacy Guidance */}
                  {currentResponse.medicationGuidance && currentResponse.medicationGuidance.length > 0 && (
                    <div className="p-4 rounded-2xl bg-indigo-50/70 border border-indigo-200 text-xs space-y-2">
                      <div className="font-bold text-indigo-950 flex items-center gap-2 text-[11px] uppercase tracking-wider">
                        <Pill className="w-4 h-4 text-indigo-700" />
                        <span>Safe Medication & Pharmacy Guidance:</span>
                      </div>
                      <div className="space-y-1.5 text-indigo-900 font-medium">
                        {currentResponse.medicationGuidance.map((med, idx) => (
                          <div key={idx} className="flex items-start gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-indigo-600 mt-1.5 shrink-0" />
                            <span>{med}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Section 5: Specialist Doctor Consultation Advice */}
                  {currentResponse.doctorConsultAdvice && (
                    <div className="p-4 rounded-2xl bg-sky-50 border border-sky-200 text-xs flex items-start gap-3">
                      <Stethoscope className="w-5 h-5 text-sky-700 shrink-0 mt-0.5" />
                      <div>
                        <div className="font-bold text-sky-950 text-[11px] uppercase tracking-wider mb-0.5">
                          When & Which Specialist to Consult:
                        </div>
                        <p className="text-sky-900 font-medium leading-relaxed">
                          {currentResponse.doctorConsultAdvice}
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Section 6: Red Flag Warnings */}
                  {currentResponse.redFlagWarnings && currentResponse.redFlagWarnings.length > 0 && (
                    <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-xs">
                      <div className="font-bold text-amber-900 flex items-center gap-1.5 mb-2">
                        <AlertTriangle className="w-4 h-4 text-amber-600" />
                        Emergency Red Flag Symptoms (Call Ambulance Immediately If Observed):
                      </div>
                      <ul className="list-disc list-inside space-y-1 text-amber-800 font-medium">
                        {currentResponse.redFlagWarnings.map((warn, i) => (
                          <li key={i}>{warn}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Section 7: Prevention & Long-Term Health Tips */}
                  {currentResponse.preventionTips && currentResponse.preventionTips.length > 0 && (
                    <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-2">
                      <div className="font-bold text-slate-800 flex items-center gap-2 text-[11px] uppercase tracking-wider">
                        <ShieldCheck className="w-4 h-4 text-emerald-600" />
                        <span>Prevention & Recovery Habits:</span>
                      </div>
                      <div className="space-y-1 text-slate-700 font-medium">
                        {currentResponse.preventionTips.map((tip, idx) => (
                          <div key={idx} className="flex items-start gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-slate-400 mt-1.5 shrink-0" />
                            <span>{tip}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Section 8: Full Detailed Explanation */}
                  <div className="pt-3 border-t border-slate-200 text-xs text-slate-600 leading-relaxed space-y-2">
                    <div className="font-bold text-slate-800 flex items-center gap-2">
                      <BookOpen className="w-4 h-4 text-rose-600" />
                      <span>Full Clinical Protocol Rationale:</span>
                    </div>
                    <div className="whitespace-pre-line text-slate-700 bg-slate-50 p-4 rounded-xl border border-slate-200 leading-relaxed font-normal">
                      {currentResponse.fullDetailedAnswer}
                    </div>
                  </div>

                  {/* Bottom Action Hotline Bar */}
                  <div className="p-4 rounded-2xl bg-slate-900 text-white flex flex-wrap items-center justify-between gap-3">
                    <div className="text-xs">
                      <div className="font-bold">Need Immediate Emergency Transport?</div>
                      <div className="text-slate-400 text-[11px]">Direct first-responder dispatch lines:</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <a
                        href="tel:108"
                        className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-md"
                      >
                        <PhoneCall className="w-3.5 h-3.5" />
                        <span>Dial 108 / 112</span>
                      </a>
                      <a
                        href="tel:911"
                        className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 font-bold text-xs flex items-center gap-1.5"
                      >
                        <PhoneCall className="w-3.5 h-3.5 text-rose-400" />
                        <span>Dial 911</span>
                      </a>
                    </div>
                  </div>

                </div>
              </div>
            ) : (
              <div className="p-12 rounded-3xl bg-white border border-slate-200 text-center space-y-3 shadow-2xs">
                <Bot className="w-12 h-12 text-slate-300 mx-auto" />
                <h3 className="text-sm font-bold text-slate-800">No Active Health Query</h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  Select any of the common health problem topics on the left or type your own question or symptoms in the bar above.
                </p>
              </div>
            )}

          </div>

        </div>
      ) : (
        /* TAB 2: MongoDB Saved Triage History */
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs">
            <div>
              <h3 className="text-sm font-bold text-slate-800">MongoDB Health Solutions & Triage History</h3>
              <p className="text-xs text-slate-500">
                All inquiries and clinical solutions are persisted in the <code className="font-mono text-emerald-700">chat_history</code> collection.
              </p>
            </div>
            <button
              onClick={loadMongoChatHistory}
              className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Refresh History</span>
            </button>
          </div>

          <div className="space-y-3">
            {pastRecords.length === 0 ? (
              <div className="p-12 text-center text-xs text-slate-400 bg-white rounded-3xl border border-slate-200">
                No past precaution queries recorded in MongoDB yet.
              </div>
            ) : (
              pastRecords.map((item, idx) => (
                <div
                  key={item.id || item._id || idx}
                  className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200">
                      {item.category || 'Health Solutions'}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {new Date(item.timestamp).toLocaleString()}
                    </span>
                  </div>

                  <div className="text-xs font-bold text-slate-900">
                    Q: {item.question}
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700 leading-relaxed whitespace-pre-line">
                    {item.answer}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};
