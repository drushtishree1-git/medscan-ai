import React from 'react';
import { 
  Heart, 
  Activity, 
  Wind, 
  Droplet, 
  Thermometer, 
  TrendingUp, 
  TrendingDown, 
  Minus,
  ShieldCheck, 
  AlertTriangle,
  Plus
} from 'lucide-react';
import { VitalRecord } from '../../types';

interface VitalsSummaryCardsProps {
  latestRecord: VitalRecord | undefined;
  previousRecord: VitalRecord | undefined;
  onOpenLogModal: () => void;
}

export const VitalsSummaryCards: React.FC<VitalsSummaryCardsProps> = ({
  latestRecord,
  previousRecord,
  onOpenLogModal,
}) => {
  if (!latestRecord) {
    return (
      <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm text-center">
        <p className="text-sm text-slate-500">No vitals logged yet.</p>
        <button
          onClick={onOpenLogModal}
          className="mt-3 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-all inline-flex items-center gap-2 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Log First Vital Reading</span>
        </button>
      </div>
    );
  }

  // Calculate trends
  const getTrend = (current?: number, prev?: number) => {
    if (current === undefined || prev === undefined) return { diff: 0, direction: 'same' as const };
    const diff = current - prev;
    if (diff > 0) return { diff, direction: 'up' as const };
    if (diff < 0) return { diff: Math.abs(diff), direction: 'down' as const };
    return { diff: 0, direction: 'same' as const };
  };

  const hrTrend = getTrend(latestRecord.heartRate, previousRecord?.heartRate);
  const sysBpTrend = getTrend(latestRecord.systolicBp, previousRecord?.systolicBp);
  const spo2Trend = getTrend(latestRecord.oxygenSaturation, previousRecord?.oxygenSaturation);
  const glucoseTrend = getTrend(latestRecord.bloodGlucose, previousRecord?.bloodGlucose);

  // BP classification per AHA guidelines
  const getBpCategory = (sys: number, dia: number) => {
    if (sys < 120 && dia < 80) return { label: 'Optimal / Normal', color: 'text-emerald-700 bg-emerald-50 border-emerald-200' };
    if (sys <= 129 && dia < 80) return { label: 'Elevated', color: 'text-amber-700 bg-amber-50 border-amber-200' };
    if (sys <= 139 || dia <= 89) return { label: 'Stage 1 HTN', color: 'text-orange-700 bg-orange-50 border-orange-200' };
    return { label: 'Stage 2 HTN', color: 'text-rose-700 bg-rose-50 border-rose-200' };
  };

  const bpStatus = getBpCategory(latestRecord.systolicBp, latestRecord.diastolicBp);

  return (
    <div className="space-y-4">
      {/* Real-Time Clinical Evaluation Bar */}
      <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-2xl bg-blue-500/20 border border-blue-400/30 flex items-center justify-center shrink-0">
            <Activity className="w-5 h-5 text-blue-300 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-black uppercase tracking-wider text-blue-300 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Cardiopulmonary & Metabolic Status: Optimal Baseline</span>
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                AHA / WHO Normal
              </span>
            </div>
            <p className="text-xs text-blue-100/90 mt-0.5 font-medium">
              Last synced: <strong className="text-white">{latestRecord.date} at {latestRecord.time}</strong> • Context: <span className="text-blue-200 font-semibold">{latestRecord.activityContext || 'Resting'}</span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenLogModal}
            className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md flex items-center gap-2 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Log New Vitals</span>
          </button>
        </div>
      </div>

      {/* 4 Core Vital Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* 1. Heart Rate */}
        <div className="p-5 rounded-3xl bg-white border border-slate-200/90 shadow-sm hover:shadow-md transition-all space-y-3 relative overflow-hidden group">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-2xl bg-rose-50 border border-rose-100 flex items-center justify-center text-rose-600">
                <Heart className="w-4 h-4 text-rose-600 group-hover:scale-110 transition-transform" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wide">Heart Rate</h4>
                <span className="text-[10px] font-medium text-slate-400">Resting Sinus</span>
              </div>
            </div>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
              Optimal (60-100)
            </span>
          </div>

          <div className="flex items-baseline justify-between pt-1">
            <div>
              <span className="text-3xl font-black text-slate-900 tracking-tight">{latestRecord.heartRate}</span>
              <span className="text-xs font-bold text-slate-500 ml-1.5">BPM</span>
            </div>
            <div className="flex items-center gap-1 text-[11px] font-bold text-slate-500">
              {hrTrend.direction === 'up' && <TrendingUp className="w-3.5 h-3.5 text-rose-500" />}
              {hrTrend.direction === 'down' && <TrendingDown className="w-3.5 h-3.5 text-emerald-500" />}
              {hrTrend.direction === 'same' && <Minus className="w-3.5 h-3.5 text-slate-400" />}
              <span>{hrTrend.diff > 0 ? `${hrTrend.diff} bpm` : 'Stable'}</span>
            </div>
          </div>

          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
            <div 
              className="bg-rose-500 h-full rounded-full transition-all duration-500" 
              style={{ width: `${Math.min(100, Math.max(10, ((latestRecord.heartRate - 40) / 100) * 100))}%` }}
            />
          </div>
        </div>

        {/* 2. Blood Pressure */}
        <div className="p-5 rounded-3xl bg-white border border-slate-200/90 shadow-sm hover:shadow-md transition-all space-y-3 relative overflow-hidden group">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600">
                <Activity className="w-4 h-4 text-indigo-600 group-hover:scale-110 transition-transform" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wide">Blood Pressure</h4>
                <span className="text-[10px] font-medium text-slate-400">SYS / DIA</span>
              </div>
            </div>
            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${bpStatus.color}`}>
              {bpStatus.label}
            </span>
          </div>

          <div className="flex items-baseline justify-between pt-1">
            <div>
              <span className="text-3xl font-black text-slate-900 tracking-tight">
                {latestRecord.systolicBp}/{latestRecord.diastolicBp}
              </span>
              <span className="text-xs font-bold text-slate-500 ml-1.5">mmHg</span>
            </div>
            <div className="flex items-center gap-1 text-[11px] font-bold text-slate-500">
              {sysBpTrend.direction === 'up' && <TrendingUp className="w-3.5 h-3.5 text-amber-500" />}
              {sysBpTrend.direction === 'down' && <TrendingDown className="w-3.5 h-3.5 text-emerald-500" />}
              {sysBpTrend.direction === 'same' && <Minus className="w-3.5 h-3.5 text-slate-400" />}
              <span>{sysBpTrend.diff > 0 ? `${sysBpTrend.diff} mmHg` : 'Stable'}</span>
            </div>
          </div>

          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
            <div 
              className="bg-indigo-600 h-full rounded-full transition-all duration-500" 
              style={{ width: `${Math.min(100, Math.max(10, ((latestRecord.systolicBp - 80) / 80) * 100))}%` }}
            />
          </div>
        </div>

        {/* 3. Blood Oxygen (SpO2) */}
        <div className="p-5 rounded-3xl bg-white border border-slate-200/90 shadow-sm hover:shadow-md transition-all space-y-3 relative overflow-hidden group">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-2xl bg-sky-50 border border-sky-100 flex items-center justify-center text-sky-600">
                <Wind className="w-4 h-4 text-sky-600 group-hover:scale-110 transition-transform" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wide">Blood Oxygen</h4>
                <span className="text-[10px] font-medium text-slate-400">Pulse Oximetry</span>
              </div>
            </div>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-50 text-sky-700 border border-sky-200">
              SpO₂ Normal (≥95%)
            </span>
          </div>

          <div className="flex items-baseline justify-between pt-1">
            <div>
              <span className="text-3xl font-black text-slate-900 tracking-tight">{latestRecord.oxygenSaturation}</span>
              <span className="text-xs font-bold text-slate-500 ml-1.5">%</span>
            </div>
            <div className="flex items-center gap-1 text-[11px] font-bold text-emerald-600">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Full Oxygenation</span>
            </div>
          </div>

          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
            <div 
              className="bg-sky-500 h-full rounded-full transition-all duration-500" 
              style={{ width: `${Math.min(100, Math.max(10, ((latestRecord.oxygenSaturation - 85) / 15) * 100))}%` }}
            />
          </div>
        </div>

        {/* 4. Blood Glucose / Metabolism */}
        <div className="p-5 rounded-3xl bg-white border border-slate-200/90 shadow-sm hover:shadow-md transition-all space-y-3 relative overflow-hidden group">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-2xl bg-amber-50 border border-amber-100 flex items-center justify-center text-amber-600">
                <Droplet className="w-4 h-4 text-amber-600 group-hover:scale-110 transition-transform" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wide">Blood Sugar</h4>
                <span className="text-[10px] font-medium text-slate-400">{latestRecord.activityContext || 'Fasting'}</span>
              </div>
            </div>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
              Euglycemic
            </span>
          </div>

          <div className="flex items-baseline justify-between pt-1">
            <div>
              <span className="text-3xl font-black text-slate-900 tracking-tight">
                {latestRecord.bloodGlucose || 94}
              </span>
              <span className="text-xs font-bold text-slate-500 ml-1.5">mg/dL</span>
            </div>
            <div className="flex items-center gap-1 text-[11px] font-bold text-slate-500">
              {glucoseTrend.direction === 'up' && <TrendingUp className="w-3.5 h-3.5 text-amber-500" />}
              {glucoseTrend.direction === 'down' && <TrendingDown className="w-3.5 h-3.5 text-emerald-500" />}
              {glucoseTrend.direction === 'same' && <Minus className="w-3.5 h-3.5 text-slate-400" />}
              <span>{glucoseTrend.diff > 0 ? `${glucoseTrend.diff} mg/dL` : 'Stable'}</span>
            </div>
          </div>

          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
            <div 
              className="bg-amber-500 h-full rounded-full transition-all duration-500" 
              style={{ width: `${Math.min(100, Math.max(10, (((latestRecord.bloodGlucose || 95) - 60) / 100) * 100))}%` }}
            />
          </div>
        </div>

      </div>
    </div>
  );
};
