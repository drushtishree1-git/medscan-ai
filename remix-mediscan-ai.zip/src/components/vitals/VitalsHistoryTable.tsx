import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Download, 
  Calendar, 
  Activity, 
  Heart, 
  Wind, 
  Droplet, 
  Trash2, 
  FileSpreadsheet,
  CheckCircle2,
  AlertTriangle,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { VitalRecord } from '../../types';

interface VitalsHistoryTableProps {
  records: VitalRecord[];
  onDeleteRecord?: (id: string) => void;
  onSelectRecord?: (record: VitalRecord) => void;
}

export const VitalsHistoryTable: React.FC<VitalsHistoryTableProps> = ({
  records,
  onDeleteRecord,
  onSelectRecord,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'optimal' | 'normal' | 'borderline' | 'elevated' | 'critical'>('all');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;

  // Filter & Search
  const filteredRecords = useMemo(() => {
    return records.filter((r) => {
      const matchSearch =
        r.date.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (r.notes || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (r.activityContext || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (r.recordedBy || '').toLowerCase().includes(searchTerm.toLowerCase());

      const matchStatus = statusFilter === 'all' || r.statusAlert === statusFilter;

      return matchSearch && matchStatus;
    });
  }, [records, searchTerm, statusFilter]);

  const totalPages = Math.ceil(filteredRecords.length / itemsPerPage) || 1;
  const paginatedRecords = filteredRecords.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // CSV Export
  const handleExportCSV = () => {
    const headers = ['ID', 'Date', 'Time', 'Heart Rate (BPM)', 'Systolic BP (mmHg)', 'Diastolic BP (mmHg)', 'Oxygen SpO2 (%)', 'Blood Glucose (mg/dL)', 'Temperature (F)', 'Context', 'Status', 'Notes'];
    const rows = records.map((r) => [
      r.id,
      r.date,
      r.time,
      r.heartRate,
      r.systolicBp,
      r.diastolicBp,
      r.oxygenSaturation,
      r.bloodGlucose || '',
      r.bodyTemperature || '',
      `"${r.activityContext || ''}"`,
      r.statusAlert || 'normal',
      `"${(r.notes || '').replace(/"/g, '""')}"`
    ]);

    const csvContent = [headers.join(','), ...rows.map((row) => row.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `mediscan_vitals_history_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
      
      {/* Header & Export Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
        <div>
          <h3 className="text-sm sm:text-base font-extrabold text-slate-900 flex items-center gap-2">
            <span>Historical Vitals Logbook</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700">
              {records.length} Total Logs
            </span>
          </h3>
          <p className="text-xs text-slate-500">
            Comprehensive longitudinal audit trail of recorded patient physiological telemetry.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-2xs"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search dates, context, notes..."
            value={searchTerm}
            onChange={(e) => { setSearchTerm(e.target.value); setCurrentPage(1); }}
            className="w-full pl-9 pr-3.5 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="flex items-center gap-1.5 w-full sm:w-auto overflow-x-auto pb-1 text-xs">
          {(['all', 'optimal', 'normal', 'borderline', 'elevated'] as const).map((st) => (
            <button
              key={st}
              onClick={() => { setStatusFilter(st); setCurrentPage(1); }}
              className={`px-2.5 py-1 rounded-lg font-bold capitalize transition-all cursor-pointer ${
                statusFilter === st
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto rounded-2xl border border-slate-200">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50/80 text-slate-600 font-bold border-b border-slate-200 text-[11px] uppercase tracking-wider">
            <tr>
              <th className="px-4 py-3">Date & Time</th>
              <th className="px-3 py-3">Heart Rate</th>
              <th className="px-3 py-3">Blood Pressure</th>
              <th className="px-3 py-3">Blood Oxygen</th>
              <th className="px-3 py-3">Glucose</th>
              <th className="px-3 py-3">Context</th>
              <th className="px-3 py-3">Status</th>
              <th className="px-3 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 font-medium text-slate-800">
            {paginatedRecords.length > 0 ? (
              paginatedRecords.map((r) => (
                <tr key={r.id} className="hover:bg-blue-50/30 transition-colors">
                  <td className="px-4 py-3">
                    <div className="font-bold text-slate-900">{r.date}</div>
                    <div className="text-[10px] text-slate-400 font-mono">{r.time}</div>
                  </td>

                  <td className="px-3 py-3">
                    <div className="font-extrabold text-rose-700 flex items-center gap-1">
                      <Heart className="w-3 h-3 text-rose-500" />
                      <span>{r.heartRate}</span>
                      <span className="text-[10px] font-normal text-slate-400">BPM</span>
                    </div>
                  </td>

                  <td className="px-3 py-3">
                    <div className="font-extrabold text-indigo-900 flex items-center gap-1">
                      <Activity className="w-3 h-3 text-indigo-500" />
                      <span>{r.systolicBp}/{r.diastolicBp}</span>
                      <span className="text-[10px] font-normal text-slate-400">mmHg</span>
                    </div>
                  </td>

                  <td className="px-3 py-3">
                    <div className="font-extrabold text-sky-700 flex items-center gap-1">
                      <Wind className="w-3 h-3 text-sky-500" />
                      <span>{r.oxygenSaturation}%</span>
                    </div>
                  </td>

                  <td className="px-3 py-3">
                    <div className="font-extrabold text-amber-700">
                      {r.bloodGlucose ? `${r.bloodGlucose} mg/dL` : '—'}
                    </div>
                  </td>

                  <td className="px-3 py-3">
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-slate-100 text-slate-700 border border-slate-200">
                      {r.activityContext || 'Resting'}
                    </span>
                  </td>

                  <td className="px-3 py-3">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                      r.statusAlert === 'optimal'
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        : r.statusAlert === 'borderline' || r.statusAlert === 'elevated'
                        ? 'bg-amber-50 text-amber-700 border-amber-200'
                        : r.statusAlert === 'critical'
                        ? 'bg-rose-50 text-rose-700 border-rose-200'
                        : 'bg-blue-50 text-blue-700 border-blue-200'
                    }`}>
                      {r.statusAlert || 'Normal'}
                    </span>
                  </td>

                  <td className="px-3 py-3 text-right">
                    {onDeleteRecord && (
                      <button
                        onClick={() => onDeleteRecord(r.id)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-all cursor-pointer"
                        title="Delete entry"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={8} className="px-4 py-8 text-center text-slate-400 text-xs">
                  No vital records matching current search or filter criteria.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between pt-2 text-xs text-slate-500">
          <span>
            Showing {(currentPage - 1) * itemsPerPage + 1} to {Math.min(currentPage * itemsPerPage, filteredRecords.length)} of {filteredRecords.length} records
          </span>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 disabled:opacity-40 cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="px-2 font-bold text-slate-800">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 disabled:opacity-40 cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
