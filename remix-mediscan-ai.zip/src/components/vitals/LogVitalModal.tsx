import React, { useState } from 'react';
import { 
  X, 
  Activity, 
  Heart, 
  Wind, 
  Droplet, 
  Thermometer, 
  Calendar, 
  Clock, 
  Check, 
  AlertCircle,
  Sparkles,
  ShieldCheck
} from 'lucide-react';
import { VitalRecord } from '../../types';

interface LogVitalModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (record: VitalRecord) => void;
}

export const LogVitalModal: React.FC<LogVitalModalProps> = ({
  isOpen,
  onClose,
  onSave,
}) => {
  const [heartRate, setHeartRate] = useState<number>(72);
  const [systolicBp, setSystolicBp] = useState<number>(118);
  const [diastolicBp, setDiastolicBp] = useState<number>(78);
  const [oxygenSaturation, setOxygenSaturation] = useState<number>(98);
  const [bloodGlucose, setBloodGlucose] = useState<number>(95);
  const [bodyTemperature, setBodyTemperature] = useState<number>(98.6);
  const [respiratoryRate, setRespiratoryRate] = useState<number>(16);
  const [weightKg, setWeightKg] = useState<number>(68.2);
  const [activityContext, setActivityContext] = useState<VitalRecord['activityContext']>('Morning Fasting');
  const [notes, setNotes] = useState<string>('');

  if (!isOpen) return null;

  // Real-time evaluation
  const getHrFeedback = (hr: number) => {
    if (hr < 50) return { label: 'Bradycardia (<50 BPM)', color: 'text-amber-600' };
    if (hr <= 100) return { label: 'Optimal Normal (60-100 BPM)', color: 'text-emerald-600' };
    return { label: 'Tachycardia (>100 BPM)', color: 'text-rose-600' };
  };

  const getBpFeedback = (sys: number, dia: number) => {
    if (sys < 120 && dia < 80) return { label: 'Optimal (<120/<80)', color: 'text-emerald-600' };
    if (sys <= 129 && dia < 80) return { label: 'Elevated (120-129)', color: 'text-amber-600' };
    if (sys <= 139 || dia <= 89) return { label: 'Stage 1 Hypertension', color: 'text-orange-600' };
    return { label: 'Stage 2 Hypertension (≥140)', color: 'text-rose-600' };
  };

  const getSpo2Feedback = (spo2: number) => {
    if (spo2 >= 95) return { label: 'Normal Oxygenation (≥95%)', color: 'text-emerald-600' };
    if (spo2 >= 90) return { label: 'Mild Hypoxemia (90-94%)', color: 'text-amber-600' };
    return { label: 'Critical Hypoxemia (<90%)', color: 'text-rose-600' };
  };

  const hrStatus = getHrFeedback(heartRate);
  const bpStatus = getBpFeedback(systolicBp, diastolicBp);
  const spo2Status = getSpo2Feedback(oxygenSaturation);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const now = new Date();
    const formattedDate = now.toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
    const formattedTime = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

    let statusAlert: VitalRecord['statusAlert'] = 'normal';
    if (systolicBp < 120 && diastolicBp < 80 && oxygenSaturation >= 98 && heartRate >= 60 && heartRate <= 85) {
      statusAlert = 'optimal';
    } else if (systolicBp >= 140 || diastolicBp >= 90 || oxygenSaturation < 90) {
      statusAlert = 'critical';
    } else if (systolicBp >= 130 || oxygenSaturation < 95) {
      statusAlert = 'elevated';
    }

    const newRecord: VitalRecord = {
      id: `VIT-${now.getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
      timestamp: now.toISOString(),
      date: formattedDate,
      time: formattedTime,
      heartRate,
      systolicBp,
      diastolicBp,
      oxygenSaturation,
      bloodGlucose,
      bodyTemperature,
      respiratoryRate,
      weightKg,
      activityContext,
      notes: notes || `Logged via clinical portal during ${activityContext}.`,
      recordedBy: 'Patient Self-Log (Verified)',
      statusAlert
    };

    onSave(newRecord);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto space-y-6">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-blue-600 text-white shadow-md">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-slate-900">
                Log New Clinical Vitals
              </h3>
              <p className="text-xs text-slate-500">
                Enter your latest biometric measurements for real-time trend plotting.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Presets */}
        <div className="space-y-2">
          <label className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
            Quick Baseline Presets:
          </label>
          <div className="flex flex-wrap items-center gap-2">
            {[
              { label: 'Morning Resting (Optimal)', hr: 68, sys: 118, dia: 78, spo2: 99, glu: 92, ctx: 'Morning Fasting' as const },
              { label: 'Post-Meal Evaluation', hr: 76, sys: 122, dia: 80, spo2: 98, glu: 115, ctx: 'Post-Meal' as const },
              { label: 'Post-Exercise Activity', hr: 92, sys: 128, dia: 82, spo2: 98, glu: 105, ctx: 'Post-Exercise' as const },
            ].map((preset, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  setHeartRate(preset.hr);
                  setSystolicBp(preset.sys);
                  setDiastolicBp(preset.dia);
                  setOxygenSaturation(preset.spo2);
                  setBloodGlucose(preset.glu);
                  setActivityContext(preset.ctx);
                }}
                className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-blue-50 hover:text-blue-700 border border-slate-200 text-xs font-semibold text-slate-700 transition-all cursor-pointer"
              >
                {preset.label}
              </button>
            ))}
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Heart Rate */}
            <div className="space-y-1.5 p-3.5 rounded-2xl bg-rose-50/50 border border-rose-100">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-rose-950 flex items-center gap-1.5">
                  <Heart className="w-4 h-4 text-rose-600" />
                  <span>Heart Rate (BPM)</span>
                </label>
                <span className={`text-[10px] font-bold ${hrStatus.color}`}>
                  {hrStatus.label}
                </span>
              </div>
              <input
                type="number"
                min={40}
                max={220}
                value={heartRate}
                onChange={(e) => setHeartRate(Number(e.target.value))}
                className="w-full px-3.5 py-2 rounded-xl bg-white border border-rose-200 text-sm font-extrabold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-rose-500"
                required
              />
            </div>

            {/* Oxygen Saturation */}
            <div className="space-y-1.5 p-3.5 rounded-2xl bg-sky-50/50 border border-sky-100">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-sky-950 flex items-center gap-1.5">
                  <Wind className="w-4 h-4 text-sky-600" />
                  <span>Blood Oxygen (SpO₂ %)</span>
                </label>
                <span className={`text-[10px] font-bold ${spo2Status.color}`}>
                  {spo2Status.label}
                </span>
              </div>
              <input
                type="number"
                min={70}
                max={100}
                value={oxygenSaturation}
                onChange={(e) => setOxygenSaturation(Number(e.target.value))}
                className="w-full px-3.5 py-2 rounded-xl bg-white border border-sky-200 text-sm font-extrabold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-sky-500"
                required
              />
            </div>

            {/* Blood Pressure (Sys & Dia) */}
            <div className="space-y-1.5 p-3.5 rounded-2xl bg-indigo-50/50 border border-indigo-100 sm:col-span-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-indigo-950 flex items-center gap-1.5">
                  <Activity className="w-4 h-4 text-indigo-600" />
                  <span>Blood Pressure (SYS / DIA mmHg)</span>
                </label>
                <span className={`text-[10px] font-bold ${bpStatus.color}`}>
                  {bpStatus.label}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="text-[10px] text-slate-500 font-bold uppercase block mb-1">Systolic (Top)</span>
                  <input
                    type="number"
                    min={70}
                    max={220}
                    value={systolicBp}
                    onChange={(e) => setSystolicBp(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl bg-white border border-indigo-200 text-sm font-extrabold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                    placeholder="120"
                    required
                  />
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 font-bold uppercase block mb-1">Diastolic (Bottom)</span>
                  <input
                    type="number"
                    min={40}
                    max={140}
                    value={diastolicBp}
                    onChange={(e) => setDiastolicBp(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl bg-white border border-indigo-200 text-sm font-extrabold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                    placeholder="80"
                    required
                  />
                </div>
              </div>
            </div>

            {/* Blood Glucose */}
            <div className="space-y-1.5 p-3.5 rounded-2xl bg-amber-50/50 border border-amber-100">
              <label className="text-xs font-bold text-amber-950 flex items-center gap-1.5">
                <Droplet className="w-4 h-4 text-amber-600" />
                <span>Blood Glucose (mg/dL)</span>
              </label>
              <input
                type="number"
                min={40}
                max={400}
                value={bloodGlucose}
                onChange={(e) => setBloodGlucose(Number(e.target.value))}
                className="w-full px-3.5 py-2 rounded-xl bg-white border border-amber-200 text-sm font-extrabold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              />
            </div>

            {/* Body Temperature */}
            <div className="space-y-1.5 p-3.5 rounded-2xl bg-emerald-50/50 border border-emerald-100">
              <label className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                <Thermometer className="w-4 h-4 text-emerald-600" />
                <span>Body Temperature (°F)</span>
              </label>
              <input
                type="number"
                step="0.1"
                min={95}
                max={106}
                value={bodyTemperature}
                onChange={(e) => setBodyTemperature(Number(e.target.value))}
                className="w-full px-3.5 py-2 rounded-xl bg-white border border-emerald-200 text-sm font-extrabold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {/* Activity Context */}
            <div className="space-y-1.5 sm:col-span-2">
              <label className="text-xs font-bold text-slate-700">Measurement Context</label>
              <select
                value={activityContext}
                onChange={(e) => setActivityContext(e.target.value as any)}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              >
                <option value="Morning Fasting">Morning Fasting (Resting)</option>
                <option value="Resting">Resting (General Daytime)</option>
                <option value="Post-Meal">Post-Meal (1-2hr Postprandial)</option>
                <option value="Post-Exercise">Post-Exercise / Walk</option>
                <option value="Bedtime">Bedtime Prior to Sleep</option>
              </select>
            </div>

            {/* Clinical Notes */}
            <div className="space-y-1.5 sm:col-span-2">
              <label className="text-xs font-bold text-slate-700">Notes / Symptoms (Optional)</label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g., Felt energetic, hydration 2.5L today, no chest discomfort."
                className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              />
            </div>

          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 text-xs font-bold transition-all cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs shadow-md flex items-center gap-2 transition-all cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>Save & Plot to Chart</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
