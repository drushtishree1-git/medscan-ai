import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
  ReferenceArea,
  Brush
} from 'recharts';
import {
  Activity,
  Heart,
  Wind,
  Droplet,
  Thermometer,
  Calendar,
  Layers,
  Sparkles,
  ShieldCheck,
  TrendingDown,
  TrendingUp,
  Info,
  Maximize2
} from 'lucide-react';
import { VitalRecord, VitalMetricKey, AnalysisRecord } from '../../types';
import { CLINICAL_VITAL_THRESHOLDS } from '../../data/mockVitals';

interface VitalsTrendChartProps {
  records: VitalRecord[];
  analyses?: AnalysisRecord[];
  onSelectScan?: (scanId: string) => void;
}

type TimeRangeFilter = '7d' | '14d' | '30d' | '90d' | 'all';
type ChartStyleType = 'smooth' | 'area' | 'stepped' | 'linear';

export const VitalsTrendChart: React.FC<VitalsTrendChartProps> = ({
  records,
  analyses = [],
  onSelectScan
}) => {
  const [selectedMetric, setSelectedMetric] = useState<VitalMetricKey>('all');
  const [timeRange, setTimeRange] = useState<TimeRangeFilter>('30d');
  const [chartStyle, setChartStyle] = useState<ChartStyleType>('smooth');
  const [showScanMilestones, setShowScanMilestones] = useState(true);
  const [showReferenceZones, setShowReferenceZones] = useState(true);

  // Filter records by time range
  const filteredData = useMemo(() => {
    // Sort oldest to newest for chronological left-to-right chart plotting
    const sorted = [...records].sort(
      (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );

    if (timeRange === 'all') return sorted;

    const days = timeRange === '7d' ? 7 : timeRange === '14d' ? 14 : timeRange === '30d' ? 30 : 90;
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - days);

    const filtered = sorted.filter((r) => new Date(r.timestamp) >= cutoff);
    return filtered.length > 0 ? filtered : sorted.slice(-Math.min(sorted.length, days));
  }, [records, timeRange]);

  // Compute summary stats for the active metric
  const stats = useMemo(() => {
    if (filteredData.length === 0) return null;

    const compute = (vals: number[]) => {
      const valid = vals.filter((v) => !isNaN(v) && v !== undefined);
      if (valid.length === 0) return { avg: 0, min: 0, max: 0, current: 0, delta: 0 };
      const sum = valid.reduce((acc, v) => acc + v, 0);
      const avg = Math.round((sum / valid.length) * 10) / 10;
      const min = Math.min(...valid);
      const max = Math.max(...valid);
      const current = valid[valid.length - 1];
      const initial = valid[0];
      const delta = Math.round((current - initial) * 10) / 10;
      return { avg, min, max, current, delta };
    };

    return {
      heartRate: compute(filteredData.map((d) => d.heartRate)),
      systolicBp: compute(filteredData.map((d) => d.systolicBp)),
      diastolicBp: compute(filteredData.map((d) => d.diastolicBp)),
      oxygenSaturation: compute(filteredData.map((d) => d.oxygenSaturation)),
      bloodGlucose: compute(filteredData.map((d) => d.bloodGlucose || 95)),
      bodyTemperature: compute(filteredData.map((d) => d.bodyTemperature || 98.6)),
      respiratoryRate: compute(filteredData.map((d) => d.respiratoryRate || 16))
    };
  }, [filteredData]);

  // Determine line interpolation curve
  const curveType = chartStyle === 'smooth' ? 'monotone' : chartStyle === 'stepped' ? 'stepAfter' : 'linear';

  // Custom Chart Tooltip with Clinical Diagnostics & Notes
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const dataPoint: VitalRecord = payload[0]?.payload;
      return (
        <div className="p-4 rounded-2xl bg-slate-900/95 backdrop-blur-md text-white border border-slate-700 shadow-2xl space-y-2.5 max-w-xs text-xs">
          <div className="flex items-center justify-between border-b border-slate-700/80 pb-1.5">
            <span className="font-extrabold text-blue-300">{dataPoint.date} • {dataPoint.time}</span>
            <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-500/20 text-blue-200 border border-blue-400/30">
              {dataPoint.activityContext || 'Resting'}
            </span>
          </div>

          <div className="space-y-1.5">
            {payload.map((entry: any, index: number) => (
              <div key={`item-${index}`} className="flex items-center justify-between gap-4">
                <span className="flex items-center gap-1.5 font-medium" style={{ color: entry.color }}>
                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
                  {entry.name}:
                </span>
                <span className="font-mono font-bold text-white">
                  {entry.value} {entry.unit || ''}
                </span>
              </div>
            ))}
          </div>

          {dataPoint.notes && (
            <div className="pt-1.5 border-t border-slate-800 text-[11px] text-slate-300 italic">
              "{dataPoint.notes}"
            </div>
          )}

          {dataPoint.associatedScanId && (
            <div className="pt-1 flex items-center gap-1 text-[10px] text-amber-300 font-bold">
              <Sparkles className="w-3 h-3 text-amber-400" />
              <span>Correlated Scan: {dataPoint.associatedScanId}</span>
            </div>
          )}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="p-6 rounded-3xl bg-white border border-slate-200/90 shadow-md space-y-6">
      
      {/* Header & Controls Toolbar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-100">
        
        {/* Title */}
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-blue-600 text-white shadow-md shadow-blue-500/20">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base sm:text-lg font-black text-slate-900 tracking-tight">
                Historical Vitals & Biometric Trend Analysis
              </h3>
              <span className="hidden sm:inline-flex px-2 py-0.5 rounded-md text-[10px] font-black uppercase bg-blue-50 text-blue-700 border border-blue-200">
                Recharts Visualizer
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Longitudinal tracking of cardiovascular, respiratory, and metabolic markers correlated with diagnostic scans.
            </p>
          </div>
        </div>

        {/* Time Range & Chart Style Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          
          {/* Time Range Buttons */}
          <div className="inline-flex items-center p-1 rounded-xl bg-slate-100 border border-slate-200 text-xs font-bold">
            {(['7d', '14d', '30d', '90d', 'all'] as TimeRangeFilter[]).map((range) => (
              <button
                key={range}
                onClick={() => setTimeRange(range)}
                className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                  timeRange === range
                    ? 'bg-white text-blue-700 shadow-2xs font-extrabold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {range === 'all' ? 'All Time' : range.toUpperCase()}
              </button>
            ))}
          </div>

          {/* Chart Style Switcher */}
          <div className="inline-flex items-center p-1 rounded-xl bg-slate-100 border border-slate-200 text-xs font-bold">
            <button
              onClick={() => setChartStyle('smooth')}
              className={`px-2 py-1 rounded-lg transition-all cursor-pointer ${
                chartStyle === 'smooth' ? 'bg-white text-indigo-700 shadow-2xs' : 'text-slate-600'
              }`}
              title="Smooth Spline Curve"
            >
              Smooth
            </button>
            <button
              onClick={() => setChartStyle('area')}
              className={`px-2 py-1 rounded-lg transition-all cursor-pointer ${
                chartStyle === 'area' ? 'bg-white text-indigo-700 shadow-2xs' : 'text-slate-600'
              }`}
              title="Area Filled Gradient"
            >
              Area
            </button>
            <button
              onClick={() => setChartStyle('stepped')}
              className={`px-2 py-1 rounded-lg transition-all cursor-pointer ${
                chartStyle === 'stepped' ? 'bg-white text-indigo-700 shadow-2xs' : 'text-slate-600'
              }`}
              title="Stepped Discrete Levels"
            >
              Step
            </button>
          </div>

          {/* Reference Zones Toggle */}
          <button
            onClick={() => setShowReferenceZones(!showReferenceZones)}
            className={`px-2.5 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              showReferenceZones
                ? 'bg-emerald-50 text-emerald-800 border-emerald-200 shadow-2xs'
                : 'bg-slate-50 text-slate-600 border-slate-200'
            }`}
            title="Toggle Clinical Normal Reference Range Bands"
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Normal Ranges</span>
          </button>
        </div>

      </div>

      {/* Metric Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
        {[
          { key: 'all', label: 'All Vitals (Composite)', icon: Layers, color: 'text-blue-600' },
          { key: 'heartRate', label: 'Heart Rate (BPM)', icon: Heart, color: 'text-rose-600' },
          { key: 'bloodPressure', label: 'Blood Pressure (SYS/DIA)', icon: Activity, color: 'text-indigo-600' },
          { key: 'oxygenSaturation', label: 'Blood Oxygen (SpO₂)', icon: Wind, color: 'text-sky-600' },
          { key: 'bloodGlucose', label: 'Blood Sugar (mg/dL)', icon: Droplet, color: 'text-amber-600' },
          { key: 'bodyTemperature', label: 'Temperature (°F)', icon: Thermometer, color: 'text-emerald-600' }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = selectedMetric === tab.key;
          return (
            <button
              key={tab.key}
              onClick={() => setSelectedMetric(tab.key as VitalMetricKey)}
              className={`px-3.5 py-2 rounded-2xl text-xs font-extrabold flex items-center gap-2 shrink-0 transition-all cursor-pointer ${
                isActive
                  ? 'bg-slate-900 text-white shadow-md'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200/80'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-blue-300' : tab.color}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Dynamic Statistics Bar for Selected Metric */}
      {stats && (
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-3 p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 text-xs">
          
          {selectedMetric === 'all' || selectedMetric === 'heartRate' ? (
            <>
              <div className="space-y-0.5">
                <span className="text-[10px] uppercase font-bold text-slate-400">Avg Heart Rate</span>
                <div className="font-extrabold text-slate-900 text-sm">
                  {stats.heartRate.avg} <span className="text-xs font-normal text-slate-500">BPM</span>
                </div>
              </div>
              <div className="space-y-0.5">
                <span className="text-[10px] uppercase font-bold text-slate-400">Resting Range</span>
                <div className="font-extrabold text-slate-900 text-sm">
                  {stats.heartRate.min} - {stats.heartRate.max} <span className="text-xs font-normal text-slate-500">BPM</span>
                </div>
              </div>
            </>
          ) : null}

          {selectedMetric === 'all' || selectedMetric === 'bloodPressure' ? (
            <>
              <div className="space-y-0.5">
                <span className="text-[10px] uppercase font-bold text-slate-400">Avg Blood Pressure</span>
                <div className="font-extrabold text-slate-900 text-sm">
                  {stats.systolicBp.avg}/{stats.diastolicBp.avg} <span className="text-xs font-normal text-slate-500">mmHg</span>
                </div>
              </div>
              <div className="space-y-0.5">
                <span className="text-[10px] uppercase font-bold text-slate-400">Systolic Range</span>
                <div className="font-extrabold text-slate-900 text-sm">
                  {stats.systolicBp.min} - {stats.systolicBp.max} <span className="text-xs font-normal text-slate-500">mmHg</span>
                </div>
              </div>
            </>
          ) : null}

          {selectedMetric === 'all' || selectedMetric === 'oxygenSaturation' ? (
            <div className="space-y-0.5">
              <span className="text-[10px] uppercase font-bold text-slate-400">Avg Oxygen SpO₂</span>
              <div className="font-extrabold text-sky-700 text-sm">
                {stats.oxygenSaturation.avg}% <span className="text-xs font-normal text-emerald-600 font-bold">(Normal ≥95%)</span>
              </div>
            </div>
          ) : null}

          {selectedMetric === 'bloodGlucose' && (
            <>
              <div className="space-y-0.5">
                <span className="text-[10px] uppercase font-bold text-slate-400">Avg Fasting Glucose</span>
                <div className="font-extrabold text-amber-700 text-sm">
                  {stats.bloodGlucose.avg} <span className="text-xs font-normal text-slate-500">mg/dL</span>
                </div>
              </div>
              <div className="space-y-0.5">
                <span className="text-[10px] uppercase font-bold text-slate-400">Glucose Min / Max</span>
                <div className="font-extrabold text-slate-900 text-sm">
                  {stats.bloodGlucose.min} - {stats.bloodGlucose.max} <span className="text-xs font-normal text-slate-500">mg/dL</span>
                </div>
              </div>
            </>
          )}

          {selectedMetric === 'bodyTemperature' && (
            <>
              <div className="space-y-0.5">
                <span className="text-[10px] uppercase font-bold text-slate-400">Avg Temperature</span>
                <div className="font-extrabold text-emerald-700 text-sm">
                  {stats.bodyTemperature.avg}°F <span className="text-xs font-normal text-slate-500">(Afebrile)</span>
                </div>
              </div>
              <div className="space-y-0.5">
                <span className="text-[10px] uppercase font-bold text-slate-400">Resp. Rate Avg</span>
                <div className="font-extrabold text-slate-900 text-sm">
                  {stats.respiratoryRate.avg} <span className="text-xs font-normal text-slate-500">breaths/min</span>
                </div>
              </div>
            </>
          )}

          <div className="space-y-0.5">
            <span className="text-[10px] uppercase font-bold text-slate-400">Trend Status</span>
            <div className="font-extrabold text-emerald-600 text-sm flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Optimal & Stable</span>
            </div>
          </div>

        </div>
      )}

      {/* Main Recharts Container */}
      <div className="w-full h-[360px] sm:h-[400px] select-none pt-2">
        <ResponsiveContainer width="100%" height="100%">
          {chartStyle === 'area' ? (
            <AreaChart data={filteredData} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
              <defs>
                <linearGradient id="colorHr" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#E11D48" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#E11D48" stopOpacity={0.0} />
                </linearGradient>
                <linearGradient id="colorSys" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#4F46E5" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#4F46E5" stopOpacity={0.0} />
                </linearGradient>
                <linearGradient id="colorDia" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#3B82F6" stopOpacity={0.0} />
                </linearGradient>
                <linearGradient id="colorSpo2" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#0284C7" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#0284C7" stopOpacity={0.0} />
                </linearGradient>
                <linearGradient id="colorGlucose" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#D97706" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#D97706" stopOpacity={0.0} />
                </linearGradient>
              </defs>

              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" vertical={false} />
              <XAxis 
                dataKey="date" 
                tick={{ fontSize: 11, fill: '#64748B' }} 
                axisLine={{ stroke: '#CBD5E1' }}
                tickLine={false}
              />
              <YAxis 
                domain={['auto', 'auto']}
                tick={{ fontSize: 11, fill: '#64748B' }} 
                axisLine={{ stroke: '#CBD5E1' }}
                tickLine={false}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend 
                verticalAlign="top" 
                height={36} 
                iconType="circle"
                wrapperStyle={{ fontSize: '12px', fontWeight: 'bold' }}
              />

              {/* Normal Reference Lines for SpO2, HR, or BP */}
              {showReferenceZones && selectedMetric === 'heartRate' && (
                <>
                  <ReferenceLine y={60} stroke="#10B981" strokeDasharray="3 3" label={{ value: '60 BPM Resting Base', fill: '#059669', fontSize: 10 }} />
                  <ReferenceLine y={100} stroke="#F59E0B" strokeDasharray="3 3" label={{ value: '100 BPM Upper Limit', fill: '#D97706', fontSize: 10 }} />
                </>
              )}

              {showReferenceZones && selectedMetric === 'bloodPressure' && (
                <>
                  <ReferenceLine y={120} stroke="#4F46E5" strokeDasharray="3 3" label={{ value: '120 mmHg Normal SYS', fill: '#4F46E5', fontSize: 10 }} />
                  <ReferenceLine y={80} stroke="#3B82F6" strokeDasharray="3 3" label={{ value: '80 mmHg Normal DIA', fill: '#3B82F6', fontSize: 10 }} />
                </>
              )}

              {/* Render Selected Metric Area Plots */}
              {(selectedMetric === 'all' || selectedMetric === 'heartRate') && (
                <Area
                  type={curveType}
                  dataKey="heartRate"
                  name="Heart Rate (BPM)"
                  stroke="#E11D48"
                  strokeWidth={2.5}
                  fill="url(#colorHr)"
                  unit="BPM"
                />
              )}

              {(selectedMetric === 'all' || selectedMetric === 'bloodPressure') && (
                <>
                  <Area
                    type={curveType}
                    dataKey="systolicBp"
                    name="Systolic BP (mmHg)"
                    stroke="#4F46E5"
                    strokeWidth={2.5}
                    fill="url(#colorSys)"
                    unit="mmHg"
                  />
                  <Area
                    type={curveType}
                    dataKey="diastolicBp"
                    name="Diastolic BP (mmHg)"
                    stroke="#3B82F6"
                    strokeWidth={2}
                    fill="url(#colorDia)"
                    unit="mmHg"
                  />
                </>
              )}

              {(selectedMetric === 'all' || selectedMetric === 'oxygenSaturation') && (
                <Area
                  type={curveType}
                  dataKey="oxygenSaturation"
                  name="Blood Oxygen (SpO₂ %)"
                  stroke="#0284C7"
                  strokeWidth={2.5}
                  fill="url(#colorSpo2)"
                  unit="%"
                />
              )}

              {selectedMetric === 'bloodGlucose' && (
                <Area
                  type={curveType}
                  dataKey="bloodGlucose"
                  name="Blood Glucose (mg/dL)"
                  stroke="#D97706"
                  strokeWidth={2.5}
                  fill="url(#colorGlucose)"
                  unit="mg/dL"
                />
              )}

              {selectedMetric === 'bodyTemperature' && (
                <Area
                  type={curveType}
                  dataKey="bodyTemperature"
                  name="Temperature (°F)"
                  stroke="#10B981"
                  strokeWidth={2.5}
                  fill="#10B981"
                  fillOpacity={0.15}
                  unit="°F"
                />
              )}
            </AreaChart>
          ) : (
            <LineChart data={filteredData} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" vertical={false} />
              <XAxis 
                dataKey="date" 
                tick={{ fontSize: 11, fill: '#64748B' }} 
                axisLine={{ stroke: '#CBD5E1' }}
                tickLine={false}
              />
              <YAxis 
                domain={['auto', 'auto']}
                tick={{ fontSize: 11, fill: '#64748B' }} 
                axisLine={{ stroke: '#CBD5E1' }}
                tickLine={false}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend 
                verticalAlign="top" 
                height={36} 
                iconType="circle"
                wrapperStyle={{ fontSize: '12px', fontWeight: 'bold' }}
              />

              {/* Reference Threshold Lines */}
              {showReferenceZones && (selectedMetric === 'all' || selectedMetric === 'oxygenSaturation') && (
                <ReferenceLine 
                  y={95} 
                  stroke="#EF4444" 
                  strokeDasharray="4 4" 
                  strokeWidth={1.5}
                  label={{ value: 'SpO₂ 95% Hypoxemia Threshold', fill: '#DC2626', fontSize: 10, position: 'right' }} 
                />
              )}

              {showReferenceZones && (selectedMetric === 'all' || selectedMetric === 'bloodPressure') && (
                <ReferenceLine 
                  y={120} 
                  stroke="#6366F1" 
                  strokeDasharray="4 4" 
                  label={{ value: '120 mmHg Normal SYS', fill: '#4F46E5', fontSize: 10, position: 'right' }} 
                />
              )}

              {showReferenceZones && selectedMetric === 'heartRate' && (
                <>
                  <ReferenceLine y={60} stroke="#10B981" strokeDasharray="3 3" label={{ value: '60 BPM Resting Base', fill: '#059669', fontSize: 10 }} />
                  <ReferenceLine y={100} stroke="#F59E0B" strokeDasharray="3 3" label={{ value: '100 BPM Upper Normal', fill: '#D97706', fontSize: 10 }} />
                </>
              )}

              {/* Render Lines */}
              {(selectedMetric === 'all' || selectedMetric === 'heartRate') && (
                <Line
                  type={curveType}
                  dataKey="heartRate"
                  name="Heart Rate"
                  stroke="#E11D48"
                  strokeWidth={3}
                  dot={{ r: 3, fill: '#E11D48', strokeWidth: 2, stroke: '#FFFFFF' }}
                  activeDot={{ r: 6, stroke: '#E11D48', strokeWidth: 2, fill: '#FFFFFF' }}
                  unit="BPM"
                />
              )}

              {(selectedMetric === 'all' || selectedMetric === 'bloodPressure') && (
                <>
                  <Line
                    type={curveType}
                    dataKey="systolicBp"
                    name="Systolic BP"
                    stroke="#4F46E5"
                    strokeWidth={2.5}
                    dot={{ r: 3, fill: '#4F46E5', strokeWidth: 2, stroke: '#FFFFFF' }}
                    activeDot={{ r: 6, stroke: '#4F46E5', strokeWidth: 2, fill: '#FFFFFF' }}
                    unit="mmHg"
                  />
                  <Line
                    type={curveType}
                    dataKey="diastolicBp"
                    name="Diastolic BP"
                    stroke="#3B82F6"
                    strokeWidth={2}
                    dot={{ r: 3, fill: '#3B82F6', strokeWidth: 2, stroke: '#FFFFFF' }}
                    activeDot={{ r: 6, stroke: '#3B82F6', strokeWidth: 2, fill: '#FFFFFF' }}
                    unit="mmHg"
                  />
                </>
              )}

              {(selectedMetric === 'all' || selectedMetric === 'oxygenSaturation') && (
                <Line
                  type={curveType}
                  dataKey="oxygenSaturation"
                  name="Oxygen SpO₂"
                  stroke="#0284C7"
                  strokeWidth={2.5}
                  dot={{ r: 3, fill: '#0284C7', strokeWidth: 2, stroke: '#FFFFFF' }}
                  activeDot={{ r: 6, stroke: '#0284C7', strokeWidth: 2, fill: '#FFFFFF' }}
                  unit="%"
                />
              )}

              {selectedMetric === 'bloodGlucose' && (
                <Line
                  type={curveType}
                  dataKey="bloodGlucose"
                  name="Blood Glucose"
                  stroke="#D97706"
                  strokeWidth={2.5}
                  dot={{ r: 3, fill: '#D97706', strokeWidth: 2, stroke: '#FFFFFF' }}
                  activeDot={{ r: 6, stroke: '#D97706', strokeWidth: 2, fill: '#FFFFFF' }}
                  unit="mg/dL"
                />
              )}

              {selectedMetric === 'bodyTemperature' && (
                <Line
                  type={curveType}
                  dataKey="bodyTemperature"
                  name="Temperature"
                  stroke="#10B981"
                  strokeWidth={2.5}
                  dot={{ r: 3, fill: '#10B981', strokeWidth: 2, stroke: '#FFFFFF' }}
                  activeDot={{ r: 6, stroke: '#10B981', strokeWidth: 2, fill: '#FFFFFF' }}
                  unit="°F"
                />
              )}
            </LineChart>
          )}
        </ResponsiveContainer>
      </div>

      {/* Clinical Notes & Guideline Reference Footer */}
      <div className="p-4 rounded-2xl bg-blue-50/60 border border-blue-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-slate-700">
        <div className="flex items-start gap-2.5">
          <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold text-blue-950">Clinical Interpretation Baseline: </span>
            <span>
              {CLINICAL_VITAL_THRESHOLDS[selectedMetric === 'all' ? 'heartRate' : (selectedMetric as keyof typeof CLINICAL_VITAL_THRESHOLDS)]?.description || 
              'All monitored biometric ranges comply with American Heart Association (AHA) and WHO clinical thresholds.'}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white border border-blue-200 text-[11px] font-bold text-blue-800 shadow-2xs">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>PubMed RAG Grounded</span>
          </span>
        </div>
      </div>

    </div>
  );
};
