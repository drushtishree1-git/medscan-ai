import React, { useState } from 'react';
import { 
  Target, 
  Droplet, 
  Footprints, 
  Moon, 
  Pill, 
  Flame, 
  CheckCircle2, 
  Plus,
  TrendingUp,
  Sparkles
} from 'lucide-react';
import { HealthGoal } from '../../types';
import { INITIAL_HEALTH_GOALS } from '../../data/mockVitals';

export const PatientHealthGoals: React.FC = () => {
  const [goals, setGoals] = useState<HealthGoal[]>(() => {
    const saved = localStorage.getItem('mediscan_health_goals');
    return saved ? JSON.parse(saved) : INITIAL_HEALTH_GOALS;
  });

  const handleIncrement = (id: string, step: number) => {
    setGoals((prev) => {
      const updated = prev.map((g) => {
        if (g.id === id) {
          const nextVal = Math.min(g.target * 1.5, Math.round((g.current + step) * 10) / 10);
          const status: HealthGoal['status'] = nextVal >= g.target ? 'achieved' : 'on_track';
          return { ...g, current: nextVal, status };
        }
        return g;
      });
      localStorage.setItem('mediscan_health_goals', JSON.stringify(updated));
      return updated;
    });
  };

  const getGoalIcon = (category: HealthGoal['category']) => {
    switch (category) {
      case 'water': return { icon: Droplet, color: 'text-sky-600 bg-sky-50 border-sky-200' };
      case 'steps': return { icon: Footprints, color: 'text-emerald-600 bg-emerald-50 border-emerald-200' };
      case 'sleep': return { icon: Moon, color: 'text-indigo-600 bg-indigo-50 border-indigo-200' };
      case 'medication': return { icon: Pill, color: 'text-rose-600 bg-rose-50 border-rose-200' };
      case 'exercise': return { icon: Flame, color: 'text-amber-600 bg-amber-50 border-amber-200' };
    }
  };

  return (
    <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
      
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-amber-50 text-amber-600 border border-amber-200">
            <Target className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm sm:text-base font-extrabold text-slate-900">
              Daily Health Targets & Adherence Tracker
            </h3>
            <p className="text-xs text-slate-500">
              Interactive progress tracking for clinical wellness goals recommended by your physician.
            </p>
          </div>
        </div>

        <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200 self-start sm:self-auto">
          {goals.filter((g) => g.status === 'achieved').length} of {goals.length} Goals Achieved Today
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5 pt-1">
        {goals.map((goal) => {
          const { icon: Icon, color } = getGoalIcon(goal.category);
          const percent = Math.min(100, Math.round((goal.current / goal.target) * 100));

          return (
            <div
              key={goal.id}
              className="p-4 rounded-2xl bg-slate-50/70 border border-slate-200 hover:border-blue-300 hover:bg-blue-50/20 transition-all space-y-3 flex flex-col justify-between"
            >
              <div className="flex items-start justify-between">
                <div className={`p-2 rounded-xl border ${color}`}>
                  <Icon className="w-4 h-4" />
                </div>
                {goal.status === 'achieved' && (
                  <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-100 text-emerald-800 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    <span>Done</span>
                  </span>
                )}
              </div>

              <div>
                <h4 className="text-xs font-extrabold text-slate-800">{goal.title}</h4>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="text-xl font-black text-slate-900">{goal.current}</span>
                  <span className="text-xs font-semibold text-slate-500">/ {goal.target} {goal.unit}</span>
                </div>
              </div>

              {/* Progress bar */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-[10px] font-bold text-slate-500">
                  <span>Progress</span>
                  <span>{percent}%</span>
                </div>
                <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                  <div 
                    className={`h-full rounded-full transition-all duration-500 ${
                      percent >= 100 ? 'bg-emerald-500' : 'bg-blue-600'
                    }`}
                    style={{ width: `${percent}%` }}
                  />
                </div>
              </div>

              {/* Quick Increment Action */}
              <button
                onClick={() => handleIncrement(goal.id, goal.category === 'water' ? 0.25 : goal.category === 'steps' ? 500 : 1)}
                className="w-full py-1.5 rounded-xl bg-white hover:bg-blue-600 hover:text-white text-slate-700 border border-slate-200 text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
              >
                <Plus className="w-3 h-3" />
                <span>Log +{goal.category === 'water' ? '0.25L' : goal.category === 'steps' ? '500' : '1'}</span>
              </button>

            </div>
          );
        })}
      </div>

    </div>
  );
};
