import React, { useState, useEffect } from 'react';
import { 
  Database, 
  RefreshCw, 
  Search, 
  Trash2, 
  Edit3, 
  Plus, 
  FileJson, 
  CheckCircle2, 
  AlertCircle, 
  Server, 
  HardDrive, 
  Clock, 
  ShieldCheck, 
  Layers, 
  Key, 
  Users, 
  Activity, 
  MessageSquare, 
  Download,
  FolderGit2,
  Lock
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

type CollectionName = 'users' | 'analyses' | 'reports' | 'chat_history' | 'otp_codes' | 'audit_logs' | 'soundtracks';

export const MongoDBManager: React.FC = () => {
  const { mongoDbStatus, refreshMongoDbStatus, resetMongoDbToSeed } = useAuth();
  
  const [activeCollection, setActiveCollection] = useState<CollectionName>('users');
  const [documents, setDocuments] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDoc, setSelectedDoc] = useState<any | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editJson, setEditJson] = useState('');
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);
  const [isInserting, setIsInserting] = useState(false);
  const [newDocJson, setNewDocJson] = useState('{\n  "title": "New Sample Record",\n  "status": "active"\n}');

  // Fetch documents for the active collection
  const loadCollectionDocs = async (collection: CollectionName) => {
    setIsLoading(true);
    setMessage(null);
    try {
      const res = await fetch(`/api/db/collections/${collection}`);
      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          setDocuments(data.data || []);
          if (data.data && data.data.length > 0) {
            setSelectedDoc(data.data[0]);
            setEditJson(JSON.stringify(data.data[0], null, 2));
          } else {
            setSelectedDoc(null);
            setEditJson('');
          }
        }
      }
    } catch (e: any) {
      setMessage({ text: `Failed to query MongoDB collection: ${e.message}`, type: 'error' });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadCollectionDocs(activeCollection);
  }, [activeCollection]);

  // Handle Save Edit
  const handleSaveEdit = async () => {
    if (!selectedDoc) return;
    try {
      const parsed = JSON.parse(editJson);
      const docId = selectedDoc.id || selectedDoc._id;
      const res = await fetch(`/api/db/collections/${activeCollection}/${docId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(parsed),
      });
      const data = await res.json();
      if (data.success) {
        setMessage({ text: `Document ${docId} successfully updated in MongoDB store.`, type: 'success' });
        setIsEditing(false);
        await loadCollectionDocs(activeCollection);
        await refreshMongoDbStatus();
      } else {
        setMessage({ text: data.message || 'Failed to update document.', type: 'error' });
      }
    } catch (err: any) {
      setMessage({ text: `JSON Syntax Error: ${err.message}`, type: 'error' });
    }
  };

  // Handle Insert Document
  const handleInsertDocument = async () => {
    try {
      const parsed = JSON.parse(newDocJson);
      const res = await fetch(`/api/db/collections/${activeCollection}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(parsed),
      });
      const data = await res.json();
      if (data.success) {
        setMessage({ text: `New document inserted into "${activeCollection}" collection.`, type: 'success' });
        setIsInserting(false);
        await loadCollectionDocs(activeCollection);
        await refreshMongoDbStatus();
      } else {
        setMessage({ text: data.message || 'Insert rejected by MongoDB constraints.', type: 'error' });
      }
    } catch (err: any) {
      setMessage({ text: `Invalid JSON format: ${err.message}`, type: 'error' });
    }
  };

  // Handle Delete Document
  const handleDeleteDocument = async (id: string) => {
    if (!confirm(`Are you sure you want to permanently delete document ${id} from MongoDB?`)) return;
    try {
      const res = await fetch(`/api/db/collections/${activeCollection}/${id}`, {
        method: 'DELETE',
      });
      const data = await res.json();
      if (data.success) {
        setMessage({ text: `Document ${id} deleted from MongoDB.`, type: 'success' });
        await loadCollectionDocs(activeCollection);
        await refreshMongoDbStatus();
      }
    } catch (e: any) {
      setMessage({ text: `Delete failed: ${e.message}`, type: 'error' });
    }
  };

  // Filter docs
  const filteredDocs = documents.filter((doc) => {
    const raw = JSON.stringify(doc).toLowerCase();
    return raw.includes(searchQuery.toLowerCase());
  });

  const collectionsList: { name: CollectionName; label: string; icon: React.FC<any>; count: number }[] = [
    { name: 'users', label: 'Users & Auth', icon: Users, count: mongoDbStatus?.collections?.users ?? 0 },
    { name: 'analyses', label: 'Scan Analyses', icon: Activity, count: mongoDbStatus?.collections?.analyses ?? 0 },
    { name: 'reports', label: 'Medical Reports', icon: FileJson, count: mongoDbStatus?.collections?.reports ?? 0 },
    { name: 'chat_history', label: 'Precautions Chat', icon: MessageSquare, count: mongoDbStatus?.collections?.chat_history ?? 0 },
    { name: 'otp_codes', label: 'Gmail OTP Tokens', icon: Key, count: mongoDbStatus?.collections?.otp_codes ?? 0 },
    { name: 'audit_logs', label: 'Security Audit Logs', icon: ShieldCheck, count: mongoDbStatus?.collections?.audit_logs ?? 0 },
    { name: 'soundtracks', label: 'Sound Therapy', icon: Layers, count: mongoDbStatus?.collections?.soundtracks ?? 0 },
  ];

  return (
    <div className="space-y-6">
      {/* 3D Top Header & MongoDB Connection Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 border border-emerald-500/30 text-white shadow-xl relative overflow-hidden preserve-3d">
        {/* Glow backdrop */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-700 text-white shadow-[0_4px_20px_rgba(16,185,129,0.35)] border border-emerald-400/40 flex-shrink-0">
              <Database className="h-7 w-7 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white">
                  MongoDB Document Database
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  ONLINE & SYNCED
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1 max-w-2xl font-normal leading-relaxed">
                Centralized multi-collection MongoDB document engine storing all application datasets: patient profiles, DICOM scan inferences, generated reports, Gmail OTP passcodes, emergency precautions triage logs, and session tokens.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => { refreshMongoDbStatus(); loadCollectionDocs(activeCollection); }}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Sync Metrics</span>
            </button>

            <button
              onClick={() => {
                if (confirm('Re-seed MongoDB with pristine medical records, test doctor, and demo studies?')) {
                  resetMongoDbToSeed();
                  setTimeout(() => loadCollectionDocs(activeCollection), 500);
                }
              }}
              className="px-3.5 py-2 rounded-xl bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-200 border border-emerald-500/40 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <FolderGit2 className="w-3.5 h-3.5" />
              <span>Re-Seed Sample Data</span>
            </button>
          </div>
        </div>

        {/* MongoDB Node Metrics Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-slate-800/80">
          <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-700/60 shadow-inner">
            <div className="text-[11px] font-semibold text-slate-400 flex items-center gap-1.5">
              <Server className="w-3.5 h-3.5 text-emerald-400" />
              Database Engine
            </div>
            <div className="text-sm font-bold text-white mt-1 truncate" title={mongoDbStatus?.engine || 'MongoDB Atlas'}>
              {mongoDbStatus?.isAtlasLive ? 'Atlas Cloud v7.0' : 'MongoDB v7.0'}
            </div>
            <div className="text-[10px] text-emerald-400 mt-0.5 font-mono">
              {mongoDbStatus?.databaseName || 'mediscan_clinical_db'}
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-700/60 shadow-inner">
            <div className="text-[11px] font-semibold text-slate-400 flex items-center gap-1.5">
              <HardDrive className="w-3.5 h-3.5 text-cyan-400" />
              Cluster Host
            </div>
            <div className="text-xs font-bold text-cyan-300 mt-1 truncate" title="mediscan-admin.aspbcsk.mongodb.net">
              mediscan-admin (Atlas)
            </div>
            <div className="text-[10px] text-cyan-400/80 mt-0.5">
              {mongoDbStatus?.storageFormatted || '18.4 KB'} synced
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-700/60 shadow-inner">
            <div className="text-[11px] font-semibold text-slate-400 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-blue-400" />
              Active Collections
            </div>
            <div className="text-sm font-bold text-blue-300 mt-1">
              7 Collections
            </div>
            <div className="text-[10px] text-blue-400/80 mt-0.5">
              Latency: {mongoDbStatus?.latencyMs || 35}ms
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-700/60 shadow-inner">
            <div className="text-[11px] font-semibold text-slate-400 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-purple-400" />
              Email Constraint
            </div>
            <div className="text-sm font-bold text-purple-300 mt-1">
              1 User = 1 Email
            </div>
            <div className="text-[10px] text-purple-300/80 mt-0.5">
              Strict Schema Integrity
            </div>
          </div>
        </div>
      </div>

      {/* MongoDB Atlas Connection Info Strip */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
            <Server className="w-4 h-4" />
          </div>
          <div>
            <div className="font-semibold text-slate-800 flex items-center gap-2">
              <span>Cluster URI:</span>
              <code className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-mono text-[11px]">
                {mongoDbStatus?.connectionUri || 'mongodb+srv://drushtishree1_db_user:••••••••@mediscan-admin.aspbcsk.mongodb.net/mediscan_clinical_db'}
              </code>
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">
              Database: <span className="font-semibold text-emerald-700">{mongoDbStatus?.databaseName || 'mediscan_clinical_db'}</span> &bull; Port: <span className="font-semibold">3000</span> &bull; Live Sync Engine Active
            </div>
          </div>
        </div>
        {mongoDbStatus?.error && (
          <div className="text-[11px] text-amber-700 bg-amber-50 px-3 py-1.5 rounded-xl border border-amber-200 flex items-center gap-1.5">
            <AlertCircle className="w-3.5 h-3.5 flex-shrink-0 text-amber-600" />
            <span>{mongoDbStatus.error}</span>
          </div>
        )}
      </div>

      {/* Alert banner */}
      {message && (
        <div className={`p-4 rounded-2xl flex items-center gap-2.5 text-xs font-semibold ${
          message.type === 'success'
            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
            : 'bg-rose-50 text-rose-800 border border-rose-200'
        }`}>
          {message.type === 'success' ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <AlertCircle className="w-4 h-4 text-rose-600" />}
          <span>{message.text}</span>
        </div>
      )}

      {/* Main Database Workstation */}
      <div className="grid lg:grid-cols-12 gap-6">
        
        {/* Left: Collections Sidebar */}
        <div className="lg:col-span-3 space-y-2">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider px-2">
            Database Collections
          </div>
          <div className="space-y-1">
            {collectionsList.map((col) => {
              const Icon = col.icon;
              const isActive = activeCollection === col.name;
              return (
                <button
                  key={col.name}
                  onClick={() => { setActiveCollection(col.name); setIsEditing(false); setIsInserting(false); }}
                  className={`w-full p-3 rounded-2xl text-left transition-all flex items-center justify-between cursor-pointer ${
                    isActive
                      ? 'bg-emerald-600 text-white shadow-md font-bold'
                      : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 font-medium'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-500'}`} />
                    <span className="text-xs">{col.label}</span>
                  </div>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
                    isActive ? 'bg-emerald-700 text-white' : 'bg-slate-100 text-slate-600'
                  }`}>
                    {col.count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Center/Right: Document Query & JSON Inspector */}
        <div className="lg:col-span-9 space-y-4">
          {/* Action & Search Bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-4 rounded-2xl bg-white border border-slate-200 shadow-sm">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={`Search ${activeCollection} documents...`}
                className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
              <button
                onClick={() => { setIsInserting(!isInserting); setIsEditing(false); }}
                className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Insert Document</span>
              </button>
            </div>
          </div>

          {/* Insert Document Panel */}
          {isInserting && (
            <div className="p-5 rounded-2xl bg-slate-900 border border-emerald-500/40 text-white shadow-xl">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Plus className="w-4 h-4" /> Insert into "{activeCollection}" collection
                </span>
                <button
                  onClick={() => setIsInserting(false)}
                  className="text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
              </div>
              <textarea
                value={newDocJson}
                onChange={(e) => setNewDocJson(e.target.value)}
                rows={6}
                className="w-full font-mono text-xs p-3 bg-slate-950 border border-slate-700 rounded-xl text-emerald-300 focus:outline-none focus:border-emerald-500"
              />
              <div className="mt-3 flex justify-end">
                <button
                  onClick={handleInsertDocument}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
                >
                  <Database className="w-3.5 h-3.5" />
                  <span>Execute MongoDB insertOne()</span>
                </button>
              </div>
            </div>
          )}

          {/* Document Browser & JSON View */}
          <div className="grid lg:grid-cols-12 gap-4">
            
            {/* List of Docs */}
            <div className="lg:col-span-5 space-y-2 max-h-[500px] overflow-y-auto pr-1">
              {isLoading ? (
                <div className="p-8 text-center text-xs text-slate-400 flex items-center justify-center gap-2">
                  <RefreshCw className="w-4 h-4 animate-spin text-emerald-600" />
                  Loading MongoDB records...
                </div>
              ) : filteredDocs.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-400 bg-white rounded-2xl border border-slate-200">
                  No documents found in this collection.
                </div>
              ) : (
                filteredDocs.map((doc, idx) => {
                  const docId = doc.id || doc._id || `doc-${idx}`;
                  const isSelected = selectedDoc && (selectedDoc.id === doc.id || selectedDoc._id === doc._id);
                  const title = doc.name || doc.title || doc.email || doc.userEmail || doc.question || doc.code || docId;
                  const subtitle = doc.role || doc.status || doc.action || doc.modality || doc.category || doc.createdAt || '';

                  return (
                    <div
                      key={docId}
                      onClick={() => {
                        setSelectedDoc(doc);
                        setEditJson(JSON.stringify(doc, null, 2));
                        setIsEditing(false);
                      }}
                      className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                        isSelected
                          ? 'border-emerald-500 bg-emerald-50/50 shadow-sm'
                          : 'border-slate-200 bg-white hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-[10px] text-slate-400 truncate max-w-[140px]">
                          {docId}
                        </span>
                        <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                          {subtitle}
                        </span>
                      </div>
                      <div className="text-xs font-bold text-slate-800 mt-1 truncate">
                        {title}
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Document JSON Inspector & Editor */}
            <div className="lg:col-span-7">
              {selectedDoc ? (
                <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 text-white shadow-xl flex flex-col h-full min-h-[420px]">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <div className="flex items-center gap-2">
                      <FileJson className="w-4 h-4 text-emerald-400" />
                      <span className="text-xs font-bold text-slate-200 font-mono">
                        _id: {selectedDoc.id || selectedDoc._id}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      {!isEditing ? (
                        <button
                          onClick={() => setIsEditing(true)}
                          className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                        >
                          <Edit3 className="w-3 h-3" />
                          <span>Edit</span>
                        </button>
                      ) : (
                        <button
                          onClick={handleSaveEdit}
                          className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
                        >
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Save</span>
                        </button>
                      )}
                      <button
                        onClick={() => handleDeleteDocument(selectedDoc.id || selectedDoc._id)}
                        className="p-1 rounded-lg hover:bg-rose-900/50 text-rose-400 hover:text-rose-300 transition-colors cursor-pointer"
                        title="Delete Document"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <div className="flex-1 mt-3">
                    {isEditing ? (
                      <textarea
                        value={editJson}
                        onChange={(e) => setEditJson(e.target.value)}
                        rows={16}
                        className="w-full h-full min-h-[320px] font-mono text-xs p-3 bg-slate-950 border border-slate-700 rounded-xl text-emerald-300 focus:outline-none focus:border-emerald-500"
                      />
                    ) : (
                      <pre className="font-mono text-xs text-emerald-300 p-3 bg-slate-950 rounded-xl overflow-auto max-h-[380px] border border-slate-800/80 leading-relaxed">
                        {JSON.stringify(selectedDoc, null, 2)}
                      </pre>
                    )}
                  </div>
                </div>
              ) : (
                <div className="p-12 text-center text-xs text-slate-400 bg-white rounded-2xl border border-slate-200 h-full flex flex-col items-center justify-center">
                  <Database className="w-8 h-8 text-slate-300 mb-2" />
                  <span>Select a document from the left list to view its MongoDB BSON/JSON structure.</span>
                </div>
              )}
            </div>

          </div>
        </div>

      </div>
    </div>
  );
};
