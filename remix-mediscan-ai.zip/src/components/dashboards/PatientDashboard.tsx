import React, { useState, useEffect } from 'react';
import { 
  Scan, 
  Activity, 
  Droplets,
  AlertCircle,
  Box,
  Database,
  LineChart as ChartIcon,
  Plus,
  Calendar,
  History,
  Target
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { StatCard } from '../common/StatCard';
import { Medical3DViewer } from '../viewer3d/Medical3DViewer';
import { StayHealthyFrontPage } from '../home/StayHealthyFrontPage';
import { VitalsTrendChart } from '../vitals/VitalsTrendChart';
import { VitalsSummaryCards } from '../vitals/VitalsSummaryCards';
import { LogVitalModal } from '../vitals/LogVitalModal';
import { VitalsHistoryTable } from '../vitals/VitalsHistoryTable';
import { PatientHealthGoals } from '../vitals/PatientHealthGoals';
import { INITIAL_VITALS_DATA } from '../../data/mockVitals';
import { VitalRecord } from '../../types';

interface PatientDashboardProps {
  onNavigate: (view: string) => void;
  onSelectRecord: (recordId: string) => void;
}

export const PatientDashboard: React.FC<PatientDashboardProps> = ({
  onNavigate,
  onSelectRecord,
}) => {
  const { user, userAnalyses } = useAuth();
  const [show3DAnatomy, setShow3DAnatomy] = useState(false);
  const [selectedOrgan, setSelectedOrgan] = useState<'Lungs' | 'Brain' | 'Heart' | 'Spine'>('Lungs');
  const [isLogModalOpen, setIsLogModalOpen] = useState(false);
  const [vitalsTab, setVitalsTab] = useState<'chart' | 'history' | 'goals'>('chart');

  // Vitals State with localStorage persistence
  const [vitals, setVitals] = useState<VitalRecord[]>(() => {
    const saved = localStorage.getItem('mediscan_patient_vitals');
    return saved ? JSON.parse(saved) : INITIAL_VITALS_DATA;
  });

  useEffect(() => {
    localStorage.setItem('mediscan_patient_vitals', JSON.stringify(vitals));
  }, [vitals]);

  const handleSaveVital = (newRecord: VitalRecord) => {
    setVitals((prev) => [newRecord, ...prev]);
  };

  const handleDeleteVital = (id: string) => {
    setVitals((prev) => prev.filter((r) => r.id !== id));
  };

  const latestVital = vitals[0];
  const previousVital = vitals[1];

  const patientRecords = userAnalyses;

  return (
    <div className="space-y-8">
      {/* Front Page Hero Design matching user mockup ("Stay Healthy") */}
      <StayHealthyFrontPage 
        onNavigate={onNavigate} 
        onSelectRecord={onSelectRecord} 
      />

      {/* ---------------------------------------------------- */}
      {/* REAL-TIME VITALS SUMMARY & TREND MONITORING SUITE */}
      {/* ---------------------------------------------------- */}
      <div className="space-y-6">
        
        {/* Section Header & Sub-navigation */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-700 text-white flex items-center justify-center shadow-md shadow-blue-500/20">
              <ChartIcon className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
                <span>Personal Biometrics & Telemetry Center</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase bg-emerald-100 text-emerald-800 border border-emerald-300">
                  Live Sensor Sync
                </span>
              </h2>
              <p className="text-xs text-slate-500">
                Visualize historical vitals, identify physiological trends, and track daily clinical adherence goals.
              </p>
            </div>
          </div>

          {/* Quick Sub-tab selector */}
          <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-slate-100 border border-slate-200 text-xs font-bold self-start sm:self-auto">
            <button
              onClick={() => setVitalsTab('chart')}
              className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                vitalsTab === 'chart'
                  ? 'bg-white text-blue-700 shadow-2xs font-extrabold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ChartIcon className="w-3.5 h-3.5" />
              <span>Trend Visualizer</span>
            </button>

            <button
              onClick={() => setVitalsTab('history')}
              className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                vitalsTab === 'history'
                  ? 'bg-white text-blue-700 shadow-2xs font-extrabold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span>Logbook ({vitals.length})</span>
            </button>

            <button
              onClick={() => setVitalsTab('goals')}
              className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                vitalsTab === 'goals'
                  ? 'bg-white text-blue-700 shadow-2xs font-extrabold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Target className="w-3.5 h-3.5" />
              <span>Health Targets</span>
            </button>
          </div>
        </div>

        {/* Real-time Summary Cards & Latest Snapshot */}
        <VitalsSummaryCards
          latestRecord={latestVital}
          previousRecord={previousVital}
          onOpenLogModal={() => setIsLogModalOpen(true)}
        />

        {/* Tab 1: Recharts Trend Line Visualizer */}
        {vitalsTab === 'chart' && (
          <div className="space-y-6 animate-in fade-in duration-300">
            <VitalsTrendChart
              records={vitals}
              analyses={patientRecords}
              onSelectScan={onSelectRecord}
            />

            {/* Accompanying Daily Goals Strip */}
            <PatientHealthGoals />
          </div>
        )}

        {/* Tab 2: Historical Logbook Table */}
        {vitalsTab === 'history' && (
          <div className="animate-in fade-in duration-300">
            <VitalsHistoryTable
              records={vitals}
              onDeleteRecord={handleDeleteVital}
            />
          </div>
        )}

        {/* Tab 3: Health Goals & Targets */}
        {vitalsTab === 'goals' && (
          <div className="animate-in fade-in duration-300">
            <PatientHealthGoals />
          </div>
        )}

      </div>

      {/* Clinical Vitals & Bio-Metric Record Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Blood Group"
          value={user?.bloodType || 'O+ (Positive)'}
          subtitle="Genotyped Clinical Record"
          icon={Droplets}
          iconColor="text-rose-600"
          iconBg="bg-rose-50 border-rose-100"
        />

        <StatCard
          title="Personal Scans"
          value={patientRecords.length}
          subtitle="Stored in MongoDB"
          icon={Scan}
          iconColor="text-blue-600"
          iconBg="bg-blue-50 border-blue-100"
        />

        <StatCard
          title="Allergies"
          value={user?.allergies?.[0] || 'None Reported'}
          subtitle="Verified by attending physician"
          icon={AlertCircle}
          iconColor="text-amber-600"
          iconBg="bg-amber-50 border-amber-100"
        />

        <StatCard
          title="Database Sync"
          value="MongoDB Atlas"
          subtitle={`${user?.email || 'drushtishree1@gmail.com'} Synced`}
          icon={Database}
          iconColor="text-emerald-600"
          iconBg="bg-emerald-50 border-emerald-100"
        />
      </div>

      {/* 3D Interactive Anatomical Organ Model Viewer */}
      <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-md space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-indigo-50 text-indigo-600 border border-indigo-200 shadow-sm">
              <Box className="w-6 h-6 text-indigo-600" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-extrabold text-slate-900">
                Interactive 3D Anatomical Organ Exploration
              </h3>
              <p className="text-xs text-slate-500">
                Rotate, inspect, and analyze 3D volumetric models (Lungs, Brain, Heart, Spine) correlated with your diagnostic imaging studies.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs font-bold">
            {(['Lungs', 'Brain', 'Heart', 'Spine'] as const).map((organ) => (
              <button
                key={organ}
                onClick={() => { setSelectedOrgan(organ); setShow3DAnatomy(true); }}
                className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                  selectedOrgan === organ && show3DAnatomy
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {organ}
              </button>
            ))}
            <button
              onClick={() => setShow3DAnatomy(!show3DAnatomy)}
              className="px-2.5 py-1 text-slate-600 hover:text-slate-900 text-[11px] underline ml-1 cursor-pointer"
            >
              {show3DAnatomy ? 'Hide 3D View' : 'Show 3D View'}
            </button>
          </div>
        </div>

        {show3DAnatomy && (
          <div className="rounded-2xl overflow-hidden border border-slate-800 shadow-inner">
            <Medical3DViewer selectedOrgan={selectedOrgan} />
          </div>
        )}
      </div>

      {/* Log Vital Modal */}
      <LogVitalModal
        isOpen={isLogModalOpen}
        onClose={() => setIsLogModalOpen(false)}
        onSave={handleSaveVital}
      />
    </div>
  );
};

